(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=globalThis,t=e.ShadowRoot&&(e.ShadyCSS===void 0||e.ShadyCSS.nativeShadow)&&`adoptedStyleSheets`in Document.prototype&&`replace`in CSSStyleSheet.prototype,n=Symbol(),r=new WeakMap,i=class{constructor(e,t,r){if(this._$cssResult$=!0,r!==n)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o,n=this.t;if(t&&e===void 0){let t=n!==void 0&&n.length===1;t&&(e=r.get(n)),e===void 0&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),t&&r.set(n,e))}return e}toString(){return this.cssText}},a=e=>new i(typeof e==`string`?e:e+``,void 0,n),o=(e,...t)=>new i(e.length===1?e[0]:t.reduce((t,n,r)=>t+(e=>{if(!0===e._$cssResult$)return e.cssText;if(typeof e==`number`)return e;throw Error(`Value passed to 'css' function must be a 'css' function result: `+e+`. Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.`)})(n)+e[r+1],e[0]),e,n),s=(n,r)=>{if(t)n.adoptedStyleSheets=r.map(e=>e instanceof CSSStyleSheet?e:e.styleSheet);else for(let t of r){let r=document.createElement(`style`),i=e.litNonce;i!==void 0&&r.setAttribute(`nonce`,i),r.textContent=t.cssText,n.appendChild(r)}},c=t?e=>e:e=>e instanceof CSSStyleSheet?(e=>{let t=``;for(let n of e.cssRules)t+=n.cssText;return a(t)})(e):e,{is:l,defineProperty:u,getOwnPropertyDescriptor:d,getOwnPropertyNames:ee,getOwnPropertySymbols:te,getPrototypeOf:ne}=Object,re=globalThis,ie=re.trustedTypes,ae=ie?ie.emptyScript:``,oe=re.reactiveElementPolyfillSupport,se=(e,t)=>e,ce={toAttribute(e,t){switch(t){case Boolean:e=e?ae:null;break;case Object:case Array:e=e==null?e:JSON.stringify(e)}return e},fromAttribute(e,t){let n=e;switch(t){case Boolean:n=e!==null;break;case Number:n=e===null?null:Number(e);break;case Object:case Array:try{n=JSON.parse(e)}catch{n=null}}return n}},le=(e,t)=>!l(e,t),ue={attribute:!0,type:String,converter:ce,reflect:!1,useDefault:!1,hasChanged:le};Symbol.metadata??=Symbol(`metadata`),re.litPropertyMetadata??=new WeakMap;var f=class extends HTMLElement{static addInitializer(e){this._$Ei(),(this.l??=[]).push(e)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(e,t=ue){if(t.state&&(t.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(e)&&((t=Object.create(t)).wrapped=!0),this.elementProperties.set(e,t),!t.noAccessor){let n=Symbol(),r=this.getPropertyDescriptor(e,n,t);r!==void 0&&u(this.prototype,e,r)}}static getPropertyDescriptor(e,t,n){let{get:r,set:i}=d(this.prototype,e)??{get(){return this[t]},set(e){this[t]=e}};return{get:r,set(t){let a=r?.call(this);i?.call(this,t),this.requestUpdate(e,a,n)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)??ue}static _$Ei(){if(this.hasOwnProperty(se(`elementProperties`)))return;let e=ne(this);e.finalize(),e.l!==void 0&&(this.l=[...e.l]),this.elementProperties=new Map(e.elementProperties)}static finalize(){if(this.hasOwnProperty(se(`finalized`)))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(se(`properties`))){let e=this.properties,t=[...ee(e),...te(e)];for(let n of t)this.createProperty(n,e[n])}let e=this[Symbol.metadata];if(e!==null){let t=litPropertyMetadata.get(e);if(t!==void 0)for(let[e,n]of t)this.elementProperties.set(e,n)}this._$Eh=new Map;for(let[e,t]of this.elementProperties){let n=this._$Eu(e,t);n!==void 0&&this._$Eh.set(n,e)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(e){let t=[];if(Array.isArray(e)){let n=new Set(e.flat(1/0).reverse());for(let e of n)t.unshift(c(e))}else e!==void 0&&t.push(c(e));return t}static _$Eu(e,t){let n=t.attribute;return!1===n?void 0:typeof n==`string`?n:typeof e==`string`?e.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(e=>this.enableUpdating=e),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(e=>e(this))}addController(e){(this._$EO??=new Set).add(e),this.renderRoot!==void 0&&this.isConnected&&e.hostConnected?.()}removeController(e){this._$EO?.delete(e)}_$E_(){let e=new Map,t=this.constructor.elementProperties;for(let n of t.keys())this.hasOwnProperty(n)&&(e.set(n,this[n]),delete this[n]);e.size>0&&(this._$Ep=e)}createRenderRoot(){let e=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return s(e,this.constructor.elementStyles),e}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(e=>e.hostConnected?.())}enableUpdating(e){}disconnectedCallback(){this._$EO?.forEach(e=>e.hostDisconnected?.())}attributeChangedCallback(e,t,n){this._$AK(e,n)}_$ET(e,t){let n=this.constructor.elementProperties.get(e),r=this.constructor._$Eu(e,n);if(r!==void 0&&!0===n.reflect){let i=(n.converter?.toAttribute===void 0?ce:n.converter).toAttribute(t,n.type);this._$Em=e,i==null?this.removeAttribute(r):this.setAttribute(r,i),this._$Em=null}}_$AK(e,t){let n=this.constructor,r=n._$Eh.get(e);if(r!==void 0&&this._$Em!==r){let e=n.getPropertyOptions(r),i=typeof e.converter==`function`?{fromAttribute:e.converter}:e.converter?.fromAttribute===void 0?ce:e.converter;this._$Em=r;let a=i.fromAttribute(t,e.type);this[r]=a??this._$Ej?.get(r)??a,this._$Em=null}}requestUpdate(e,t,n,r=!1,i){if(e!==void 0){let a=this.constructor;if(!1===r&&(i=this[e]),n??=a.getPropertyOptions(e),!((n.hasChanged??le)(i,t)||n.useDefault&&n.reflect&&i===this._$Ej?.get(e)&&!this.hasAttribute(a._$Eu(e,n))))return;this.C(e,t,n)}!1===this.isUpdatePending&&(this._$ES=this._$EP())}C(e,t,{useDefault:n,reflect:r,wrapped:i},a){n&&!(this._$Ej??=new Map).has(e)&&(this._$Ej.set(e,a??t??this[e]),!0!==i||a!==void 0)||(this._$AL.has(e)||(this.hasUpdated||n||(t=void 0),this._$AL.set(e,t)),!0===r&&this._$Em!==e&&(this._$Eq??=new Set).add(e))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(e){Promise.reject(e)}let e=this.scheduleUpdate();return e!=null&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(let[e,t]of this._$Ep)this[e]=t;this._$Ep=void 0}let e=this.constructor.elementProperties;if(e.size>0)for(let[t,n]of e){let{wrapped:e}=n,r=this[t];!0!==e||this._$AL.has(t)||r===void 0||this.C(t,void 0,n,r)}}let e=!1,t=this._$AL;try{e=this.shouldUpdate(t),e?(this.willUpdate(t),this._$EO?.forEach(e=>e.hostUpdate?.()),this.update(t)):this._$EM()}catch(t){throw e=!1,this._$EM(),t}e&&this._$AE(t)}willUpdate(e){}_$AE(e){this._$EO?.forEach(e=>e.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(e){return!0}update(e){this._$Eq&&=this._$Eq.forEach(e=>this._$ET(e,this[e])),this._$EM()}updated(e){}firstUpdated(e){}};f.elementStyles=[],f.shadowRootOptions={mode:`open`},f[se(`elementProperties`)]=new Map,f[se(`finalized`)]=new Map,oe?.({ReactiveElement:f}),(re.reactiveElementVersions??=[]).push(`2.1.2`);var de=globalThis,fe=e=>e,pe=de.trustedTypes,me=pe?pe.createPolicy(`lit-html`,{createHTML:e=>e}):void 0,he=`$lit$`,p=`lit$${Math.random().toFixed(9).slice(2)}$`,ge=`?`+p,_e=`<${ge}>`,m=document,ve=()=>m.createComment(``),ye=e=>e===null||typeof e!=`object`&&typeof e!=`function`,be=Array.isArray,xe=e=>be(e)||typeof e?.[Symbol.iterator]==`function`,Se=`[ 	
\f\r]`,Ce=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,we=/-->/g,Te=/>/g,h=RegExp(`>|${Se}(?:([^\\s"'>=/]+)(${Se}*=${Se}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,`g`),Ee=/'/g,De=/"/g,Oe=/^(?:script|style|textarea|title)$/i,ke=e=>(t,...n)=>({_$litType$:e,strings:t,values:n}),g=ke(1),_=ke(2),v=Symbol.for(`lit-noChange`),y=Symbol.for(`lit-nothing`),Ae=new WeakMap,b=m.createTreeWalker(m,129);function je(e,t){if(!be(e)||!e.hasOwnProperty(`raw`))throw Error(`invalid template strings array`);return me===void 0?t:me.createHTML(t)}var Me=(e,t)=>{let n=e.length-1,r=[],i,a=t===2?`<svg>`:t===3?`<math>`:``,o=Ce;for(let t=0;t<n;t++){let n=e[t],s,c,l=-1,u=0;for(;u<n.length&&(o.lastIndex=u,c=o.exec(n),c!==null);)u=o.lastIndex,o===Ce?c[1]===`!--`?o=we:c[1]===void 0?c[2]===void 0?c[3]!==void 0&&(o=h):(Oe.test(c[2])&&(i=RegExp(`</`+c[2],`g`)),o=h):o=Te:o===h?c[0]===`>`?(o=i??Ce,l=-1):c[1]===void 0?l=-2:(l=o.lastIndex-c[2].length,s=c[1],o=c[3]===void 0?h:c[3]===`"`?De:Ee):o===De||o===Ee?o=h:o===we||o===Te?o=Ce:(o=h,i=void 0);let d=o===h&&e[t+1].startsWith(`/>`)?` `:``;a+=o===Ce?n+_e:l>=0?(r.push(s),n.slice(0,l)+he+n.slice(l)+p+d):n+p+(l===-2?t:d)}return[je(e,a+(e[n]||`<?>`)+(t===2?`</svg>`:t===3?`</math>`:``)),r]},Ne=class e{constructor({strings:t,_$litType$:n},r){let i;this.parts=[];let a=0,o=0,s=t.length-1,c=this.parts,[l,u]=Me(t,n);if(this.el=e.createElement(l,r),b.currentNode=this.el.content,n===2||n===3){let e=this.el.content.firstChild;e.replaceWith(...e.childNodes)}for(;(i=b.nextNode())!==null&&c.length<s;){if(i.nodeType===1){if(i.hasAttributes())for(let e of i.getAttributeNames())if(e.endsWith(he)){let t=u[o++],n=i.getAttribute(e).split(p),r=/([.?@])?(.*)/.exec(t);c.push({type:1,index:a,name:r[2],strings:n,ctor:r[1]===`.`?Le:r[1]===`?`?Re:r[1]===`@`?ze:Ie}),i.removeAttribute(e)}else e.startsWith(p)&&(c.push({type:6,index:a}),i.removeAttribute(e));if(Oe.test(i.tagName)){let e=i.textContent.split(p),t=e.length-1;if(t>0){i.textContent=pe?pe.emptyScript:``;for(let n=0;n<t;n++)i.append(e[n],ve()),b.nextNode(),c.push({type:2,index:++a});i.append(e[t],ve())}}}else if(i.nodeType===8){if(i.data===ge)c.push({type:2,index:a});else{let e=-1;for(;(e=i.data.indexOf(p,e+1))!==-1;)c.push({type:7,index:a}),e+=p.length-1}}a++}}static createElement(e,t){let n=m.createElement(`template`);return n.innerHTML=e,n}};function x(e,t,n=e,r){if(t===v)return t;let i=r===void 0?n._$Cl:n._$Co?.[r],a=ye(t)?void 0:t._$litDirective$;return i?.constructor!==a&&(i?._$AO?.(!1),a===void 0?i=void 0:(i=new a(e),i._$AT(e,n,r)),r===void 0?n._$Cl=i:(n._$Co??=[])[r]=i),i!==void 0&&(t=x(e,i._$AS(e,t.values),i,r)),t}var Pe=class{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){let{el:{content:t},parts:n}=this._$AD,r=(e?.creationScope??m).importNode(t,!0);b.currentNode=r;let i=b.nextNode(),a=0,o=0,s=n[0];for(;s!==void 0;){if(a===s.index){let t;s.type===2?t=new Fe(i,i.nextSibling,this,e):s.type===1?t=new s.ctor(i,s.name,s.strings,this,e):s.type===6&&(t=new Be(i,this,e)),this._$AV.push(t),s=n[++o]}a!==s?.index&&(i=b.nextNode(),a++)}return b.currentNode=m,r}p(e){let t=0;for(let n of this._$AV)n!==void 0&&(n.strings===void 0?n._$AI(e[t]):(n._$AI(e,n,t),t+=n.strings.length-2)),t++}},Fe=class e{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(e,t,n,r){this.type=2,this._$AH=y,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=n,this.options=r,this._$Cv=r?.isConnected??!0}get parentNode(){let e=this._$AA.parentNode,t=this._$AM;return t!==void 0&&e?.nodeType===11&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=x(this,e,t),ye(e)?e===y||e==null||e===``?(this._$AH!==y&&this._$AR(),this._$AH=y):e!==this._$AH&&e!==v&&this._(e):e._$litType$===void 0?e.nodeType===void 0?xe(e)?this.k(e):this._(e):this.T(e):this.$(e)}O(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}T(e){this._$AH!==e&&(this._$AR(),this._$AH=this.O(e))}_(e){this._$AH!==y&&ye(this._$AH)?this._$AA.nextSibling.data=e:this.T(m.createTextNode(e)),this._$AH=e}$(e){let{values:t,_$litType$:n}=e,r=typeof n==`number`?this._$AC(e):(n.el===void 0&&(n.el=Ne.createElement(je(n.h,n.h[0]),this.options)),n);if(this._$AH?._$AD===r)this._$AH.p(t);else{let e=new Pe(r,this),n=e.u(this.options);e.p(t),this.T(n),this._$AH=e}}_$AC(e){let t=Ae.get(e.strings);return t===void 0&&Ae.set(e.strings,t=new Ne(e)),t}k(t){be(this._$AH)||(this._$AH=[],this._$AR());let n=this._$AH,r,i=0;for(let a of t)i===n.length?n.push(r=new e(this.O(ve()),this.O(ve()),this,this.options)):r=n[i],r._$AI(a),i++;i<n.length&&(this._$AR(r&&r._$AB.nextSibling,i),n.length=i)}_$AR(e=this._$AA.nextSibling,t){for(this._$AP?.(!1,!0,t);e!==this._$AB;){let t=fe(e).nextSibling;fe(e).remove(),e=t}}setConnected(e){this._$AM===void 0&&(this._$Cv=e,this._$AP?.(e))}},Ie=class{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(e,t,n,r,i){this.type=1,this._$AH=y,this._$AN=void 0,this.element=e,this.name=t,this._$AM=r,this.options=i,n.length>2||n[0]!==``||n[1]!==``?(this._$AH=Array(n.length-1).fill(new String),this.strings=n):this._$AH=y}_$AI(e,t=this,n,r){let i=this.strings,a=!1;if(i===void 0)e=x(this,e,t,0),a=!ye(e)||e!==this._$AH&&e!==v,a&&(this._$AH=e);else{let r=e,o,s;for(e=i[0],o=0;o<i.length-1;o++)s=x(this,r[n+o],t,o),s===v&&(s=this._$AH[o]),a||=!ye(s)||s!==this._$AH[o],s===y?e=y:e!==y&&(e+=(s??``)+i[o+1]),this._$AH[o]=s}a&&!r&&this.j(e)}j(e){e===y?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??``)}},Le=class extends Ie{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===y?void 0:e}},Re=class extends Ie{constructor(){super(...arguments),this.type=4}j(e){this.element.toggleAttribute(this.name,!!e&&e!==y)}},ze=class extends Ie{constructor(e,t,n,r,i){super(e,t,n,r,i),this.type=5}_$AI(e,t=this){if((e=x(this,e,t,0)??y)===v)return;let n=this._$AH,r=e===y&&n!==y||e.capture!==n.capture||e.once!==n.once||e.passive!==n.passive,i=e!==y&&(n===y||r);r&&this.element.removeEventListener(this.name,this,n),i&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){typeof this._$AH==`function`?this._$AH.call(this.options?.host??this.element,e):this._$AH.handleEvent(e)}},Be=class{constructor(e,t,n){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=n}get _$AU(){return this._$AM._$AU}_$AI(e){x(this,e)}},Ve={M:he,P:p,A:ge,C:1,L:Me,R:Pe,D:xe,V:x,I:Fe,H:Ie,N:Re,U:ze,B:Le,F:Be},He=de.litHtmlPolyfillSupport;He?.(Ne,Fe),(de.litHtmlVersions??=[]).push(`3.3.3`);var Ue=(e,t,n)=>{let r=n?.renderBefore??t,i=r._$litPart$;if(i===void 0){let e=n?.renderBefore??null;r._$litPart$=i=new Fe(t.insertBefore(ve(),e),e,void 0,n??{})}return i._$AI(e),i},We=globalThis,S=class extends f{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){let e=super.createRenderRoot();return this.renderOptions.renderBefore??=e.firstChild,e}update(e){let t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=Ue(t,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return v}};S._$litElement$=!0,S.finalized=!0,We.litElementHydrateSupport?.({LitElement:S});var Ge=We.litElementPolyfillSupport;Ge?.({LitElement:S}),(We.litElementVersions??=[]).push(`4.2.2`);var C=e=>(t,n)=>{n===void 0?customElements.define(e,t):n.addInitializer(()=>{customElements.define(e,t)})},Ke={attribute:!0,type:String,converter:ce,reflect:!1,hasChanged:le},qe=(e=Ke,t,n)=>{let{kind:r,metadata:i}=n,a=globalThis.litPropertyMetadata.get(i);if(a===void 0&&globalThis.litPropertyMetadata.set(i,a=new Map),r===`setter`&&((e=Object.create(e)).wrapped=!0),a.set(n.name,e),r===`accessor`){let{name:r}=n;return{set(n){let i=t.get.call(this);t.set.call(this,n),this.requestUpdate(r,i,e,!0,n)},init(t){return t!==void 0&&this.C(r,void 0,e,t),t}}}if(r===`setter`){let{name:r}=n;return function(n){let i=this[r];t.call(this,n),this.requestUpdate(r,i,e,!0,n)}}throw Error(`Unsupported decorator location: `+r)};function Je(e){return(t,n)=>typeof n==`object`?qe(e,t,n):((e,t,n)=>{let r=t.hasOwnProperty(n);return t.constructor.createProperty(n,e),r?Object.getOwnPropertyDescriptor(t,n):void 0})(e,t,n)}function w(e){return Je({...e,state:!0,attribute:!1})}var{I:Ye}=Ve,Xe=e=>e.strings===void 0,Ze={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},Qe=e=>(...t)=>({_$litDirective$:e,values:t}),$e=class{constructor(e){}get _$AU(){return this._$AM._$AU}_$AT(e,t,n){this._$Ct=e,this._$AM=t,this._$Ci=n}_$AS(e,t){return this.update(e,t)}update(e,t){return this.render(...t)}},et=(e,t)=>{let n=e._$AN;if(n===void 0)return!1;for(let e of n)e._$AO?.(t,!1),et(e,t);return!0},tt=e=>{let t,n;do{if((t=e._$AM)===void 0)break;n=t._$AN,n.delete(e),e=t}while(n?.size===0)},nt=e=>{for(let t;t=e._$AM;e=t){let n=t._$AN;if(n===void 0)t._$AN=n=new Set;else if(n.has(e))break;n.add(e),at(t)}};function rt(e){this._$AN===void 0?this._$AM=e:(tt(this),this._$AM=e,nt(this))}function it(e,t=!1,n=0){let r=this._$AH,i=this._$AN;if(i!==void 0&&i.size!==0){if(t){if(Array.isArray(r))for(let e=n;e<r.length;e++)et(r[e],!1),tt(r[e]);else r!=null&&(et(r,!1),tt(r))}else et(this,e)}}var at=e=>{e.type==Ze.CHILD&&(e._$AP??=it,e._$AQ??=rt)},ot=class extends $e{constructor(){super(...arguments),this._$AN=void 0}_$AT(e,t,n){super._$AT(e,t,n),nt(this),this.isConnected=e._$AU}_$AO(e,t=!0){e!==this.isConnected&&(this.isConnected=e,e?this.reconnected?.():this.disconnected?.()),t&&(et(this,e),tt(this))}setValue(e){if(Xe(this._$Ct))this._$Ct._$AI(e,this);else{let t=[...this._$Ct._$AH];t[this._$Ci]=e,this._$Ct._$AI(t,this,0)}}disconnected(){}reconnected(){}};function st(e){return typeof e==`object`&&!!e&&`document`in e&&`history`in e&&`location`in e}function T(){let e=globalThis;if(st(e.window))return e.window;if(st(e))return e;throw Error(`lit-router requires a browser Window-like global with document, history, and location.`)}function E(){return T().document}function ct(e){if(typeof e==`string`)return{type:`name`,value:A(e)};if(e.id&&e.name)throw Error(`Route selector must not include both id and name.`);if(e.id)return{type:`id`,value:vt(e.id)};if(e.name)return{type:`name`,value:A(e.name)};throw Error(`Route selector must include either a route id or route name.`)}var D=`/`,O=`route-child`,lt=new Set([`404`,`error`]),ut=/:([A-Za-z0-9_-]+)(\([^)]*\))?([?+*])?/g,dt=3,ft=256,pt=128;function k(e){if(!e||e===D)return D;let t=e.replace(/\/+$/,``);return t.startsWith(D)?t:`${D}${t}`}function mt(e){return k(e||D)}function ht(e,t){let n=k(e),r=mt(t);return r===D?n:n===r?D:n.startsWith(`${r}/`)?k(n.slice(r.length)):null}function gt(e){let t=k(e);return t===D?[]:t.slice(1).split(`/`).filter(Boolean)}function _t(e){return!e||e===D?D:e===`*`?`*`:k(e.startsWith(D)?e:`/${e}`)}function A(e){let t=e.trim();if(!t)throw Error(`Route name must be a non-empty string.`);return t}function vt(e){let t=e.trim();if(!t)throw Error(`Route id must be a non-empty string.`);return t}function yt(e){if(e===void 0)return O;let t=e.trim();if(!t)throw Error(`Route slot must be a non-empty string.`);if(lt.has(t))throw Error(`Route slot "${t}" is reserved.`);return t}function bt(e){let t=Array(e.length+1);t[0]=D;let n=``;for(let r=0;r<e.length;r+=1)n+=`${D}${e[r]}`,t[r+1]=n;return t}function xt(e){try{return decodeURIComponent(e)}catch{return e}}function St(){return typeof URLPattern<`u`}function Ct(e,t){let n=e===`*`?`*`:_t(e),r=t.get(n);if(r!==void 0)return r;if(!St())return null;try{let e=new URLPattern({pathname:n});return t.set(n,e),e}catch{return t.set(n,null),null}}function wt(e){let t=_t(e);if(t===D)return{minSegments:0,maxSegments:0};if(t===`*`)return{minSegments:0,maxSegments:1/0};let n=0,r=0;for(let e of gt(t)){let t=Array.from(e.matchAll(ut));if(t.length===0){n+=1,r+=1;continue}let i=!1,a=0,o=!1;for(let n of t){let[t,r,s,c]=n;e.slice(a,n.index)&&(i=!0),c!==`+`&&c||(i=!0),(c===`+`||c===`*`)&&(o=!0),a=(n.index??0)+t.length}e.slice(a)&&(i=!0),i&&(n+=1),r=o?1/0:r+1}return{minSegments:n,maxSegments:r}}function Tt(e){let t={};for(let[n,r]of Object.entries(e))r&&(t[n]=xt(r));return t}function Et(e,t,n){if(e.normalizedPath===`*`)return[{consumedCount:t.length,params:{"*":t.join(`/`)}}];if(!e.pattern)return[];let r=[],i=Math.min(e.maxSegments,t.length);for(let t=e.minSegments;t<=i;t+=1){let i=e.pattern.exec({pathname:n[t]});i&&r.push({consumedCount:t,params:Tt(i.pathname.groups)})}return r}function Dt(e,t){let n=Object.keys(e),r=Object.keys(t);return n.length===r.length&&n.every(n=>e[n]===t[n])}function Ot(e,t){if(e.pathname!==t.pathname||e.localPathname!==t.localPathname||e.basePath!==t.basePath||e.search!==t.search||e.hash!==t.hash||e.branch.length!==t.branch.length||!Dt(e.params,t.params)||!e.branch.every((e,n)=>e===t.branch[n]))return!1;let n=e.slotBranches??{},r=t.slotBranches??{},i=Object.keys(n).sort(),a=Object.keys(r).sort();if(i.length!==a.length)return!1;let o=e.slotParams??{},s=t.slotParams??{};for(let e of i)if(!Dt(o[e]??{},s[e]??{}))return!1;return i.every((e,t)=>{if(e!==a[t])return!1;let i=n[e]??[],o=r[e]??[];return i.length===o.length&&i.every((e,t)=>e===o[t])})}function kt(e,t){let n=0,r=Math.min(e.length,t.length);for(;n<r&&e[n]===t[n];)n+=1;return n}function At(e){return e.records.map(e=>e.route)}function jt(e){let t=At(e);return{branch:t,leaf:t.at(-1),params:e.params}}function Mt(e){let t={};return e.forEach((e,n)=>{let r=t[n];r===void 0?t[n]=e:t[n]=Array.isArray(r)?[...r,e]:[r,e]}),t}function Nt(){return{pathname:this.pathname,localPathname:this.localPathname,basePath:this.basePath,search:this.search,query:Mt(this.query),hash:this.hash,params:this.params,branch:this.branch,leaf:this.leaf,slotBranches:this.slotBranches,slotParams:this.slotParams,slots:this.slots,url:this.url.href,navigationKey:this.navigationKey,direction:this.direction,data:this.data,meta:this.meta}}function Pt(e){let t=[],n=new Set;for(let r of e.branch)n.add(r),t.push(r);let r=e.slotBranches??{};for(let e of Object.keys(r).sort())for(let i of r[e]??[])n.has(i)||(n.add(i),t.push(i));return t}function Ft(e,t){let n=[],r=new Set,i=e.slotBranches??{},a=t?.slotBranches??{};for(let t of Object.keys(i).sort()){let o=i[t]??[],s=kt(o,a[t]??[]);for(let t of o.slice(s).reverse())e.branch.includes(t)||r.has(t)||(r.add(t),n.push(t))}let o=kt(e.branch,t?.branch??[]);for(let t of e.branch.slice(o).reverse())r.has(t)||(r.add(t),n.push(t));return n}function It(e){let t=Object.values(e.slotBranches??{});return e.branch.length?[e.branch,...t]:t}function Lt(e,t=[],n=new Map,r=new Map){for(let i of e){let e=[...t,i];if(i.id){let t=vt(i.id);if(n.has(t))throw Error(`Duplicate route id "${t}" detected.`);n.set(t,e)}if(i.name){let t=A(i.name);if(r.has(t))throw Error(`Duplicate route name "${t}" detected.`);r.set(t,e)}i.children?.length&&Lt(i.children,e,n,r)}return{routeIds:n,namedRoutes:r}}function Rt(e){if(e===`*`)return 1;let t=Array.from(e.matchAll(ut));return t.length===0?5:t.some(([,,,e])=>e===`*`||e===`+`)?1:t.some(([,,,e])=>e===`?`)?2:4}function zt(e){let t=_t(e);return t===D?[]:t===`*`?[1]:gt(t).map(e=>Rt(e))}function Bt(e,t){let n=Math.max(e.specificity.length,t.specificity.length);for(let r=0;r<n;r+=1){let n=r<e.specificity.length?e.specificity[r]:dt,i=r<t.specificity.length?t.specificity[r]:dt;if(n!==i)return i-n}return e.sortIndex-t.sortIndex}function Vt(e){let t=new Map;for(let n of e){let e=yt(n.route.slot),r=t.get(e);r||(r=[],t.set(e,r)),r.push(n)}return t}function Ht(e,t){let n=e.map((e,n)=>{yt(e.slot);let r=_t(e.path),{minSegments:i,maxSegments:a}=wt(r),o=e.children?.length?Ht(e.children,t):[];return{route:e,normalizedPath:r,pattern:r===`*`?null:Ct(r,t),children:o,childrenBySlot:Vt(o),minSegments:i,maxSegments:a,specificity:zt(r),sortIndex:n}});return n.sort(Bt),n}function Ut(e){return{...e,meta:e.meta?{...e.meta}:void 0,props:e.props?{...e.props}:void 0,children:e.children?.length?j(e.children):void 0}}function j(e){return e.map(e=>Ut(e))}function Wt(e){let t={...e,meta:e.meta?Object.freeze({...e.meta}):void 0,props:e.props?Object.freeze({...e.props}):void 0,children:e.children?.length?Gt(e.children):void 0};return Object.freeze(t)}function Gt(e){return Object.freeze(e.map(e=>Wt(e)))}function Kt(e){return e.reduce((e,t)=>e+1+Kt(t.children??[]),0)}function qt(e){return typeof e==`object`&&!!e&&`then`in e&&typeof e.then==`function`}function Jt(e,t){if(e===void 0)return t;if(!Number.isInteger(e)||e<0||e>t)throw Error(`Route insertion index must be an integer between 0 and ${t}.`);return e}function Yt(e,t){let n=e.findIndex(t);if(n>=0)return e.splice(n,1),!0;for(let n of e)if(n.children?.length&&Yt(n.children,t))return n.children.length===0&&(n.children=void 0),!0;return!1}function Xt(e,t){if(t==null)throw Error(`Missing route param "${e}".`);return encodeURIComponent(String(t))}function Zt(e){if(e==null)throw Error(`Missing route param "*".`);return String(e).split(`/`).filter(Boolean).map(e=>encodeURIComponent(e))}function Qt(e,t){if(e===`*`)return Zt(t[`*`]);let n=!1,r=``,i=0;for(let a of e.matchAll(ut)){n=!0;let[o,s,c,l]=a;if(l&&l!==`?`)throw Error(`Route path segment "${e}" uses unsupported reverse-routing modifier "${l}" in token "${o}".`);r+=e.slice(i,a.index),l===`?`&&(t[s]===null||t[s]===void 0)||(r+=Xt(s,t[s])),i=(a.index??0)+o.length}return n?(r+=e.slice(i),r?[r]:[]):[e]}function $t(e,t={}){let n=[];for(let r of e){let e=_t(r.path);if(e!==D)for(let r of gt(e))n.push(...Qt(r,t))}return n.length?`/${n.join(`/`)}`:D}function en(e){if(!e)return new URLSearchParams;if(typeof e==`string`)return new URLSearchParams(e.startsWith(`?`)?e.slice(1):e);if(e instanceof URLSearchParams)return new URLSearchParams(e);let t=new URLSearchParams;for(let[n,r]of Object.entries(e)){if(r==null)continue;let e=Array.isArray(r)?r:[r];for(let r of e)t.append(n,String(r))}return t}function tn(e,t){if(!e&&!t)return;let n=en(e);if(t){let e=en(t),r=new Set;for(let t of e.keys())if(!r.has(t)){r.add(t),n.delete(t);for(let r of e.getAll(t))n.append(t,r)}}return n}function nn(e){let t=en(e).toString();return t?`?${t}`:``}function rn(e){return e?e.startsWith(`#`)?e:`#${e}`:``}function an(e,t,n=[],r={}){let i={},a=new Map,o=bt(t);for(let s of e){let e=yt(s.route.slot);if(e in i)continue;let c=s.normalizedPath,l=c,u=a.get(l);if(u||(u=Et(s,t,o),a.set(l,u)),u.length!==0)for(let a of u){let o={route:s.route,params:{...r,...a.params}},l=t.slice(a.consumedCount),u=[...n,o],d=s.children.length?an(s.children,l,u,o.params):{},ee=d[O],te=l.length===0||c===`*`,ne=ee??(te?{records:u,params:o.params}:null);if(ne){i[e]=ne;for(let[e,t]of Object.entries(d))e===O||e in i||(i[e]=t);break}}}return i}var on=class e extends EventTarget{static activeRouter;routeTree=[];basePath;beforeRoute;current={pathname:D,localPathname:D,basePath:D,search:``,query:new URLSearchParams,hash:``,params:{},branch:[],url:new URL(T().location.href),navigationKey:``,direction:`none`};loadedRoutes=new WeakSet;pendingRouteLoads=new WeakMap;routePatternCache=new Map;compiledRoutes=[];routeIds=new Map;namedRoutes=new Map;readonlyRoutes=Object.freeze([]);routeCount=0;navigationEntryOrders=new Map;nextNavigationEntryOrder=0;navigationId=0;activeNavigation;browserNavigation;maxRedirectDepth=3;pendingRedirectDepths=new Map;activeRouteLoads=0;started=!1;routeMutationDepth=0;pendingRouteRefreshSkipIfSame;pendingRouteTreeChange=!1;lastRouteErrorDetail;lastRouteNotFoundDetail;dynamicLeaveGuards=new Set;addEventListener(e,t,n){super.addEventListener(e,t,n)}removeEventListener(e,t,n){super.removeEventListener(e,t,n)}onDocumentClick=e=>{let t=typeof e.composedPath==`function`?e.composedPath():[],n;if(t.length>0)n=t.find(e=>this.isNavigableAnchor(e));else{let t=e.target;for(;t;){if(this.isNavigableAnchor(t)){n=t;break}t=t.parentElement}}if(!n||e.defaultPrevented||e.button!==0||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey)return;let r=n.getAttribute(`target`);if(r&&r!==`_self`)return;let i=n.getAttribute(`rel`);if(i&&i.split(/\s+/).includes(`external`))return;if(t.length>0)for(let e of t){if(e instanceof Element&&(e.hasAttribute(`data-router-ignore`)||e.hasAttribute(`download`)||e.hasAttribute(`disabled`)||e.getAttribute(`aria-disabled`)===`true`))return;if(e===n)break}else{let t=e.target;for(;t&&t!==n.parentElement;){if(t.hasAttribute(`data-router-ignore`)||t.hasAttribute(`download`)||t.hasAttribute(`disabled`)||t.getAttribute(`aria-disabled`)===`true`)return;t=t.parentElement}}let a=this.getAnchorHref(n);if(!a||a.startsWith(`#`))return;let o=T(),s;try{s=new URL(a,o.location.href)}catch{return}if(s.origin!==o.location.origin||!this.managesUrl(s))return;let c=n.hasAttribute(`data-router-replace`);e.preventDefault(),this.navigate(s,c?`replace`:`push`)};onNavigate=e=>{let t=e;if(t.defaultPrevented||!t.canIntercept||!t.intercept||t.downloadRequest||t.formData)return;let n=new URL(t.destination.url);if(n.origin!==T().location.origin||!this.managesUrl(n))return;let r=this.consumePendingRedirectDepth(n);t.intercept({scroll:`manual`,handler:async()=>{await this.routeTo(n,{history:`none`,navigationKey:t.destination.key,redirectDepth:r})}})};constructor(e={}){super(),this.routeTree=j(e.routes??[]),this.basePath=mt(e.basePath??D),this.beforeRoute=e.beforeRoute,this.current={...this.current,basePath:this.basePath,url:new URL(T().location.href)},this.rebuildRouteState(),e.autoStart!==!1&&this.start()}get routes(){return this.readonlyRoutes}set routes(e){this.replaceRouteTree(e,{skipIfSame:!1,reason:`replace`})}start(){if(this.started)return;if(!St())throw Error(`Router requires URLPattern support. Use a modern browser or provide a URLPattern polyfill before starting the router.`);if(e.activeRouter&&e.activeRouter!==this)throw Error(`Only one Router instance can be started at a time in single-router mode.`);let t=this.requireNavigationApi();this.browserNavigation=t,this.ensureNavigationEntryOrder(this.getCurrentNavigationEntryKey()),this.started=!0,e.activeRouter=this,E().addEventListener(`click`,this.onDocumentClick),t.addEventListener(`navigate`,this.onNavigate),this.routeTo(new URL(T().location.href),{history:`none`,skipIfSame:!1})}stop(){this.started&&(this.activeNavigation?.abortController.abort(),this.navigationId+=1,this.activeNavigation=void 0,this.started=!1,e.activeRouter===this&&(e.activeRouter=void 0),E().removeEventListener(`click`,this.onDocumentClick),this.browserNavigation?.removeEventListener(`navigate`,this.onNavigate),this.browserNavigation=void 0)}configure(e){`routes`in e&&(this.routeTree=j(e.routes??[]),this.rebuildRouteState(),this.notifyRouteTreeChanged(`replace`)),e.basePath!==void 0&&(this.basePath=mt(e.basePath)),`beforeRoute`in e&&(this.beforeRoute=e.beforeRoute),this.requestRouteRefresh(!1)}setRoutes(e){this.replaceRouteTree(e,{skipIfSame:!1,reason:`replace`})}insertRoutes(e,t={}){if(e.length===0)return;let n=j(e),{routeIds:r,namedRoutes:i}=Lt(n);for(let e of r.keys())if(this.routeIds.has(e))throw Error(`Duplicate route id "${e}" detected.`);for(let e of i.keys())if(this.namedRoutes.has(e))throw Error(`Duplicate route name "${e}" detected.`);let a=this.routeTree;if(t.parentId&&t.parentName)throw Error(`Provide either parentId or parentName, not both.`);if(t.parentId||t.parentName){let e=this.resolveRouteBranch({id:t.parentId,name:t.parentName}).at(-1);if(!e)throw Error(`Unknown parent route.`);a=e.children??=[]}let o=Jt(t.index,a.length);a.splice(o,0,...n),this.rebuildRouteState(),this.notifyRouteTreeChanged(`insert`),this.requestRouteRefresh(!0)}removeRoute(e){let t=ct(e);return Yt(this.routeTree,e=>t.type===`id`?!!(e.id&&vt(e.id)===t.value):!!(e.name&&A(e.name)===t.value))?(this.rebuildRouteState(),this.notifyRouteTreeChanged(`remove`),this.requestRouteRefresh(!0),!0):!1}batchRouteUpdates(e){let t=this.routeMutationDepth===0,n=t?{routeTree:j(this.routeTree),basePath:this.basePath,beforeRoute:this.beforeRoute}:void 0;this.routeMutationDepth+=1;try{if(qt(e()))throw Error(`batchRouteUpdates callback must be synchronous.`)}catch(e){throw t&&n&&(this.routeTree=n.routeTree,this.basePath=n.basePath,this.beforeRoute=n.beforeRoute,this.rebuildRouteState(),this.pendingRouteTreeChange=!1,this.pendingRouteRefreshSkipIfSame=void 0),e}finally{--this.routeMutationDepth}if(this.routeMutationDepth>0)return;let r=this.pendingRouteTreeChange,i=this.pendingRouteRefreshSkipIfSame;this.pendingRouteTreeChange=!1,this.pendingRouteRefreshSkipIfSame=void 0,r&&this.dispatchRouteTreeChange(`batch`),i!==void 0&&this.requestRouteRefresh(i)}push(e){this.navigate(e,`push`)}replace(e){this.navigate(e,`replace`)}back(){let e=this.navigationApi;typeof e.back==`function`?e.back():T().history.back()}forward(){let e=this.navigationApi;typeof e.forward==`function`?e.forward():T().history.forward()}go(e){T().history.go(e)}resolve(e){let t=this.toRouteUrl(e);return this.resolveMatched(t)}resolveUrl(e){let t=this.toRouteUrl(e);return this.resolveMatched(t)}resolveNamed(e,t={}){return this.resolveMatched(this.toRouteUrl({name:e,...t}))}resolveId(e,t={}){return this.resolveMatched(this.toRouteUrl({id:e,...t}))}link(e){let t=this.toRouteUrl(e),n=T();return t.origin===n.location.origin?`${t.pathname}${t.search}${t.hash}`:t.href}linkAttributes(e,t={}){let n=this.link(e);return t.replace?{href:n,"data-router-replace":``}:{href:n}}registerLeaveGuard(e){return this.dynamicLeaveGuards.add(e),()=>{this.dynamicLeaveGuards.delete(e)}}isActive(e,t={}){if(this.current.branch.length===0)return!1;let n=It(this.current);if(typeof e==`object`&&e&&!(e instanceof URL)){if(`id`in e&&typeof e.id==`string`&&e.id.trim()){let r=vt(e.id);if(!(t.exact?n.some(e=>e[e.length-1]?.id===r):n.some(e=>e.some(e=>e.id===r))))return!1;let i=e,a={...i.params,...t.params},o=tn(i.query,t.query),s=i.hash??t.hash;return this.matchesParamsAndQuery(a,o,s)}if(`name`in e&&typeof e.name==`string`&&e.name.trim()){let r=A(e.name);if(!(t.exact?n.some(e=>e[e.length-1]?.name===r):n.some(e=>e.some(e=>e.name===r))))return!1;let i=e,a={...i.params,...t.params},o=tn(i.query,t.query),s=i.hash??t.hash;return this.matchesParamsAndQuery(a,o,s)}}if(typeof e==`string`&&e.trim()&&!e.startsWith(`/`)&&!e.startsWith(`.`)&&!e.includes(`/`)&&this.namedRoutes.has(A(e))){let r=A(e);return(t.exact?n.some(e=>e[e.length-1]?.name===r):n.some(e=>e.some(e=>e.name===r)))?this.matchesParamsAndQuery(t.params,t.query,t.hash):!1}let r=this.toRouteUrl(e),i=this.current.url,a=k(this.current.localPathname),o=ht(k(r.pathname),this.basePath)??k(r.pathname);if(t.exact){if(a!==o)return!1}else if(o===D){if(a!==D)return!1}else{let e=o.endsWith(`/`)?o:`${o}/`;if(a!==o&&!a.startsWith(e))return!1}if(r.search){for(let[e,t]of r.searchParams)if(!i.searchParams.getAll(e).includes(t))return!1}return r.hash&&r.hash!==i.hash?!1:this.matchesParamsAndQuery(t.params,t.query,t.hash)}matchesParamsAndQuery(e,t,n){if(e)for(let[t,n]of Object.entries(e)){if(n==null)continue;let e=String(n),r=xt(e),i=t=>t===e||t!==void 0&&xt(t)===r,a=i(this.current.params[t]);if(!a&&this.current.slotParams){for(let e of Object.values(this.current.slotParams))if(i(e[t])){a=!0;break}}if(!a)return!1}if(t){let e=en(t);for(let[t,n]of e)if(!this.current.query.getAll(t).includes(n))return!1}return n===void 0||rn(n)===this.current.hash}getRouteData(e){if(!e){if(this.current.data!==void 0)return this.current.data;if(this.current.routeData)for(let e=this.current.branch.length-1;e>=0;e--){let t=this.current.branch[e];if(t&&this.current.routeData.has(t))return this.current.routeData.get(t)}return}let{type:t,value:n}=ct(e),r;for(let e of It(this.current))if(r=e.find(e=>t===`id`?e.id===n:e.name===n),r)break;if(r&&this.current.routeData)return this.current.routeData.get(r)}cloneRoutes(){return j(this.routeTree)}get lastError(){return this.lastRouteErrorDetail}get lastNotFound(){return this.lastRouteNotFoundDetail}replaceRouteTree(e,t){this.routeTree=j(e),this.rebuildRouteState(),this.notifyRouteTreeChanged(t.reason),this.requestRouteRefresh(t.skipIfSame)}requireNavigationApi(){let e=T().navigation;if(!e||typeof e.navigate!=`function`)throw Error(`Router is Navigation API-first and requires window.navigation.navigate; it does not provide a History API fallback.`);return e}get navigationApi(){return this.browserNavigation??this.requireNavigationApi()}isNavigableAnchor(e){return e instanceof Element&&e.tagName.toUpperCase()===`A`&&!e.hasAttribute(`data-router-ignore`)}getAnchorHref(e){return e.getAttribute(`href`)??e.getAttribute(`xlink:href`)}ensureNavigationEntryOrder(e){let t=this.navigationEntryOrders.get(e);if(t!==void 0)return t;let n=this.nextNavigationEntryOrder;return this.navigationEntryOrders.set(e,n),this.nextNavigationEntryOrder+=1,this.pruneNavigationEntryOrders(),n}pruneNavigationEntryOrders(){if(this.navigationEntryOrders.size<=ft)return;let e=this.current.navigationKey,t=this.nextNavigationEntryOrder-pt;for(let[n,r]of this.navigationEntryOrders){if(this.navigationEntryOrders.size<=pt)break;n===e||r>=t||this.navigationEntryOrders.delete(n)}}getCurrentNavigationEntryKey(){let e=this.navigationApi.currentEntry?.key;if(e)return e;throw Error(`Router is Navigation API-first and requires window.navigation.currentEntry.key for per-entry state.`)}tryGetCurrentNavigationEntryKey(){try{return this.navigationApi.currentEntry?.key}catch{return}}resolveNavigationDirection(e,t){if(e===`push`)return`forward`;if(e===`replace`||!this.current.navigationKey||this.current.navigationKey===t)return`none`;let n=this.navigationEntryOrders.get(this.current.navigationKey),r=this.navigationEntryOrders.get(t);return n===void 0||r===void 0||n===r?`none`:r>n?`forward`:`backward`}resolveAttemptDirection(e,t){if(e===`push`)return`forward`;if(e===`replace`)return`none`;let n=t||this.getCurrentNavigationEntryKey();return this.ensureNavigationEntryOrder(n),this.resolveNavigationDirection(`none`,n)}navigate(e,t){let n=this.toRouteUrl(e),r=T();if(n.origin!==r.location.origin){t===`replace`?r.location.replace(n.href):r.location.assign(n.href);return}let i=`${n.pathname}${n.search}${n.hash}`;this.navigationApi.navigate(i,{history:t})}toRouteUrl(e){if(e instanceof URL)return new URL(e.href);if(typeof e==`string`){if(!e.trim())return new URL(this.current.url.href);if(e.trim()&&!e.startsWith(`/`)&&!e.startsWith(`.`)&&!e.includes(`/`)&&!e.includes(`?`)&&!e.includes(`#`)&&this.namedRoutes.has(A(e))){let t=$t(this.resolveNamedRouteBranch(A(e))),n=this.withBasePath(t);return new URL(n,T().location.origin)}if(e.startsWith(`/`)&&!e.startsWith(`//`)&&this.basePath!==D&&!e.startsWith(this.basePath+`/`)&&e!==this.basePath){let t=new URL(e,T().location.origin),n=this.withBasePath(t.pathname);return new URL(`${n}${t.search}${t.hash}`,T().location.origin)}return new URL(e,this.current.url.href)}let t;if(e.id)t=this.resolveRouteIdBranch(e.id);else if(e.name)t=this.resolveNamedRouteBranch(e.name);else if(this.current.branch.length>0)t=this.current.branch;else throw Error(`RouteLocation requires a route name or id when there is no active route.`);let n={...!e.id&&!e.name?this.current.params:{},...e.params??{}},r=$t(t,n),i=`${this.withBasePath(r)}${e.query===void 0?!e.id&&!e.name?this.current.url.search:``:nn(e.query)}${e.hash===void 0?!e.id&&!e.name?this.current.url.hash:``:rn(e.hash)}`;return new URL(i,T().location.origin)}resolveMatched(e){let t=this.resolveUrlDetail(e);return t&&t.branch.length>0?t:null}resolveNamedRouteBranch(e){let t=A(e),n=this.namedRoutes.get(t);if(!n)throw Error(`Unknown route name "${t}".`);return n}resolveRouteIdBranch(e){let t=vt(e),n=this.routeIds.get(t);if(!n)throw Error(`Unknown route id "${t}".`);return n}resolveRouteBranch(e){if(e.id&&e.name)throw Error(`Route selector must not include both id and name.`);if(e.id)return this.resolveRouteIdBranch(e.id);if(e.name)return this.resolveNamedRouteBranch(e.name);throw Error(`Route selector must include either a route id or route name.`)}withBasePath(e){return this.basePath===D?e:e===D?this.basePath:`${this.basePath}${e}`}resolveUrlDetail(e){let t=k(e.pathname),n=ht(t,this.basePath);if(n===null)return null;let r=an(this.compiledRoutes,gt(n)),i=r[O],a=i?At(i):[],o=a.at(-1),s=i?.params??{},c={},l={},u={};if(i){u[O]={branch:a,leaf:o,params:s};for(let[e,t]of Object.entries(r)){if(e===O)continue;let n=At(t);n.length<2||a.length===0||n[0]!==a[0]||(c[e]=n,l[e]=t.params,u[e]=jt(t))}}let d=Object.assign({},...a.map(e=>e.meta).filter(Boolean));return{pathname:t,localPathname:n,basePath:mt(this.basePath),search:e.search,query:new URLSearchParams(e.search),hash:e.hash,params:s,branch:a,leaf:o,slotBranches:Object.keys(c).length?c:void 0,slotParams:Object.keys(l).length?l:void 0,slots:Object.keys(u).length?u:void 0,url:e,navigationKey:this.tryGetCurrentNavigationEntryKey()??``,direction:`none`,meta:Object.keys(d).length?d:void 0,toJSON:Nt}}managesUrl(e){return ht(e.pathname,this.basePath)!==null}rebuildRouteState(){this.compiledRoutes=Ht(this.routeTree,this.routePatternCache);let{routeIds:e,namedRoutes:t}=Lt(this.routeTree);this.routeIds=e,this.namedRoutes=t,this.readonlyRoutes=Gt(this.routeTree),this.routeCount=Kt(this.routeTree)}notifyRouteTreeChanged(e){this.started&&(this.routeMutationDepth>0?this.pendingRouteTreeChange=!0:this.dispatchRouteTreeChange(e))}dispatchRouteTreeChange(e){let t={reason:e,routeCount:this.routeCount,routes:this.readonlyRoutes};this.dispatchEvent(new CustomEvent(`route-tree-change`,{detail:t}))}requestRouteRefresh(e){if(!this.started)return;if(this.routeMutationDepth>0){this.pendingRouteRefreshSkipIfSame=(this.pendingRouteRefreshSkipIfSame===void 0||this.pendingRouteRefreshSkipIfSame)&&e;return}let t=this.activeNavigation;if(t&&t.id===this.navigationId){let n=this.resolveUrlDetail(t.url);if(e&&(t.detail&&n&&Ot(t.detail,n)||!t.detail&&!n))return;this.routeTo(new URL(t.url.href),{history:t.history,navigationKey:t.navigationKey});return}let n=new URL(T().location.href);if(e){let e=this.resolveUrlDetail(n);if(e&&this.current.branch.length>0&&Ot(this.current,e)||!e&&this.lastRouteNotFoundDetail?.url.href===n.href)return}this.routeTo(n,{history:`none`,skipIfSame:e})}updateActiveNavigationDetail(e,t){this.activeNavigation?.id===e&&(this.activeNavigation.detail=t)}async routeTo(e,t){if(t.history!==`none`){this.navigationApi.navigate(`${e.pathname}${e.search}${e.hash}`,{history:t.history});return}this.activeNavigation?.url.href!==e.href&&this.activeNavigation?.abortController.abort();let n=++this.navigationId,r=new AbortController,i=this.resolveAttemptDirection(t.history,t.navigationKey);this.activeNavigation={id:n,url:new URL(e.href),history:t.history,navigationKey:t.navigationKey,detail:null,abortController:r};let a=r.signal,o=t.redirectDepth??0;try{let r=this.resolveUrlDetail(e);this.updateActiveNavigationDetail(n,r);let s=await this.evaluateGuards(e,r,i,a);if(!s||a.aborted||this.isNavigationStale(n)||this.followRedirect(e,s,o,i))return;if(!s.allowed){this.restoreCancelledNavigation(e,r?.navigationKey||t.navigationKey,i);return}if(!r||r.branch.length===0){this.dispatchRouteNotFound(e,i);return}if(this.shouldSkipNavigation(r,t)||!await this.loadBranchForNavigation(e,r,n,i,a))return;this.commitNavigation(r,t.history,t.navigationKey)}finally{this.activeNavigation?.id===n&&(this.activeNavigation=void 0)}}async evaluateGuards(e,t,n,r){try{let e=await this.runGuards(t,r);return r.aborted?null:e}catch(t){return r.aborted||this.dispatchRouteError(e,t,`guard`,n),null}}followRedirect(e,t,n,r){if(!t.redirect)return!1;let i=n+1;return i>this.maxRedirectDepth?(this.dispatchRouteError(e,Error(`Redirect loop detected`),`guard`,r),!0):(this.redirectWithNavigationApi(t.redirect,i),!0)}toRedirectInstruction(e,t){if(e instanceof URL)return{to:e,replace:!1};if(typeof e==`string`){if(!e.trim())return{to:new URL(t.href),replace:!1};let n;if(e.trim()&&!e.startsWith(`/`)&&!e.startsWith(`.`)&&!e.includes(`/`)&&!e.includes(`?`)&&!e.includes(`#`)&&this.namedRoutes.has(A(e)))n=this.toRouteUrl(e);else if(e.startsWith(`/`)&&!e.startsWith(`//`)&&this.basePath!==D&&!e.startsWith(this.basePath+`/`)&&e!==this.basePath){let t=new URL(e,T().location.origin),r=this.withBasePath(t.pathname);n=new URL(`${r}${t.search}${t.hash}`,T().location.origin)}else n=new URL(e,t.href);return{to:n,replace:!1}}return typeof e==`object`&&e&&`to`in e&&e.to?{to:this.toRedirectInstruction(e.to,t).to,replace:!!e.replace}:{to:this.toRouteUrl(e),replace:!1}}redirectWithNavigationApi(e,t){let n=T();e.to.origin===n.location.origin?(this.pendingRedirectDepths.set(e.to.href,t),this.navigationApi.navigate(`${e.to.pathname}${e.to.search}${e.to.hash}`,{history:e.replace?`replace`:`push`})):e.replace?n.location.replace(e.to.href):n.location.assign(e.to.href)}consumePendingRedirectDepth(e){let t=this.pendingRedirectDepths.get(e.href)??0;return this.pendingRedirectDepths.delete(e.href),t}shouldSkipNavigation(e,t){return t.history===`none`&&this.current.navigationKey&&e.navigationKey!==this.current.navigationKey?!1:t.skipIfSame!==!1&&Ot(this.current,e)}async loadBranchForNavigation(e,t,n,r,i){let a=this.loadingSlotsForDetail(t),o=a.length>0;o&&this.dispatchRouteLoading(`route-loading-start`,t.url,t.branch,a,r);try{for(let e of It(t))await this.loadBranch(e,i,t);let e=new Map,n=[],r=new Set;for(let e of It(t))for(let t of e)t.loader&&!r.has(t)&&(r.add(t),n.push(t));if(n.length>0){let r=await Promise.all(n.map(e=>{let n=e.slot||O,r=n!==O&&t.slotParams?.[n]?t.slotParams[n]:t.params,a={signal:i,router:this,pathname:t.pathname,localPathname:t.localPathname,params:r,query:t.query,hash:t.hash,url:t.url};return e.loader(a)}));if(i.aborted)return!1;for(let t=0;t<n.length;t++)e.set(n[t],r[t])}if(t.routeData=e,t.leaf&&e.has(t.leaf))t.data=e.get(t.leaf);else for(let n=t.branch.length-1;n>=0;n--){let r=t.branch[n];if(r&&e.has(r)){t.data=e.get(r);break}}}catch(t){return i.aborted||this.dispatchRouteError(e,t,`load`,r),!1}finally{o&&this.dispatchRouteLoading(`route-loading-end`,t.url,t.branch,a,r)}return!i.aborted&&!this.isNavigationStale(n)}commitNavigation(e,t,n){let r=this.resolveCommittedNavigationKey(t,n),i={...e,navigationKey:r,direction:this.resolveNavigationDirection(t,r)};this.current=i,this.lastRouteErrorDetail=void 0,this.lastRouteNotFoundDetail=void 0,this.dispatchEvent(new CustomEvent(`route-change`,{detail:i}))}resolveCommittedNavigationKey(e,t){if(e!==`none`)throw Error(`Router commits must be driven by the Navigation API navigate event.`);let n=t||this.getCurrentNavigationEntryKey();return this.ensureNavigationEntryOrder(n),n}async runGuards(e,t){let n=this.current.branch.length?this.current:null;if(n){let r=Ft(n,e);if(r.length>0){for(let r of this.dynamicLeaveGuards){if(t.aborted)return{allowed:!1};let i=await r({...n,to:e,router:this,signal:t});if(t.aborted||i===!1)return{allowed:!1};if(i&&i!==!0)return{allowed:!1,redirect:this.toRedirectInstruction(i,n.url)}}for(let i of r){if(t.aborted)return{allowed:!1};if(!i.beforeLeave)continue;let r=await i.beforeLeave({...n,to:e,router:this,signal:t});if(t.aborted||r===!1)return{allowed:!1};if(r&&r!==!0)return{allowed:!1,redirect:this.toRedirectInstruction(r,n.url)}}}}if(!e)return{allowed:!0};if(this.beforeRoute){if(t.aborted)return{allowed:!1};let r=await this.beforeRoute({...e,from:n,router:this,signal:t});if(t.aborted||r===!1)return{allowed:!1};if(r&&r!==!0)return{allowed:!1,redirect:this.toRedirectInstruction(r,e.url)}}for(let r of Pt(e)){if(t.aborted)return{allowed:!1};if(!r.guard)continue;let i=await r.guard({...e,from:n,router:this,signal:t});if(t.aborted||i===!1)return{allowed:!1};if(i&&i!==!0)return{allowed:!1,redirect:this.toRedirectInstruction(i,e.url)}}return{allowed:!0}}branchNeedsLoading(e){return e.some(e=>!!(e.loader||e.load&&(!this.loadedRoutes.has(e)||this.pendingRouteLoads.has(e))))}loadingSlotsForDetail(e){let t=[];this.branchNeedsLoading(e.branch)&&t.push(O);for(let[n,r]of Object.entries(e.slotBranches??{}).sort(([e],[t])=>e.localeCompare(t)))this.branchNeedsLoading(r)&&t.push(n);return t}async loadBranch(e,t,n){for(let r of e){if(t.aborted)return;if(!r.load||this.loadedRoutes.has(r))continue;let e=this.pendingRouteLoads.get(r);if(e&&!e.signal.aborted){await e.promise;continue}let i=r.slot||O,a=i!==O&&n?.slotParams?.[i]?n.slotParams[i]:n?.params??{},o={signal:t,router:this,pathname:n?.pathname??``,localPathname:n?.localPathname??``,params:a,query:n?.query??new URLSearchParams,hash:n?.hash??``,url:n?.url??new URL(`about:blank`)},s=Promise.resolve().then(()=>r.load?.(o)).then(()=>{this.loadedRoutes.add(r)}).finally(()=>{this.pendingRouteLoads.get(r)?.promise===s&&this.pendingRouteLoads.delete(r)});this.pendingRouteLoads.set(r,{promise:s,signal:t}),await s}}isNavigationStale(e){return e!==this.navigationId}restoreCancelledNavigation(e,t,n){n!==`none`&&this.current.branch.length&&e.href===new URL(T().location.href).href&&e.href!==this.current.url.href&&(this.navigationEntryOrders.get(this.current.navigationKey),t&&this.navigationEntryOrders.get(t),this.restoreCancelledNavigationWithNavigationApi())}restoreCancelledNavigationWithNavigationApi(){let e=this.navigationApi;if(this.current.navigationKey&&typeof e.traverseTo==`function`&&typeof e.entries==`function`&&e.entries().some(e=>e.key===this.current.navigationKey))try{return e.traverseTo(this.current.navigationKey),!0}catch{}let t=`${this.current.url.pathname}${this.current.url.search}${this.current.url.hash}`;try{return this.navigationApi.navigate(t,{history:`replace`}),!0}catch{return!1}}dispatchRouteLoading(e,t,n,r,i){this.activeRouteLoads=e===`route-loading-start`?this.activeRouteLoads+1:Math.max(0,this.activeRouteLoads-1),this.dispatchEvent(new CustomEvent(e,{detail:{url:t,branch:[...n],loadingSlots:r,pending:this.activeRouteLoads,direction:i}}))}dispatchRouteNotFound(e,t){let n={url:e,basePath:mt(this.basePath),direction:t};this.lastRouteErrorDetail=void 0,this.lastRouteNotFoundDetail=n,this.dispatchEvent(new CustomEvent(`route-not-found`,{detail:n})),console.warn(`[router] No route matched for ${e.pathname}`)}dispatchRouteError(e,t,n,r){let i={url:e,error:t,phase:n,direction:r};this.lastRouteNotFoundDetail=void 0,this.lastRouteErrorDetail=i,this.dispatchEvent(new CustomEvent(`route-error`,{detail:i})),console.error(`[router] Route transition failed`,t)}};function sn(e){try{return decodeURIComponent(e)}catch{return e}}function cn(e,t){return typeof e==`string`&&e?e:e instanceof URL?e.href:t?.href??``}var ln=class e{static scrollRestorationUsage=new WeakMap;positions=new Map;maxPositions;controlsBrowserRestoration=!1;constructor(e={}){this.maxPositions=e.maxPositions??50}acquireBrowserScrollRestoration(){let t=T();if(this.controlsBrowserRestoration||!(`scrollRestoration`in t.history))return;let n=e.scrollRestorationUsage.get(t.history);n?n.users.add(this):(e.scrollRestorationUsage.set(t.history,{users:new Set([this]),previous:t.history.scrollRestoration}),t.history.scrollRestoration=`manual`),this.controlsBrowserRestoration=!0}releaseBrowserScrollRestoration(){let t=T();if(!this.controlsBrowserRestoration||!(`scrollRestoration`in t.history))return;let n=e.scrollRestorationUsage.get(t.history);this.controlsBrowserRestoration=!1,n&&(n.users.delete(this),n.users.size===0&&(t.history.scrollRestoration=n.previous,e.scrollRestorationUsage.delete(t.history)))}capture(e,t){let n=T();this.remember(cn(e,t),{left:n.scrollX,top:n.scrollY})}restore(e,t){let n=e instanceof URL?e:t;if(!n)return;if(n.hash){let e=sn(n.hash.slice(1)),t=null;if(e&&(t=E().getElementById(e),!t))try{let n=T(),r=typeof n.CSS?.escape==`function`?n.CSS.escape(e):e;t=E().querySelector(`a[name="${r}"]`)}catch{}if(t&&typeof t.scrollIntoView==`function`){t.scrollIntoView();return}}let r=this.positions.get(cn(e,t));r?T().scrollTo({left:r.left,top:r.top,behavior:`instant`}):T().scrollTo({top:0,left:0,behavior:`instant`})}remember(e,t){for(this.positions.delete(e),this.positions.set(e,t);this.positions.size>this.maxPositions;){let e=this.positions.keys().next().value;if(!e)break;this.positions.delete(e)}}},un=`context-request`,dn=class extends Event{context;callback;subscribe;constructor(e,t,n){super(un,{bubbles:!0,composed:!0}),this.context=e,this.callback=t,this.subscribe=n}},fn=Object.freeze({name:`@elelcode/lit-router/context#router`}),pn=Object.freeze({name:`@elelcode/lit-router/context#route`});function mn(e,t,n,r){let i,a=new dn(t,(e,t)=>{i=t,n(e,t)},r);return e.dispatchEvent(a),()=>{i?.()}}var hn=`route-child`,gn=class extends S{static properties={router:{attribute:!1},childSlot:{attribute:`child-slot`},noViewTransition:{attribute:`no-view-transition`,type:Boolean}};constructor(){super(),this.router=void 0,this.childSlot=hn,this.noViewTransition=!1}viewMode=`route`;routeErrorDetail;routeNotFoundDetail;activeDetail={pathname:`/`,localPathname:`/`,basePath:`/`,search:``,query:new URLSearchParams,hash:``,params:{},branch:[],url:new URL(T().location.href),navigationKey:``,direction:`none`};renderedBranches=new Map;scrollManager=new ln({maxPositions:50});validatedChildOutlets=new WeakMap;pendingChildOutletChecks=new Map;subscribedRouter;commitId=0;pendingCommitDetail;unregisterLeaveGuard;routerSubscribers=new Set;routeSubscribers=new Map;connectedCallback(){super.connectedCallback(),this.addEventListener(`context-request`,this.onContextRequest),this.scrollManager.acquireBrowserScrollRestoration(),this.setTransitionDirection(this.activeDetail.direction),this.setViewTransitionName(this.activeDetail.leaf?.viewTransitionName),this.connectRouter(),this.hasUpdated&&this.syncFromRouter(!1)}disconnectedCallback(){this.removeEventListener(`context-request`,this.onContextRequest),this.invalidatePendingCommits({clearRenderedElements:!0}),this.disconnectRouter(),this.scrollManager.releaseBrowserScrollRestoration(),this.routerSubscribers.clear(),this.routeSubscribers.clear(),super.disconnectedCallback()}firstUpdated(){this.syncFromRouter(!1)}updated(e){if(e.has(`router`)){let t=e.get(`router`);this.invalidatePendingCommits(),this.disconnectRouter(),t&&t!==this.router&&t.stop(),this.connectRouter(),this.syncFromRouter(!1)}e.has(`childSlot`)&&this.activeDetail.branch.length>0&&(this.renderedBranches.clear(),this.mountBranch(this.activeDetail))}shouldUpdate(){return!0}get current(){return this.activeDetail}get viewport(){return this.renderRoot.querySelector(`.viewport`)}getRenderRootActiveElement(){return`activeElement`in this.renderRoot?this.renderRoot.activeElement:null}push(e){this.router?.push(e)}replace(e){this.router?.replace(e)}back(){this.router?.back()}forward(){this.router?.forward()}go(e){this.router?.go(e)}resolve(e){return this.router?.resolve(e)??null}connectRouter(){this.router&&this.subscribedRouter!==this.router&&(this.router.start(),this.unregisterLeaveGuard=this.router.registerLeaveGuard(this.checkComponentLeaveGuards),this.router.addEventListener(`route-change`,this.onRouteChange),this.router.addEventListener(`route-error`,this.onRouteError),this.router.addEventListener(`route-not-found`,this.onRouteNotFound),this.subscribedRouter=this.router,this.notifyRouterSubscribers())}disconnectRouter(){this.unregisterLeaveGuard?.(),this.unregisterLeaveGuard=void 0,this.subscribedRouter&&=(this.subscribedRouter.removeEventListener(`route-change`,this.onRouteChange),this.subscribedRouter.removeEventListener(`route-error`,this.onRouteError),this.subscribedRouter.removeEventListener(`route-not-found`,this.onRouteNotFound),void 0)}checkComponentLeaveGuards=async e=>{let t=e,n=e.to,r=this.collectRenderedElementByRoute(),i=Ft(t,n);for(let t of i){if(e.signal.aborted)return!1;let n=r.get(t);if(!n)continue;let i=n;if(typeof i.beforeRouteLeave==`function`)try{let t=await i.beforeRouteLeave(e);if(t===!1||t&&t!==!0)return t}catch(e){return console.error(`[router-view] Component beforeRouteLeave threw an error`,e),!1}}return!0};getEffectiveDetail(){return this.pendingCommitDetail?this.pendingCommitDetail:this.activeDetail.branch.length>0?this.activeDetail:this.router&&this.router.current.branch.length>0?this.router.current:this.activeDetail}onContextRequest=e=>{let t=e;if(t.context===fn||typeof t.context==`object`&&t.context!==null&&`name`in t.context&&t.context.name===fn.name||t.context===fn.name)e.stopPropagation(),t.subscribe&&this.routerSubscribers.add(t.callback),this.router&&t.callback(this.router,()=>{this.routerSubscribers.delete(t.callback)});else if(t.context===pn||typeof t.context==`object`&&t.context!==null&&`name`in t.context&&t.context.name===pn.name||t.context===pn.name){e.stopPropagation();let n=this.getEffectiveDetail(),r=hn,i=(e.composedPath?e.composedPath():[])[0]??e.target;if(i){for(let[e,t]of this.renderedBranches)if(t.some(e=>e===i||e.contains(i))){r=e;break}}let a=r===`route-child`?n.branch:n.slotBranches?.[r]??n.branch,o=r===`route-child`?n.params:n.slotParams?.[r]??n.params,s;if(n.routeData)for(let e=a.length-1;e>=0;e--){let t=a[e];if(t&&n.routeData.has(t)){s=n.routeData.get(t);break}}s===void 0&&(s=n.data);let c={detail:n,params:o,slot:r,branch:a,data:s,meta:n.meta};t.subscribe&&this.routeSubscribers.set(t.callback,{element:i,slot:r}),t.callback(c,()=>{this.routeSubscribers.delete(t.callback)})}};notifyRouterSubscribers(){if(this.router)for(let e of this.routerSubscribers)e(this.router,()=>{this.routerSubscribers.delete(e)})}notifyRouteSubscribers(){let e=this.activeDetail;for(let[t,n]of this.routeSubscribers){if(n.element&&!n.element.isConnected){this.routeSubscribers.delete(t);continue}let r=n.slot;if(n.element){for(let[e,t]of this.renderedBranches)if(t.some(e=>e===n.element||e.contains(n.element))){r=e;break}}let i=r===`route-child`?e.branch:e.slotBranches?.[r]??e.branch,a=r===`route-child`?e.params:e.slotParams?.[r]??e.params,o;if(e.routeData)for(let t=i.length-1;t>=0;t--){let n=i[t];if(n&&e.routeData.has(n)){o=e.routeData.get(n);break}}o===void 0&&(o=e.data),t({detail:e,params:a,slot:r,branch:i,data:o,meta:e.meta},()=>{this.routeSubscribers.delete(t)})}}syncFromRouter(e){this.router&&(this.router.lastError?this.showRouteError(this.router.lastError):this.router.lastNotFound?this.showRouteNotFound(this.router.lastNotFound):this.router.current.branch.length!==0&&this.commitAndEmit(this.router.current,{skipTransition:!e}))}onRouteChange=e=>{this.commitAndEmit(e.detail,{captureCurrentScroll:!0})};onRouteError=e=>{this.showRouteError(e.detail),this.dispatchEvent(new CustomEvent(`route-error`,{detail:e.detail,bubbles:!0,composed:!0}))};onRouteNotFound=e=>{this.showRouteNotFound(e.detail),this.dispatchEvent(new CustomEvent(`route-not-found`,{detail:e.detail,bubbles:!0,composed:!0}))};dispatchCommitError(e,t){this.showRouteError({url:e.url,error:t,phase:`commit`,direction:e.direction}),this.dispatchEvent(new CustomEvent(`route-error`,{detail:{url:e.url,error:t,phase:`commit`,direction:e.direction},bubbles:!0,composed:!0})),console.error(`[router-view] Route commit failed`,t)}invalidatePendingCommits(e={}){this.commitId+=1,this.pendingChildOutletChecks.clear(),e.clearRenderedElements&&this.renderedBranches.clear()}commitAndEmit(e,t={}){t.captureCurrentScroll&&this.captureScrollPosition(this.activeDetail),this.commit(e,{skipTransition:t.skipTransition}).then(t=>{t&&this.dispatchRouteChange(e)}).catch(t=>{this.dispatchCommitError(e,t)})}dispatchRouteChange(e){this.notifyRouteSubscribers(),this.dispatchEvent(new CustomEvent(`route-change`,{detail:e,bubbles:!0,composed:!0}))}showRouteStage(){this.viewMode=`route`,this.routeErrorDetail=void 0,this.routeNotFoundDetail=void 0,this.requestUpdate()}showRouteNotFound(e){this.setTransitionDirection(e.direction),this.setViewTransitionName(),this.viewMode=`not-found`,this.routeNotFoundDetail=e,this.routeErrorDetail=void 0,this.requestUpdate(),this.focusFallbackAfterRender(`404`)}showRouteError(e){this.setTransitionDirection(e.direction),this.setViewTransitionName(),this.viewMode=`error`,this.routeErrorDetail=e,this.routeNotFoundDetail=void 0,this.requestUpdate(),this.focusFallbackAfterRender(`error`)}focusFallbackAfterRender(e){this.updateComplete.then(()=>{e===`404`&&this.viewMode!==`not-found`||e===`error`&&this.viewMode!==`error`||this.moveFocusIntoFallback(e)})}async commit(e,t={}){let n=e.leaf?.title,r=this.activeDetail,i=++this.commitId;this.pendingCommitDetail=e,this.setTransitionDirection(e.direction),this.setViewTransitionName(e.leaf?.viewTransitionName);try{let a=async()=>{if(this.isCommitStale(i)||(await this.updateComplete,this.isCommitStale(i)))return!1;let t=new Map(this.renderedBranches),n=this.getRenderRootActiveElement()??E().activeElement,a=this.mountBranch(e);return await this.waitForRouteElements(a),await this.validatePendingChildOutlets(),!this.isCommitStale(i)&&(this.activeDetail=e,this.showRouteStage(),this.restoreScrollPosition(e),this.moveFocusIntoRoute(e,r,t,n),!0)},o=!1;if(t.skipTransition||this.noViewTransition?o=await a():await this.runViewTransition(async()=>{o=await a()}),!o||this.isCommitStale(i))return!1;if(n){let t=typeof n==`function`?n(e):n;t&&(E().title=this.fillTitle(t,e.params))}return!0}finally{this.pendingCommitDetail===e&&(this.pendingCommitDetail=void 0)}}isCommitStale(e){return e!==this.commitId}setTransitionDirection(e){this.dataset.transitionDirection=e}setViewTransitionName(e){let t=e?.trim();t&&/^[A-Za-z_][A-Za-z0-9_-]*$/.test(t)?(this.style.setProperty(`--router-view-transition-name`,t),this.dataset.viewTransitionName=t):(this.style.removeProperty(`--router-view-transition-name`),delete this.dataset.viewTransitionName)}mountBranch(e){let t=this.viewport;if(!t)return[];if(e.branch.length===0)return t.replaceChildren(),t.dataset.path=e.pathname,this.renderedBranches.clear(),[];let n=this.collectRenderedElements(),r=this.collectRenderedElementByRoute(),i=new Map,a=new Map,o=new Set,s=[];this.mountRouteBranch({slotName:hn,branch:e.branch,detail:e,oldElementByRoute:r,nextElementByRoute:i,nextBranches:a,mountedElements:o,mountedList:s});let c=a.get(hn)?.[0];c&&t.firstElementChild!==c&&t.replaceChildren(c);for(let[t,n]of Object.entries(e.slotBranches??{}).sort(([e],[t])=>e.localeCompare(t)))this.mountRouteBranch({slotName:t,branch:n,detail:e,oldElementByRoute:r,nextElementByRoute:i,nextBranches:a,mountedElements:o,mountedList:s});for(let e of n.reverse())o.has(e)||e.remove();return t.dataset.path=e.pathname,this.renderedBranches=a,s}mountRouteBranch(e){let t=[],n=e.slotName===`route-child`?e.detail.params:e.detail.slotParams?.[e.slotName]??e.detail.slots?.[e.slotName]?.params??e.detail.params;for(let r=0;r<e.branch.length;r+=1){let i=e.branch[r],a=e.nextElementByRoute.get(i)??e.oldElementByRoute.get(i),o=!a,s=r===0?hn:this.routeSlot(i);if(a?e.nextElementByRoute.has(i)||this.applyRouteState(a,i,e.detail,s,e.branch,n):a=this.createRouteElement(i,e.detail,r,s,e.branch,n),a.setAttribute(`data-route-depth`,String(r)),e.nextElementByRoute.set(i,a),e.mountedElements.add(a),e.mountedList.includes(a)||e.mountedList.push(a),t.push(a),r===0)continue;let c=t[r-1];a.slot!==s&&(a.slot=s),(o||a.parentElement!==c)&&c.append(a),this.scheduleChildOutletValidation(c,e.branch[r-1],s)}e.nextBranches.set(e.slotName,t)}routeSlot(e){return e.slot?.trim()||this.childSlot}collectRenderedElements(){let e=[],t=new Set;for(let n of this.renderedBranches.values())for(let r of n)t.has(r)||(t.add(r),e.push(r));return e}collectRenderedElementByRoute(){let e=new Map;for(let[t,n]of this.renderedBranches){let r=t===`route-child`?this.activeDetail.branch:this.activeDetail.slotBranches?.[t]??[];for(let t=0;t<r.length;t+=1){let i=n[t];i&&!e.has(r[t])&&e.set(r[t],i)}}return e}createRouteElement(e,t,n,r,i,a){let o;return o=typeof e.component==`function`?e.component(t):typeof e.component==`string`?E().createElement(e.component):E().createElement(`section`),this.applyRouteState(o,e,t,r,i,a),o.setAttribute(`data-route-depth`,String(n)),o}applyRouteState(e,t,n,r,i,a){let o=n.routeData?.get(t);if(o===void 0&&t===i[i.length-1]){if(n.routeData)for(let e=i.length-1;e>=0;e--){let t=i[e];if(t&&n.routeData.has(t)){o=n.routeData.get(t);break}}o===void 0&&(o=n.data)}let s={detail:n,params:a,slot:r,branch:i,data:o,meta:n.meta},c=e;c.__lit_router_context=s;let l=()=>{Object.assign(e,t.props??{}),this.applyRouteContext(e,s,t)};l();let u=T().customElements;e.localName.includes(`-`)&&u&&!u.get(e.localName)&&u.whenDefined(e.localName).then(()=>{e.isConnected&&c.__lit_router_context===s&&l()})}applyRouteContext(e,t,n){let r=e;t.data===void 0?!r.__lit_router_data_set||n.props&&`data`in n.props||(r.data=void 0,r.__lit_router_data_set=!1):`data`in e&&(r.data=t.data,r.__lit_router_data_set=!0),typeof r.setRouteContext==`function`?r.setRouteContext(t):`routeContext`in r&&(r.routeContext=t)}async waitForRouteElements(e){await Promise.all(e.map(async e=>{await e.updateComplete}))}scheduleChildOutletValidation(e,t,n){if(this.validatedChildOutlets.get(e)?.has(n))return;let r=this.pendingChildOutletChecks.get(e);r||(r=new Map,this.pendingChildOutletChecks.set(e,r)),r.set(n,t)}async validatePendingChildOutlets(){let e=this.pendingChildOutletChecks;this.pendingChildOutletChecks=new Map;for(let[t,n]of e)for(let[e,r]of n)await this.validateChildOutlet(t,r,e)}async validateChildOutlet(e,t,n){if(this.validatedChildOutlets.get(e)?.has(n))return;let r=T().customElements;if(e.localName.includes(`-`)&&!r.get(e.localName)&&await r.whenDefined(e.localName),!e.isConnected)return;let i=this.validatedChildOutlets.get(e);if(i||(i=new Set,this.validatedChildOutlets.set(e,i)),i.add(n),!e.shadowRoot||Array.from(e.shadowRoot.querySelectorAll(`slot`)).find(e=>e.name===n))return;let a=t.name?`route "${t.name}"`:`path "${t.path||`/`}"`;console.warn(`[router-view] Parent component <${e.localName}> for ${a} is missing <slot name="${n}">, so nested routes cannot render into its shadow root.`)}async runViewTransition(e){let t=E();if(!t.startViewTransition){await e();return}let n=t.startViewTransition(()=>e());try{await(n.updateCallbackDone??n.finished)}finally{await n.finished.catch(()=>void 0)}}captureScrollPosition(e){this.scrollManager.capture(e.navigationKey,e.url)}restoreScrollPosition(e){this.scrollManager.restore(e.navigationKey,e.url)}moveFocusIntoRoute(e,t,n,r){let i=this.changedSideSlots(t,e);if(this.sameBranch(t.branch,e.branch)&&i.length>0){r&&this.focusWasInBranches(r,n,i)&&this.findBranchFocusTarget(i)?.focus();return}let a=this.viewport?.querySelector(`[data-route-focus]`);a?a.focus():(this.tabIndex=-1,this.focus())}changedSideSlots(e,t){let n=e.slotBranches??{},r=t.slotBranches??{};return[...new Set([...Object.keys(n),...Object.keys(r)])].filter(e=>!this.sameBranch(n[e]??[],r[e]??[])).sort()}sameBranch(e,t){return e.length===t.length&&e.every((e,n)=>e===t[n])}focusWasInBranches(e,t,n){for(let r of n)for(let n of t.get(r)??[])if(n===e||n.contains(e))return!0;return!1}findBranchFocusTarget(e){for(let t of e)for(let e of this.renderedBranches.get(t)??[]){if(e.hasAttribute(`data-route-focus`))return e;let t=e.querySelector(`[data-route-focus]`);if(t)return t}return null}moveFocusIntoFallback(e){let t=this.findAssignedFallbackFocusTarget(e);if(t){t.focus();return}let n=this.renderRoot.querySelector(`.fallback[data-fallback="${e}"]`),r=n?.querySelector(`[data-route-focus]`);r?r.focus():n&&(n.tabIndex=-1,n.focus())}findAssignedFallbackFocusTarget(e){let t=this.renderRoot.querySelector(`slot[name="${e}"]`);if(!t)return null;for(let e of t.assignedElements({flatten:!0})){if(!(e instanceof HTMLElement))continue;if(e.hasAttribute(`data-route-focus`))return e;let t=e.querySelector(`[data-route-focus]`);if(t)return t}return null}describeRouteError(e){return e instanceof Error&&e.message?e.message:typeof e==`string`&&e.trim()?e:`Unknown route error`}fillTitle(e,t){return e.replace(/:([A-Za-z0-9_-]+)/g,(e,n)=>t[n]??`:${n}`)}render(){let e=this.routeNotFoundDetail?.url.pathname??``,t=this.routeErrorDetail?.phase??`unknown`,n=this.describeRouteError(this.routeErrorDetail?.error);return g`
      <div class="viewport" ?hidden="${this.viewMode!==`route`}"></div>
      <section
        class="fallback"
        data-fallback="404"
        ?hidden="${this.viewMode!==`not-found`}"
      >
        <slot name="404">
          <article class="fallback-card">
            <p class="fallback-eyebrow">Route Not Found</p>
            <h1 data-route-focus tabindex="-1">404</h1>
            <p>No route matched <code>${e}</code>.</p>
          </article>
        </slot>
      </section>
      <section
        class="fallback"
        data-fallback="error"
        ?hidden="${this.viewMode!==`error`}"
      >
        <slot name="error">
          <article class="fallback-card">
            <p class="fallback-eyebrow">Route Error</p>
            <h1 data-route-focus tabindex="-1">Navigation Failed</h1>
            <p>
              The route transition failed during <code>${t}</code>.
            </p>
            <pre class="fallback-error">${n}</pre>
          </article>
        </slot>
      </section>
    `}static styles=o`
    :host {
      display: block;
      min-height: 100%;
      contain: content;
    }

    .viewport {
      min-height: 100%;
      view-transition-name: var(--router-view-transition-name, route-stage);
      outline: none;
    }

    .fallback[hidden],
    .viewport[hidden] {
      display: none;
    }

    .fallback {
      min-height: 100%;
      display: grid;
      place-items: center;
      padding: 2rem 1rem;
      outline: none;
    }

    .fallback-card {
      width: min(32rem, 100%);
      padding: 1.5rem;
      border: 1px solid color-mix(in srgb, currentColor 14%, transparent);
      border-radius: 1rem;
      background: color-mix(in srgb, canvas 92%, currentColor 8%);
      box-shadow: 0 1rem 2.5rem rgb(0 0 0 / 0.08);
    }

    .fallback-eyebrow {
      margin: 0 0 0.5rem;
      font-size: 0.8rem;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      opacity: 0.72;
    }

    .fallback-card h1 {
      margin: 0 0 0.75rem;
      font-size: clamp(2rem, 6vw, 3rem);
      line-height: 1;
      outline: none;
    }

    .fallback-card p {
      margin: 0;
      line-height: 1.55;
    }

    .fallback-error {
      margin: 1rem 0 0;
      padding: 0.75rem;
      border-radius: 0.75rem;
      overflow: auto;
      font: inherit;
      background: color-mix(in srgb, canvas 86%, currentColor 14%);
    }
  `};typeof customElements<`u`&&!customElements.get(`router-view`)&&customElements.define(`router-view`,gn);function _n(e){return e.tagName.toLowerCase()===`a`}function vn(e,t,n){if(!t)return;let r=t.trim().split(/\s+/).filter(Boolean);for(let t of r)n?e.classList.add(t):e.classList.remove(t)}function yn(e,t){if(e.defaultPrevented||e.button!==0||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey)return!1;let n=t.getAttribute(`target`);if(n&&n!==`_self`)return!1;let r=t.getAttribute(`rel`);if(r&&r.split(/\s+/).includes(`external`))return!1;let i=typeof e.composedPath==`function`?e.composedPath():[];if(i.length>0)for(let e of i){if(e instanceof Element&&(e.hasAttribute(`data-router-ignore`)||e.hasAttribute(`download`)||e.hasAttribute(`disabled`)||e.getAttribute(`aria-disabled`)===`true`))return!1;if(e===t)break}else{let n=e.target;for(;n&&n!==t.parentElement;){if(n.hasAttribute?.(`data-router-ignore`)||n.hasAttribute?.(`download`)||n.hasAttribute?.(`disabled`)||n.getAttribute?.(`aria-disabled`)===`true`)return!1;n=n.parentElement}}return!0}function bn(e,t){return typeof e==`object`&&e&&!(e instanceof URL)?{...e,params:e.params??t.params,query:e.query??t.query,hash:e.hash??t.hash}:e}var xn=class extends ot{element;router;target;options={};unsubscribeContext;listeningRouter;lastActiveClass;isExplicitRouter=!1;constructor(e,t){if(super(e),e.type!==Ze.ELEMENT)throw Error(`The \`${t}\` directive must be used on an element.`)}render(e,t,n){return v}update(e,t){this.element=e.element;let n,r,i;return t[0]instanceof on?(n=t[0],r=t[1],i=t[2]):(n=void 0,r=t[0],i=t[1]),this.target=r,this.options=i??{},n?(this.isExplicitRouter=!0,this.unsubscribeContext?.(),this.unsubscribeContext=void 0,this.setRouter(n)):(this.isExplicitRouter=!1,this.router?this.syncState():(this.seekRouter(),this.element.isConnected||queueMicrotask(()=>{!this.router&&this.element?.isConnected&&this.seekRouter()}))),v}seekRouter(){this.element&&(this.unsubscribeContext?.(),this.unsubscribeContext=mn(this.element,fn,e=>{this.setRouter(e)},!0))}setRouter(e){this.router===e?(this.attachRouterListener(),this.syncState()):(this.detachRouterListener(),this.router=e,this.attachRouterListener(),this.syncState())}attachRouterListener(){this.router&&this.listeningRouter!==this.router&&(this.router.addEventListener(`route-change`,this.onRouteChange),this.listeningRouter=this.router)}detachRouterListener(){this.listeningRouter&&=(this.listeningRouter.removeEventListener(`route-change`,this.onRouteChange),void 0)}onRouteChange=()=>{this.updateActiveStatus()};syncState(){this.updateActiveStatus()}getDefaultActiveClass(){}resolveIsActiveTarget(){return typeof this.target==`string`?this.target:bn(this.target,this.options)}updateActiveStatus(){let e=this.element;if(!e||!this.router||!this.target)return;let{activeClass:t=this.getDefaultActiveClass(),exact:n,ariaCurrent:r,params:i,query:a,hash:o}=this.options,s=_n(e),c=r!==void 0||s;if(!t&&!c&&!this.lastActiveClass)return;let l=this.router.isActive(this.resolveIsActiveTarget(),{exact:n,params:i,query:a,hash:o});if(this.lastActiveClass&&this.lastActiveClass!==t&&vn(e,this.lastActiveClass,!1),this.lastActiveClass=t,t&&vn(e,t,l),r===!1)e.removeAttribute(`aria-current`);else if(c){let t=typeof r==`string`?r:`page`;l?e.setAttribute(`aria-current`,t):e.removeAttribute(`aria-current`)}}disconnected(){this.element&&(this.lastActiveClass&&=(vn(this.element,this.lastActiveClass,!1),void 0),this.element.removeAttribute(`aria-current`)),this.detachRouterListener(),this.unsubscribeContext?.(),this.unsubscribeContext=void 0}reconnected(){this.element&&(!this.isExplicitRouter||!this.router)?this.seekRouter():this.router&&(this.attachRouterListener(),this.syncState())}},Sn=Qe(class extends xn{clickListeningElement;constructor(e){super(e,`routerLink`)}onClick=e=>{if(!this.element||!this.router||!this.target||!yn(e,this.element))return;e.preventDefault();let t=bn(this.target,this.options);this.options.replace?this.router.replace(t):this.router.push(t)};attachClickListener(e){this.clickListeningElement!==e&&(this.clickListeningElement?.removeEventListener(`click`,this.onClick),e.addEventListener(`click`,this.onClick),this.clickListeningElement=e)}syncState(){let e=this.element;if(e&&this.target){if(this.attachClickListener(e),this.options.assignHref===!0||this.options.assignHref!==!1&&_n(e)){let t=bn(this.target,this.options),n=this.router?this.router.link(t):typeof t==`string`?t:t instanceof URL?t.href:``;n&&e.setAttribute(`href`,n)}this.options.replace?e.setAttribute(`data-router-replace`,``):e.removeAttribute(`data-router-replace`),this.updateActiveStatus()}}resolveIsActiveTarget(){return bn(this.target,this.options)}disconnected(){this.clickListeningElement?.removeEventListener(`click`,this.onClick),this.clickListeningElement=void 0,super.disconnected()}}),Cn=class{constructor(){this.buffer=``}push(e){this.buffer+=e;let t=[],n=this.buffer.replace(/\r\n/g,`
`).split(`

`);this.buffer=n.pop()??``;for(let e of n){if(!e.trim())continue;let n=`message`,r,i=[];for(let t of e.split(`
`)){if(!t||t.startsWith(`:`))continue;let e=t.indexOf(`:`),a=e===-1?t:t.slice(0,e),o=e===-1?``:t.slice(e+1);o.startsWith(` `)&&(o=o.slice(1)),a===`event`?n=o||`message`:a===`data`?i.push(o):a===`id`&&(r=o)}i.length>0&&t.push({event:n,data:i.join(`
`),id:r})}return t}reset(){this.buffer=``}},wn=class{constructor(e){this.running=!1,this.controller=null,this.reconnectTimer=null,this.pollTimer=null,this.state=`connecting`,this.sseActive=!1,this.connGen=0,this.opts=e,this.baseBackoffMs=e.baseBackoffMs??1e3,this.maxBackoffMs=e.maxBackoffMs??15e3,this.pollIntervalMs=e.pollIntervalMs??2500,this.backoffMs=this.baseBackoffMs}start(){this.running||(this.running=!0,this.backoffMs=this.baseBackoffMs,this.setState(`connecting`),this.connectLoop())}restart(){this.stop(),this.start()}stop(){this.running=!1,this.sseActive=!1,this.connGen++,this.clearTimers(),this.controller&&=(this.controller.abort(),null)}setState(e){this.state!==e&&(this.state=e,this.opts.onState(e))}clearTimers(){this.reconnectTimer!==null&&(clearTimeout(this.reconnectTimer),this.reconnectTimer=null),this.pollTimer!==null&&(clearInterval(this.pollTimer),this.pollTimer=null)}startPollingFallback(){if(this.pollTimer!==null||!this.running)return;let e=async()=>{if(this.running&&!this.sseActive)try{await this.opts.pollFallback(),this.running&&!this.sseActive&&this.setState(`polling`)}catch(e){if(!this.running||this.sseActive)return;let t=e?.status;if(t===401){this.handleUnauthorized();return}this.setState(`offline`),this.opts.onError?.(e instanceof Error?e.message:String(e),t)}};e(),this.pollTimer=setInterval(()=>void e(),this.pollIntervalMs)}stopPollingFallback(){this.pollTimer!==null&&(clearInterval(this.pollTimer),this.pollTimer=null)}handleUnauthorized(){this.sseActive=!1,this.clearTimers(),this.controller&&=(this.controller.abort(),null),this.setState(`unauthorized`),this.opts.onUnauthorized?.()}scheduleReconnect(){if(!this.running||this.state===`unauthorized`)return;let e=this.backoffMs;this.backoffMs=Math.min(this.maxBackoffMs,this.backoffMs*2),this.reconnectTimer=setTimeout(()=>{this.reconnectTimer=null,this.running&&this.connectLoop()},e)}async connectLoop(){if(!this.running)return;let e=++this.connGen;this.controller=new AbortController;let{signal:t}=this.controller,n=new Headers({Accept:`text/event-stream`}),r=this.opts.getToken();r&&n.set(`Authorization`,`Bearer ${r}`);let i=null;try{let r=await fetch(this.opts.buildUrl(),{method:`GET`,headers:n,cache:`no-store`,signal:t});if(!this.running||e!==this.connGen)return;if(r.status===401){this.handleUnauthorized();return}let a=r.headers.get(`content-type`)??``;if(!r.ok||!r.body||!a.includes(`text/event-stream`))throw Object.assign(Error(`SSE unavailable (HTTP ${r.status})`),{status:r.status});this.stopPollingFallback(),this.backoffMs=this.baseBackoffMs,this.sseActive=!0,this.setState(`live`),i=r.body.getReader();let o=new TextDecoder,s=new Cn;for(;this.running&&e===this.connGen;){let{done:t,value:n}=await i.read();if(t||!this.running||e!==this.connGen)break;let r=o.decode(n,{stream:!0});for(let t of s.push(r)){if(!this.running||e!==this.connGen)break;let n=this.opts.parseFrame(t);n!==null&&this.opts.onData(n)}}if(e!==this.connGen)return;this.sseActive=!1,this.running&&(this.startPollingFallback(),this.scheduleReconnect())}catch(n){if(e!==this.connGen||(this.sseActive=!1,!this.running||t.aborted))return;if(n?.status===401){this.handleUnauthorized();return}this.startPollingFallback(),this.scheduleReconnect()}finally{i&&i.cancel().catch(()=>{})}}},Tn=`nexus_control_bearer_token`,En=new EventTarget,Dn=class extends Error{constructor(e,t,n=`http-error`){super(e),this.name=`ApiError`,this.status=t,this.code=n}};function M(){if(typeof window>`u`)return``;try{return window.sessionStorage.getItem(Tn)??``}catch{return``}}function On(e){if(typeof window<`u`)try{let t=e.trim();t?window.sessionStorage.setItem(Tn,t):window.sessionStorage.removeItem(Tn)}catch{}En.dispatchEvent(new CustomEvent(`token-changed`))}function kn(){En.dispatchEvent(new CustomEvent(`unauthorized`))}function An(e,t){return En.addEventListener(e,t),()=>En.removeEventListener(e,t)}function N(e){let t=typeof e==`string`?Number(e):e;return!Number.isFinite(t)||t<=0?`0 B`:t<1024?`${Math.round(t)} B`:t<1048576?`${(t/1024).toFixed(1)} KiB`:t<1073741824?`${(t/1048576).toFixed(2)} MiB`:`${(t/1073741824).toFixed(2)} GiB`}function P(e){return`${N(e)}/s`}function jn(e){if(!Number.isFinite(e)||e<0)return`0ms`;if(e<1e3)return`${Math.round(e)}ms`;let t=Math.floor(e/1e3);if(t<60)return`${t}s`;let n=Math.floor(t/60),r=t%60;return n<60?`${n}m ${r}s`:`${Math.floor(n/60)}h ${n%60}m`}function Mn(e){if(!Number.isFinite(e)||e<=0)return`--:--:--`;let t=e>0x5af3107a4000?Math.floor(e/1e6):e>1e11?e:e*1e3,n=new Date(t);if(Number.isNaN(n.getTime()))return`--:--:--`;let r=e=>String(e).padStart(2,`0`);return`${r(n.getHours())}:${r(n.getMinutes())}:${r(n.getSeconds())}`}function Nn(e,t){let n=(t??``).toLowerCase();return e==null||e<=0?n===`down`||n===`timeout`||n===`unreachable`||n===`error`||n===`failed`?`down`:`unprobed`:e<80?`fast`:e<180?`good`:e<350?`mid`:`slow`}function Pn(e){return e==null||e<=0?0:e<80?4:e<180?3:e<350?2:1}function Fn(e){return e.map(([e,t])=>`${encodeURIComponent(e)}=${encodeURIComponent(t)}`).join(`&`)}function In(e){let t=[[`name`,e.name.trim()]];return e.type&&t.push([`type`,e.type.trim().toUpperCase()]),e.server?.trim()&&t.push([`server`,e.server.trim()]),`/v1/dns/query?${Fn(t)}`}function Ln(e,t=!1){let n=[];return t&&n.push([`stream`,`1`]),e.level&&e.level!==`all`&&n.push([`level`,e.level]),e.domain&&e.domain!==`all`&&n.push([`domain`,e.domain]),e.search?.trim()&&n.push([`search`,e.search.trim()]),e.since!==void 0&&e.since>0&&n.push([`since`,String(e.since)]),t||n.push([`limit`,String(e.limit??250)]),`/v1/logs?${Fn(n)}`}async function Rn(e,t={}){let n=new Headers(t.headers??{}),r=M();r&&n.set(`Authorization`,`Bearer ${r}`),t.body&&!n.has(`Content-Type`)&&n.set(`Content-Type`,`application/json`);let i=await fetch(e,{...t,headers:n,cache:`no-store`});return i.status===401&&kn(),i}async function F(e,t={}){let n=await Rn(e,t),r=await n.text();if(!n.ok){let e=r.trim()||`HTTP ${n.status}`,t=`http-${n.status}`;try{let n=JSON.parse(r);typeof n?.error==`string`?e=n.error:n?.error?.message&&(t=n.error.code??t,e=n.error.code?`${n.error.code}: ${n.error.message}`:n.error.message)}catch{}throw new Dn(e,n.status,t)}return r?JSON.parse(r):{}}var I={health:()=>F(`/v1/health`),status:()=>F(`/v1/status`),mode:()=>F(`/v1/mode`),setMode:(e,t)=>F(`/v1/mode`,{method:`PUT`,body:JSON.stringify(t?{mode:e,outbound:t}:{mode:e})}),outbounds:()=>F(`/v1/outbounds`),selectGroup:(e,t)=>F(`/v1/groups/${encodeURIComponent(e)}`,{method:`PUT`,body:JSON.stringify({member:t})}),probeGroup:e=>F(`/v1/groups/${encodeURIComponent(e)}/probe`,{method:`POST`,body:`{}`}),probeOutbound:(e,t={})=>F(`/v1/outbounds/${encodeURIComponent(e)}/probe`,{method:`POST`,body:JSON.stringify(t)}),rules:()=>F(`/v1/rules`),dnsQuery:e=>F(In(e)),flushFakeIp:()=>F(`/v1/cache/fakeip/flush`,{method:`POST`,body:`{}`}),clearCache:(e=`all`)=>F(`/v1/state/clear-cache`,{method:`POST`,body:JSON.stringify({target:e})}),connections:()=>F(`/v1/connections`),connectionDetail:e=>F(`/v1/connections/${encodeURIComponent(e)}`),closeConnection:e=>F(`/v1/connections/${encodeURIComponent(e)}`,{method:`DELETE`}),closeAllConnections:()=>F(`/v1/connections`,{method:`DELETE`}),logs:e=>F(Ln(e,!1)),setLogLevel:(e,t=`global`)=>F(`/v1/log-level`,{method:`POST`,body:JSON.stringify({domain:t,level:e})}),diagnostics:()=>F(`/v1/diagnostics`),events:(e=0)=>F(`/v1/events?cursor=${Math.max(0,e)}`),reload:()=>F(`/v1/reload`,{method:`POST`,body:`{}`}),networkChange:()=>F(`/v1/network-change`,{method:`POST`,body:`{}`}),metricsText:async()=>{let e=await Rn(`/metrics`),t=await e.text();if(!e.ok)throw new Dn(t.trim()||`HTTP ${e.status}`,e.status);return t},ssmapiUsers:()=>F(`/ssmapi/users`),ssmapiStats:()=>F(`/ssmapi/stats`)};function zn(e,t,n,r=1500){return new wn({buildUrl:()=>`/v1/status?stream=1&interval_ms=${r}`,getToken:M,parseFrame:e=>{if(e.event!==`status`&&e.event!==`message`)return null;try{return JSON.parse(e.data)}catch{return null}},onData:e,onState:t,onError:n,onUnauthorized:kn,pollFallback:async()=>e(await I.status()),pollIntervalMs:Math.max(2e3,r)})}function Bn(e,t,n,r=2e3){return new wn({buildUrl:()=>`/v1/connections?stream=1&interval_ms=${r}`,getToken:M,parseFrame:e=>{if(e.event!==`connections`&&e.event!==`message`)return null;try{return JSON.parse(e.data).connections??[]}catch{return null}},onData:e,onState:t,onError:n,onUnauthorized:kn,pollFallback:async()=>{e((await I.connections()).connections??[])},pollIntervalMs:Math.max(2500,r)})}function Vn(e,t,n,r,i){return new wn({buildUrl:()=>Ln(e(),!0),getToken:M,parseFrame:e=>{if(e.event!==`log`&&e.event!==`message`)return null;try{return JSON.parse(e.data)}catch{return null}},onData:t,onState:r,onError:i,onUnauthorized:kn,pollFallback:async()=>{let t=e();n(await I.logs({...t,limit:250}))},pollIntervalMs:2e3})}function L(e,t=16){return _`<svg width="${t}" height="${t}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${e}</svg>`}var R={overview:()=>L(_`<rect x="3" y="3" width="7" height="9" rx="2"/><rect x="14" y="3" width="7" height="5" rx="2"/><rect x="14" y="12" width="7" height="9" rx="2"/><rect x="3" y="16" width="7" height="5" rx="2"/>`),outbounds:()=>L(_`<circle cx="6" cy="6" r="3"/><circle cx="18" cy="6" r="3"/><circle cx="12" cy="18" r="3"/><path d="M8.5 7.5 11 15M15.5 7.5 13 15"/>`),connections:()=>L(_`<path d="M7 16V4m0 0-3 3m3-3 3 3M17 8v12m0 0 3-3m-3 3-3-3"/>`),rules:()=>L(_`<path d="M4 6h16M4 12h10M4 18h7"/><circle cx="18" cy="15" r="3"/><path d="m20.5 17.5 1.5 1.5"/>`),logs:()=>L(_`<path d="M4 5h16a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1Z"/><path d="m7 9 3 3-3 3m5 0h5"/>`),diagnostics:()=>L(_`<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/>`),refresh:()=>L(_`<path d="M21 12a9 9 0 1 1-2.64-6.36"/><path d="M21 3v6h-6"/>`,15),bolt:()=>L(_`<path d="M13 2 3 14h9l-1 8 10-12h-9l1-8Z"/>`,14),sun:()=>L(_`<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.93 4.93l1.41 1.41m11.32 11.32 1.41 1.41M2 12h2m16 0h2M4.93 19.07l1.41-1.41m11.32-11.32 1.41-1.41"/>`,15),moon:()=>L(_`<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79Z"/>`,15),globe:()=>L(_`<circle cx="12" cy="12" r="9"/><path d="M3.6 9h16.8M3.6 15h16.8M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>`,15),lock:()=>L(_`<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>`,15),search:()=>L(_`<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>`,15),copy:()=>L(_`<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>`,14),download:()=>L(_`<path d="M12 3v12m0 0-4-4m4 4 4-4M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2"/>`,14),trash:()=>L(_`<path d="M3 6h18M8 6V4h8v2m-9 0 1 14h8l1-14"/>`,14),pause:()=>L(_`<rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>`,14),play:()=>L(_`<polygon points="6 4 20 12 6 20 6 4"/>`,14),close:()=>L(_`<path d="M18 6 6 18M6 6l12 12"/>`,15)},Hn=`nexus_web_lang`,Un=new EventTarget,Wn={"app.subtitle":`Control Plane Console`,"nav.overview":`Overview`,"nav.outbounds":`Outbounds`,"nav.connections":`Connections`,"nav.rules":`Rules & DNS`,"nav.logs":`Logs`,"nav.diagnostics":`Diagnostics`,"nav.mainLabel":`Main navigation`,"stream.live":`LIVE SSE`,"stream.liveWs":`LIVE WS`,"stream.polling":`POLLING`,"stream.connecting":`CONNECTING`,"stream.unauthorized":`AUTH NEEDED`,"stream.offline":`OFFLINE`,"theme.dark":`Dark`,"theme.light":`Light`,"theme.system":`Auto`,"auth.title":`Bearer Token Authentication`,"auth.banner":`Authentication required (HTTP 401). Configure your Bearer token to connect.`,"auth.desc":`Sent strictly via the HTTP Authorization header and kept only in this browser tab session (never in URL query strings).`,"auth.placeholder":`Enter control plane bearer token…`,"auth.tokenLabel":`Control plane bearer token`,"auth.openConfig":`Configure Token`,"auth.save":`Verify & Save`,"auth.clear":`Clear`,"auth.close":`Close`,"auth.configure":`Token`,"auth.verified":`Authenticated with instance {instance}.`,"auth.cleared":`Session token cleared.`,"auth.failed":`Auth check failed: {error}`,"common.refresh":`Refresh`,"common.search":`Search…`,"common.clearFilters":`Clear filters`,"common.all":`All`,"common.copy":`Copy`,"common.copied":`Copied`,"common.close":`Close`,"common.dismiss":`Dismiss`,"common.on":`ON`,"common.off":`OFF`,"common.cancel":`Cancel`,"common.confirm":`Confirm`,"common.pause":`Pause`,"common.resume":`Resume`,"common.export":`Export`,"common.empty":`No data available`,"overview.title":`System Overview`,"overview.heroRunning":`Core Running`,"overview.instance":`Instance`,"overview.gen":`Gen`,"overview.mode":`Route Mode`,"overview.mode.rule":`Rule`,"overview.mode.global":`Global`,"overview.mode.direct":`Direct`,"overview.reload":`Reload Config`,"overview.flushFakeip":`Flush FakeIP`,"overview.clearDns":`Clear DNS`,"overview.download":`Download`,"overview.upload":`Upload`,"overview.total":`Total`,"overview.sessions":`Active Sessions`,"overview.listeners":`Listeners`,"overview.workers":`Workers`,"overview.controlGen":`Control Gen`,"overview.peakCard":`Peak Rate`,"overview.throughput":`Real-Time Throughput`,"overview.peak":`Peak`,"overview.quickGroups":`Strategy Groups Quick Switch`,"overview.noGroups":`No selector, url-test, or fallback groups declared.`,"overview.reloaded":`Configuration reload queued.`,"overview.flushedFakeip":`Flushed {count} unpinned FakeIP entries.`,"overview.clearedDns":`DNS cache cleared.`,"overview.modeUpdated":`Route mode switched to {mode}.`,"outbounds.title":`Outbounds & Strategy Groups`,"outbounds.groups":`Groups`,"outbounds.nodes":`Members`,"outbounds.search":`Filter nodes by name or state…`,"outbounds.noMatch":`No nodes match the current filter.`,"outbounds.sort.default":`Order: Config`,"outbounds.sort.latency":`Order: Latency`,"outbounds.sort.name":`Order: Name`,"outbounds.sortLabel":`Sort nodes`,"outbounds.probeGroup":`Probe Group`,"outbounds.probeNode":`Probe`,"outbounds.probing":`Probing…`,"outbounds.resetAuto":`Restore Auto`,"outbounds.override":`Manual Override`,"outbounds.selected":`Active`,"outbounds.breaker":`Breaker Open`,"outbounds.unprobed":`Unprobed`,"outbounds.down":`Down`,"outbounds.empty":`No outbound strategy groups configured.`,"outbounds.groupProbed":`Triggered background probe for {group}.`,"outbounds.nodeProbed":`{node}: {state}{rtt}`,"connections.title":`Active Connections`,"connections.search":`Filter host, IP, process, outbound, rule, or ID…`,"connections.sort.bytes":`Sort: Total Traffic`,"connections.sort.down":`Sort: Download`,"connections.sort.up":`Sort: Upload`,"connections.sort.duration":`Sort: Duration`,"connections.sort.newest":`Sort: Newest`,"connections.sortLabel":`Sort connections`,"connections.closeAll":`Close All`,"connections.closeFiltered":`Close Filtered ({count})`,"connections.confirmAll":`Confirm Close All ({count})?`,"connections.confirmFiltered":`Confirm Close {count}?`,"connections.col.id":`ID`,"connections.col.inbound":`Inbound / Proto`,"connections.col.target":`Target`,"connections.col.outbound":`Outbound`,"connections.col.rule":`Rule`,"connections.col.traffic":`Traffic (↑ / ↓)`,"connections.col.duration":`Duration`,"connections.col.action":`Action`,"connections.closeOne":`Close`,"connections.detail":`Connection Inspector`,"connections.detail.source":`Source`,"connections.detail.process":`Process`,"connections.detail.uidDuration":`UID / Duration`,"connections.empty":`No active connections matching filter.`,"connections.closedCount":`Closed {count} connection(s).`,"rules.title":`Routing Rules & Live DNS`,"rules.tableTitle":`Active Routing Rules`,"rules.search":`Search rule type, action, target, or summary…`,"rules.col.index":`#`,"rules.col.type":`Type`,"rules.col.action":`Action`,"rules.col.target":`Target`,"rules.col.summary":`Matcher Summary`,"rules.empty":`No routing rules match the current filter.`,"rules.services":`Services & Telemetry`,"rules.ssmapi":`SS-2022 Multi-User Metering (ssmapi)`,"rules.ssmapiOff":`ssmapi endpoint is not enabled on this instance.`,"rules.users":`Users`,"dns.title":`Live DNS Query & Cache Control`,"dns.domainPlaceholder":`Domain name (e.g. example.com)`,"dns.domainLabel":`DNS domain name`,"dns.serverPlaceholder":`Server tag (optional)`,"dns.serverLabel":`DNS server tag (optional)`,"dns.query":`Query DNS`,"dns.querying":`Querying…`,"dns.typeLabel":`DNS record type`,"dns.col.name":`Name`,"dns.col.type":`Type`,"dns.col.ttl":`TTL`,"dns.col.data":`Data`,"dns.answers":`Answers`,"dns.noAnswers":`No answer records returned.`,"dns.cacheAll":`Clear All Cache`,"dns.confirmClearAll":`Confirm Clear All?`,"dns.cacheDns":`Clear DNS Cache`,"dns.cacheRules":`Clear Rulesets`,"dns.flushFakeip":`Flush FakeIP`,"dns.recent":`Recent`,"logs.title":`Live Log Stream`,"logs.search":`Search domain, rule, or message…`,"logs.autoscroll":`Auto-scroll`,"logs.domainPrefix":`Domain: {domain}`,"logs.domainLabel":`Filter log domain`,"logs.coreLevel":`Set Core Level`,"logs.coreLevelLabel":`Set core log level`,"logs.levelApplied":`Core log level ({domain}) set to {level}.`,"logs.empty":`No matching log entries.`,"logs.evicted":`Evicted`,"logs.latest":`Latest`,"diag.title":`Diagnostics & Auth`,"diag.copyJson":`Copy JSON Report`,"diag.networkChange":`Notify Network Change`,"diag.authorized":`Authorized Requests`,"diag.unauthorized":`Unauthorized Denied`,"diag.expired":`Expired / Reply Failed`,"diag.timeoutReply":`Timeout / Reply err`,"diag.sessionStorageOnly":`Tab session only`,"diag.listenersConn":`Listeners / Active Conns`,"diag.events":`Control Plane Event Log`,"diag.col.id":`ID`,"diag.col.event":`Event`,"diag.col.gen":`Gen`,"diag.summary":`Summary`,"diag.raw":`Raw`,"diag.noEvents":`No control-plane events recorded yet.`,"diag.metrics":`OpenMetrics Telemetry`,"diag.metricsOff":`OpenMetrics endpoint is disabled on this instance.`,"diag.networkNotified":`Network change event dispatched.`,"shortcuts.hint":`Keys: 1-6 Nav · / Search · R Refresh`},Gn={en:Wn,zh:{"app.subtitle":`控制面 Web 控制台`,"nav.overview":`概览`,"nav.outbounds":`策略组`,"nav.connections":`活跃连接`,"nav.rules":`规则与 DNS`,"nav.logs":`运行日志`,"nav.diagnostics":`诊断与鉴权`,"nav.mainLabel":`主导航`,"stream.live":`SSE 实时`,"stream.liveWs":`WS 实时`,"stream.polling":`轮询降级`,"stream.connecting":`连接中`,"stream.unauthorized":`需要鉴权`,"stream.offline":`离线`,"theme.dark":`深色`,"theme.light":`浅色`,"theme.system":`自动`,"auth.title":`Bearer 令牌鉴权`,"auth.banner":`需要鉴权 (HTTP 401)，请配置控制面 Bearer 令牌以连接核心。`,"auth.desc":`严格通过 HTTP Authorization 请求头发送，仅保留于当前浏览器标签页会话，绝不写入 URL 查询串。`,"auth.placeholder":`输入控制面 Bearer 令牌…`,"auth.tokenLabel":`控制面 Bearer 令牌`,"auth.openConfig":`配置令牌`,"auth.save":`校验并保存`,"auth.clear":`清除`,"auth.close":`关闭`,"auth.configure":`令牌`,"auth.verified":`鉴权成功，已连接实例 {instance}。`,"auth.cleared":`已清除当前会话令牌。`,"auth.failed":`鉴权失败：{error}`,"common.refresh":`刷新`,"common.search":`搜索…`,"common.clearFilters":`重置筛选`,"common.all":`全部`,"common.copy":`复制`,"common.copied":`已复制`,"common.close":`关闭`,"common.dismiss":`关闭提示`,"common.on":`启用`,"common.off":`关闭`,"common.cancel":`取消`,"common.confirm":`确认`,"common.pause":`暂停`,"common.resume":`恢复`,"common.export":`导出`,"common.empty":`暂无数据`,"overview.title":`系统概览`,"overview.heroRunning":`核心运行中`,"overview.instance":`实例`,"overview.gen":`代次`,"overview.mode":`路由模式`,"overview.mode.rule":`规则`,"overview.mode.global":`全局`,"overview.mode.direct":`直连`,"overview.reload":`热重载配置`,"overview.flushFakeip":`清空 FakeIP`,"overview.clearDns":`清空 DNS`,"overview.download":`实时下行`,"overview.upload":`实时上行`,"overview.total":`累计`,"overview.sessions":`活跃会话`,"overview.listeners":`监听端口`,"overview.workers":`工作线程`,"overview.controlGen":`控制代次`,"overview.peakCard":`峰值速率`,"overview.throughput":`实时吞吐趋势`,"overview.peak":`峰值`,"overview.quickGroups":`策略组快速切换`,"overview.noGroups":`当前配置未声明 selector / url-test / fallback 策略组。`,"overview.reloaded":`已提交配置热重载请求。`,"overview.flushedFakeip":`已清理 {count} 条未固定 FakeIP 映射。`,"overview.clearedDns":`已清空 DNS 缓存。`,"overview.modeUpdated":`路由模式已切换为 {mode}。`,"outbounds.title":`出站与策略组`,"outbounds.groups":`策略组`,"outbounds.nodes":`节点列表`,"outbounds.search":`按节点名称或状态过滤…`,"outbounds.noMatch":`暂无匹配的节点。`,"outbounds.sort.default":`排序：默认`,"outbounds.sort.latency":`排序：延迟升序`,"outbounds.sort.name":`排序：名称`,"outbounds.sortLabel":`节点排序`,"outbounds.probeGroup":`整组测速`,"outbounds.probeNode":`测速`,"outbounds.probing":`测速中…`,"outbounds.resetAuto":`恢复自动`,"outbounds.override":`手动覆盖`,"outbounds.selected":`当前选中`,"outbounds.breaker":`已熔断`,"outbounds.unprobed":`未探测`,"outbounds.down":`不可达`,"outbounds.empty":`当前配置未声明出站策略组。`,"outbounds.groupProbed":`已触发策略组 {group} 后台测速。`,"outbounds.nodeProbed":`{node}：{state}{rtt}`,"connections.title":`活跃连接`,"connections.search":`过滤域名、IP、进程、出站、规则或 ID…`,"connections.sort.bytes":`排序：总流量`,"connections.sort.down":`排序：下行流量`,"connections.sort.up":`排序：上行流量`,"connections.sort.duration":`排序：持续时间`,"connections.sort.newest":`排序：最新建立`,"connections.sortLabel":`连接排序`,"connections.closeAll":`断开全部`,"connections.closeFiltered":`断开筛选 ({count})`,"connections.confirmAll":`确认断开全部 {count} 条？`,"connections.confirmFiltered":`确认断开 {count} 条？`,"connections.col.id":`ID`,"connections.col.inbound":`入站 / 协议`,"connections.col.target":`目标地址`,"connections.col.outbound":`出站`,"connections.col.rule":`命中规则`,"connections.col.traffic":`流量 (↑ / ↓)`,"connections.col.duration":`时长`,"connections.col.action":`操作`,"connections.closeOne":`断开`,"connections.detail":`连接详情检视`,"connections.detail.source":`来源`,"connections.detail.process":`进程`,"connections.detail.uidDuration":`UID / 时长`,"connections.empty":`暂无匹配的活跃连接。`,"connections.closedCount":`已断开 {count} 条连接。`,"rules.title":`路由规则与实时 DNS`,"rules.tableTitle":`生效路由规则表`,"rules.search":`搜索规则类型、动作、目标出站或条件摘要…`,"rules.col.index":`#`,"rules.col.type":`类型`,"rules.col.action":`动作`,"rules.col.target":`目标`,"rules.col.summary":`匹配条件摘要`,"rules.empty":`暂无匹配的路由规则。`,"rules.services":`扩展服务与计量`,"rules.ssmapi":`SS-2022 多用户计量 (ssmapi)`,"rules.ssmapiOff":`当前实例未启用 ssmapi 接口。`,"rules.users":`用户数`,"dns.title":`实时 DNS 查询与缓存控制`,"dns.domainPlaceholder":`输入查询域名（例如 example.com）`,"dns.domainLabel":`DNS 查询域名`,"dns.serverPlaceholder":`指定 DNS 服务器标签（可选）`,"dns.serverLabel":`DNS 服务器标签（可选）`,"dns.query":`发起查询`,"dns.querying":`查询中…`,"dns.typeLabel":`DNS 记录类型`,"dns.col.name":`域名`,"dns.col.type":`类型`,"dns.col.ttl":`TTL`,"dns.col.data":`记录值`,"dns.answers":`应答记录`,"dns.noAnswers":`未返回应答记录。`,"dns.cacheAll":`清空全部缓存`,"dns.confirmClearAll":`确认清空全部缓存？`,"dns.cacheDns":`清空 DNS 缓存`,"dns.cacheRules":`清空规则集缓存`,"dns.flushFakeip":`清空 FakeIP`,"dns.recent":`最近查询`,"logs.title":`实时运行日志`,"logs.search":`搜索域名、规则或日志内容…`,"logs.autoscroll":`自动滚动`,"logs.domainPrefix":`域：{domain}`,"logs.domainLabel":`过滤日志域`,"logs.coreLevel":`设置核心级别`,"logs.coreLevelLabel":`调整核心日志级别`,"logs.levelApplied":`核心日志级别（{domain}）已设为 {level}。`,"logs.empty":`暂无匹配的日志记录。`,"logs.evicted":`已淘汰`,"logs.latest":`最新`,"diag.title":`诊断与鉴权`,"diag.copyJson":`复制 JSON 报告`,"diag.networkChange":`触发网络切换事件`,"diag.authorized":`已授权请求`,"diag.unauthorized":`已拒绝未授权`,"diag.expired":`超时 / 应答失败`,"diag.timeoutReply":`超时 / 应答失败`,"diag.sessionStorageOnly":`仅限当前标签页`,"diag.listenersConn":`监听数 / 活跃连接`,"diag.events":`控制面事件记录`,"diag.col.id":`ID`,"diag.col.event":`事件`,"diag.col.gen":`代次`,"diag.summary":`摘要`,"diag.raw":`原始文本`,"diag.noEvents":`暂无控制面事件记录。`,"diag.metrics":`OpenMetrics 指标`,"diag.metricsOff":`当前实例未启用 OpenMetrics 指标端点。`,"diag.networkNotified":`已发送网络切换刷新信号。`,"shortcuts.hint":`快捷键：1-6 切换 · / 搜索 · R 刷新`}};function Kn(){if(typeof window<`u`)try{let e=window.localStorage.getItem(Hn);if(e===`en`||e===`zh`)return e}catch{}return typeof navigator<`u`&&navigator.language?.toLowerCase().startsWith(`zh`)?`zh`:`en`}var z=Kn();function qn(){typeof document<`u`&&(document.documentElement.lang=z===`zh`?`zh-CN`:`en`)}qn();function Jn(){return z}function Yn(e){if(z!==e){if(z=e,typeof window<`u`)try{window.localStorage.setItem(Hn,e)}catch{}qn(),Un.dispatchEvent(new CustomEvent(`locale-changed`,{detail:e}))}}function Xn(){let e=z===`zh`?`en`:`zh`;return Yn(e),e}function B(e){let t=()=>e(z);return Un.addEventListener(`locale-changed`,t),()=>Un.removeEventListener(`locale-changed`,t)}function V(e,t){let n=Gn[z][e]??Wn[e]??e;return t?n.replace(/\{(\w+)\}/g,(e,n)=>t[n]===void 0?`{${n}}`:String(t[n])):n}var Zn=o`
  :host,
  :host([data-theme='dark']) {
    color-scheme: dark;
    --nx-bg: #111317;
    --nx-sidebar: #14171d;
    --nx-surface: #191c22;
    --nx-well: #20242c;
    --nx-inset: #20242c;
    --nx-row-hover: #252a34;
    --nx-overlay: #191c22;
    --nx-scrim: rgba(9, 11, 16, 0.68);
    --nx-border: #262a33;
    --nx-border-strong: #323744;
    --nx-modal-shadow: 0 16px 40px rgba(0, 0, 0, 0.52);

    --nx-text: #eceff4;
    --nx-text-secondary: #b8c0ce;
    --nx-muted: #9aa3b2;

    --nx-accent: #2563eb;
    --nx-accent-text: #60a5fa;
    --nx-accent-hover: #1d4ed8;
    --nx-accent-soft: rgba(59, 130, 246, 0.16);
    --nx-accent-border: rgba(59, 130, 246, 0.45);
    --nx-accent-fg: #ffffff;

    --nx-down: #38bdf8;
    --nx-up: #c084fc;

    --nx-ok-fg: #22c55e;
    --nx-ok-bg: rgba(34, 197, 94, 0.14);
    --nx-ok-border: rgba(34, 197, 94, 0.34);

    --nx-warn-fg: #f59e0b;
    --nx-warn-bg: rgba(245, 158, 11, 0.14);
    --nx-warn-border: rgba(245, 158, 11, 0.34);

    --nx-err-fg: #f87171;
    --nx-err-bg: rgba(239, 68, 68, 0.14);
    --nx-err-border: rgba(239, 68, 68, 0.36);

    --nx-lat-fast-fg: #22c55e;
    --nx-lat-fast-bg: rgba(34, 197, 94, 0.14);
    --nx-lat-good-fg: #2dd4bf;
    --nx-lat-good-bg: rgba(20, 184, 166, 0.14);
    --nx-lat-mid-fg: #f59e0b;
    --nx-lat-mid-bg: rgba(245, 158, 11, 0.14);
    --nx-lat-slow-fg: #fb923c;
    --nx-lat-slow-bg: rgba(249, 115, 22, 0.15);
    --nx-lat-down-fg: #f87171;
    --nx-lat-down-bg: rgba(239, 68, 68, 0.14);
    --nx-lat-unprobed-fg: #9aa3b2;
    --nx-lat-unprobed-bg: #20242c;
  }

  :host([data-theme='light']) {
    color-scheme: light;
    --nx-bg: #f5f6f8;
    --nx-sidebar: #fafbfd;
    --nx-surface: #ffffff;
    --nx-well: #eceff3;
    --nx-inset: #eceff3;
    --nx-row-hover: #e5e9f0;
    --nx-overlay: #ffffff;
    --nx-scrim: rgba(15, 23, 42, 0.42);
    --nx-border: #e0e4ec;
    --nx-border-strong: #cbd2df;
    --nx-modal-shadow: 0 14px 36px rgba(15, 23, 42, 0.16);

    --nx-text: #151820;
    --nx-text-secondary: #3e4656;
    --nx-muted: #555e6e;

    --nx-accent: #1d4ed8;
    --nx-accent-text: #1d4ed8;
    --nx-accent-hover: #1e40af;
    --nx-accent-soft: rgba(29, 78, 216, 0.1);
    --nx-accent-border: rgba(29, 78, 216, 0.4);
    --nx-accent-fg: #ffffff;

    --nx-down: #0369a1;
    --nx-up: #7c3aed;

    --nx-ok-fg: #15803d;
    --nx-ok-bg: #dcfce7;
    --nx-ok-border: rgba(21, 128, 61, 0.28);

    --nx-warn-fg: #b45309;
    --nx-warn-bg: #fef3c7;
    --nx-warn-border: rgba(180, 83, 9, 0.28);

    --nx-err-fg: #b91c1c;
    --nx-err-bg: #fee2e2;
    --nx-err-border: rgba(185, 28, 28, 0.28);

    --nx-lat-fast-fg: #15803d;
    --nx-lat-fast-bg: #dcfce7;
    --nx-lat-good-fg: #0f766e;
    --nx-lat-good-bg: #ccfbf1;
    --nx-lat-mid-fg: #b45309;
    --nx-lat-mid-bg: #fef3c7;
    --nx-lat-slow-fg: #c2410c;
    --nx-lat-slow-bg: #ffedd5;
    --nx-lat-down-fg: #b91c1c;
    --nx-lat-down-bg: #fee2e2;
    --nx-lat-unprobed-fg: #555e6e;
    --nx-lat-unprobed-bg: #eceff3;
  }
`,H=o`
  *,
  *::before,
  *::after {
    box-sizing: border-box;
  }
  :host {
    display: block;
    color: var(--nx-text);
  }
  .page {
    display: flex;
    flex-direction: column;
    gap: 14px;
  }
  .page-head {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
  }
  .bento-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
    gap: 12px;
  }
  .bento-2 {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 12px;
  }
  @media (max-width: 900px) {
    .bento-2 {
      grid-template-columns: 1fr;
    }
  }
  .card {
    background: var(--nx-surface);
    border: 1px solid var(--nx-border);
    border-radius: 12px;
    padding: 14px;
  }
  .well {
    background: var(--nx-well);
    border-radius: 8px;
    padding: 12px;
  }
  .row {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 8px;
  }
  .between {
    justify-content: space-between;
  }
  .col {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
  h2 {
    margin: 0;
    font-size: 19px;
    font-weight: 700;
    letter-spacing: -0.015em;
    text-wrap: balance;
  }
  h3 {
    margin: 0;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    color: var(--nx-muted);
  }
  .metric {
    font-size: 24px;
    font-weight: 700;
    letter-spacing: -0.02em;
    font-variant-numeric: tabular-nums;
    line-height: 1.2;
  }
  .tabular {
    font-variant-numeric: tabular-nums;
  }
  .rate-slot {
    display: inline-block;
    min-width: 9ch;
    text-align: right;
    font-variant-numeric: tabular-nums;
  }
  .num-col {
    text-align: right;
    font-variant-numeric: tabular-nums;
    white-space: nowrap;
  }
  .secondary {
    color: var(--nx-text-secondary);
    font-size: 13px;
  }
  .muted {
    color: var(--nx-muted);
    font-size: 12.5px;
  }
  .mono {
    font-family: ui-monospace, SFMono-Regular, 'SF Mono', Menlo, Consolas, monospace;
    font-size: 12px;
    font-variant-numeric: tabular-nums;
  }
  .truncate {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  button,
  .btn,
  a,
  .chip,
  .badge {
    -webkit-tap-highlight-color: transparent;
    touch-action: manipulation;
    user-select: none;
  }
  button,
  .btn {
    appearance: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    border: 1px solid var(--nx-border-strong);
    background: var(--nx-well);
    color: var(--nx-text);
    border-radius: 8px;
    padding: 7px 12px;
    font-size: 12.5px;
    font-weight: 600;
    line-height: 1.2;
    cursor: pointer;
    transition:
      background 120ms ease-out,
      border-color 120ms ease-out,
      transform 120ms cubic-bezier(0.23, 1, 0.32, 1);
    font-family: inherit;
  }
  button:active:not(:disabled),
  .chip:active {
    transform: scale(0.98);
  }
  button:focus-visible,
  a:focus-visible,
  input:focus-visible,
  select:focus-visible,
  [tabindex]:focus-visible {
    outline: 2px solid var(--nx-accent);
    outline-offset: 2px;
  }
  button.primary {
    background: var(--nx-accent);
    border-color: var(--nx-accent);
    color: var(--nx-accent-fg);
  }
  button.danger {
    color: var(--nx-err-fg);
    border-color: var(--nx-err-border);
    background: var(--nx-err-bg);
  }
  button.ghost {
    background: transparent;
    border-color: transparent;
    color: var(--nx-text-secondary);
  }
  button.sm {
    padding: 5px 9px;
    font-size: 12px;
    border-radius: 6px;
  }
  button:disabled {
    opacity: 0.48;
    cursor: not-allowed;
  }
  input,
  select {
    border: 1px solid var(--nx-border-strong);
    background: var(--nx-well);
    color: var(--nx-text);
    border-radius: 8px;
    padding: 7px 11px;
    font-size: 13px;
    font-family: inherit;
    transition: border-color 120ms ease-out, background 120ms ease-out;
  }
  option {
    background: var(--nx-surface);
    color: var(--nx-text);
  }
  input::placeholder {
    color: var(--nx-muted);
  }
  .segmented {
    display: inline-flex;
    background: var(--nx-inset);
    border: 1px solid var(--nx-border);
    border-radius: 10px;
    padding: 3px;
    gap: 2px;
  }
  .segmented button {
    border: none;
    background: transparent;
    color: var(--nx-text-secondary);
    padding: 5px 11px;
    border-radius: 7px;
    font-size: 12px;
    font-weight: 600;
  }
  .segmented button.active {
    background: var(--nx-accent);
    color: var(--nx-accent-fg);
  }
  .chip {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 4px 10px;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 600;
    border: 1px solid var(--nx-border);
    background: var(--nx-well);
    color: var(--nx-text-secondary);
    cursor: pointer;
    transition:
      background 120ms ease-out,
      border-color 120ms ease-out,
      transform 120ms cubic-bezier(0.23, 1, 0.32, 1);
  }
  .chip.active {
    background: var(--nx-accent-soft);
    border-color: var(--nx-accent-border);
    color: var(--nx-accent-text, var(--nx-accent));
  }
  .badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 2px 8px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 600;
    font-variant-numeric: tabular-nums;
    background: var(--nx-inset);
    border: 1px solid var(--nx-border);
    color: var(--nx-text-secondary);
    white-space: nowrap;
  }
  .badge.ok {
    color: var(--nx-ok-fg);
    background: var(--nx-ok-bg);
    border-color: var(--nx-ok-border);
  }
  .badge.warn {
    color: var(--nx-warn-fg);
    background: var(--nx-warn-bg);
    border-color: var(--nx-warn-border);
  }
  .badge.err {
    color: var(--nx-err-fg);
    background: var(--nx-err-bg);
    border-color: var(--nx-err-border);
  }
  .badge.accent {
    color: var(--nx-accent-text, var(--nx-accent));
    background: var(--nx-accent-soft);
    border-color: var(--nx-accent-border);
  }
  .badge.lat-fast {
    color: var(--nx-lat-fast-fg);
    background: var(--nx-lat-fast-bg);
    border-color: transparent;
  }
  .badge.lat-good {
    color: var(--nx-lat-good-fg);
    background: var(--nx-lat-good-bg);
    border-color: transparent;
  }
  .badge.lat-mid {
    color: var(--nx-lat-mid-fg);
    background: var(--nx-lat-mid-bg);
    border-color: transparent;
  }
  .badge.lat-slow {
    color: var(--nx-lat-slow-fg);
    background: var(--nx-lat-slow-bg);
    border-color: transparent;
  }
  .badge.lat-down {
    color: var(--nx-lat-down-fg);
    background: var(--nx-lat-down-bg);
    border-color: transparent;
  }
  .badge.lat-unprobed {
    color: var(--nx-lat-unprobed-fg);
    background: var(--nx-lat-unprobed-bg);
    border-color: transparent;
  }
  .dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: currentColor;
    display: inline-block;
  }
  .toast {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    padding: 9px 12px;
    border-radius: 8px;
    font-size: 13px;
    border: 1px solid var(--nx-border-strong);
    background: var(--nx-well);
  }
  .toast.ok {
    border-color: var(--nx-ok-border);
    background: var(--nx-ok-bg);
    color: var(--nx-ok-fg);
  }
  .toast.err {
    border-color: var(--nx-err-border);
    background: var(--nx-err-bg);
    color: var(--nx-err-fg);
  }
  .table-wrap {
    overflow-x: auto;
    overscroll-behavior: contain;
    border-radius: 8px;
  }
  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
  }
  th,
  td {
    text-align: left;
    padding: 8px 10px;
    border-bottom: 1px solid var(--nx-border);
    vertical-align: middle;
  }
  th {
    color: var(--nx-muted);
    font-weight: 600;
    font-size: 11.5px;
    text-transform: uppercase;
    letter-spacing: 0.03em;
    white-space: nowrap;
  }
  tbody tr:last-child td {
    border-bottom: none;
  }
  tbody tr.clickable {
    cursor: pointer;
  }
  tbody tr.selected {
    background: var(--nx-accent-soft);
  }
  .empty-state {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 10px;
    text-align: center;
    padding: 28px 16px;
    color: var(--nx-muted);
    font-size: 13px;
  }
  @media (hover: hover) and (pointer: fine) {
    button:hover:not(:disabled) {
      border-color: var(--nx-accent-border);
      background: var(--nx-row-hover);
    }
    button.primary:hover:not(:disabled) {
      background: var(--nx-accent-hover);
      border-color: var(--nx-accent-hover);
    }
    button.danger:hover:not(:disabled) {
      border-color: var(--nx-err-fg);
    }
    button.ghost:hover:not(:disabled) {
      background: var(--nx-well);
      color: var(--nx-text);
    }
    .segmented button:hover:not(:disabled):not(.active) {
      background: var(--nx-surface);
      color: var(--nx-text);
    }
    .chip:hover:not(.active) {
      border-color: var(--nx-border-strong);
      color: var(--nx-text);
    }
    tbody tr.clickable:hover {
      background: var(--nx-row-hover);
    }
  }
  @media (pointer: coarse) {
    input,
    select {
      font-size: 16px;
      min-height: 44px;
    }
  }
  @media (prefers-reduced-motion: reduce) {
    *,
    *::before,
    *::after {
      animation-duration: 0.01ms !important;
      animation-iteration-count: 1 !important;
      transition-duration: 0.01ms !important;
      scroll-behavior: auto !important;
    }
  }
`;function U(e,t,n,r){var i=arguments.length,a=i<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,o;if(typeof Reflect==`object`&&typeof Reflect.decorate==`function`)a=Reflect.decorate(e,t,n,r);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(i<3?o(a):i>3?o(t,n,a):o(t,n))||a);return i>3&&a&&Object.defineProperty(t,n,a),a}var W=class extends S{constructor(...e){super(...e),this.open=!1,this.tokenInput=``,this.feedback=``,this.feedbackKind=`ok`,this.unsubLocale=null}static{this.styles=[H,o`
      .backdrop {
        position: fixed;
        inset: 0;
        background: var(--nx-scrim);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 16px;
        z-index: 100;
        transition: opacity 160ms ease-out;
      }
      @media (prefers-reduced-transparency: no-preference) {
        .backdrop {
          backdrop-filter: blur(4px);
        }
      }
      .modal {
        width: min(460px, 100%);
        max-height: 90dvh;
        overflow-y: auto;
        overscroll-behavior: contain;
        background: var(--nx-overlay);
        border: 1px solid var(--nx-border-strong);
        border-radius: 16px;
        padding: 18px;
        box-shadow: var(--nx-modal-shadow);
        display: flex;
        flex-direction: column;
        gap: 12px;
        transition:
          opacity 180ms cubic-bezier(0.23, 1, 0.32, 1),
          transform 180ms cubic-bezier(0.23, 1, 0.32, 1);
      }
      @starting-style {
        .backdrop {
          opacity: 0;
        }
        .modal {
          opacity: 0;
          transform: scale(0.96);
        }
      }
    `]}connectedCallback(){super.connectedCallback(),this.unsubLocale=B(()=>this.requestUpdate())}disconnectedCallback(){super.disconnectedCallback(),this.unsubLocale?.(),this.unsubLocale=null}updated(e){e.has(`open`)&&this.open&&(this.tokenInput=M(),this.feedback=``,this.updateComplete.then(()=>{this.shadowRoot?.querySelector(`input[type="password"]`)?.focus()}))}close(){this.dispatchEvent(new CustomEvent(`close`,{bubbles:!0,composed:!0}))}async verifyAndSave(){On(this.tokenInput);try{let e=await I.health();this.feedback=V(`auth.verified`,{instance:e.instance}),this.feedbackKind=`ok`,setTimeout(()=>this.close(),450)}catch(e){this.feedback=V(`auth.failed`,{error:e instanceof Error?e.message:String(e)}),this.feedbackKind=`err`}}render(){return this.open?g`
      <div
        class="backdrop"
        @click=${e=>{e.target===e.currentTarget&&this.close()}}
      >
        <div class="modal" role="dialog" aria-modal="true" aria-label=${V(`auth.title`)}>
          <div class="row between">
            <strong style="font-size:16px">${V(`auth.title`)}</strong>
            <button class="ghost sm" aria-label=${V(`common.close`)} @click=${()=>this.close()}>
              ${R.close()}
            </button>
          </div>
          <p class="muted" style="margin:0">${V(`auth.desc`)}</p>
          <input
            type="password"
            aria-label=${V(`auth.tokenLabel`)}
            autocomplete="off"
            spellcheck="false"
            autocapitalize="none"
            autocorrect="off"
            placeholder=${V(`auth.placeholder`)}
            .value=${this.tokenInput}
            @input=${e=>this.tokenInput=e.target.value}
            @keydown=${e=>e.key===`Enter`&&void this.verifyAndSave()}
          />
          ${this.feedback?g`<div class="toast ${this.feedbackKind}" role="status" aria-live="polite">${this.feedback}</div>`:``}
          <div class="row between">
            <button
              class="sm"
              @click=${()=>{this.tokenInput=``,On(``),this.feedback=V(`auth.cleared`),this.feedbackKind=`ok`}}
            >
              ${V(`auth.clear`)}
            </button>
            <div class="row">
              <button class="sm" @click=${()=>this.close()}>${V(`auth.close`)}</button>
              <button class="primary sm" @click=${()=>void this.verifyAndSave()}>
                ${R.lock()} ${V(`auth.save`)}
              </button>
            </div>
          </div>
        </div>
      </div>
    `:null}};U([Je({type:Boolean})],W.prototype,`open`,void 0),U([w()],W.prototype,`tokenInput`,void 0),U([w()],W.prototype,`feedback`,void 0),U([w()],W.prototype,`feedbackKind`,void 0),W=U([C(`nexus-auth-modal`)],W);var Qn=1,$n=4401;function er(e){let t=e??(typeof window<`u`?window.location:null);return!t||!t.host?`ws://127.0.0.1:9090/v1/ws`:`${t.protocol===`https:`?`wss:`:`ws:`}//${t.host}/v1/ws`}var tr=class{constructor(e){this.socket=null,this.running=!1,this.authenticated=!1,this.connGen=0,this.reconnectTimer=null,this.pingTimer=null,this.subscribedChannels=new Set,this.state=`connecting`,this.opts=e,this.baseBackoffMs=e.baseBackoffMs??1e3,this.maxBackoffMs=e.maxBackoffMs??15e3,this.pingIntervalMs=e.pingIntervalMs??2e4,this.backoffMs=this.baseBackoffMs}get isLive(){return this.running&&this.authenticated&&this.socket?.readyState===Qn}start(){this.running||(this.running=!0,this.backoffMs=this.baseBackoffMs,this.setState(`connecting`),this.connect())}restart(){this.stop(),this.start()}stop(){this.running=!1,this.authenticated=!1,this.connGen++,this.subscribedChannels.clear(),this.clearTimers(),this.closeSocket(`client stop`)}syncSubscriptions(){if(!this.isLive)return;let e=this.opts.getSubscribe(),t=new Set(e.channels),n=[...this.subscribedChannels].filter(e=>!t.has(e));n.length>0&&this.sendJson({type:`unsubscribe`,channels:n}),e.channels.length>0&&this.sendJson({type:`subscribe`,channels:e.channels,since:e.since??0,interval_ms:e.interval_ms??1e3}),this.subscribedChannels=t}setState(e){this.state!==e&&(this.state=e,this.opts.onState(e))}clearTimers(){this.reconnectTimer!==null&&(clearTimeout(this.reconnectTimer),this.reconnectTimer=null),this.pingTimer!==null&&(clearInterval(this.pingTimer),this.pingTimer=null)}closeSocket(e){let t=this.socket;if(this.socket=null,t){t.onopen=t.onmessage=t.onerror=t.onclose=null;try{t.close(1e3,e)}catch{}}}startPingTimer(e){this.pingTimer!==null&&clearInterval(this.pingTimer),this.pingIntervalMs<=0||(this.pingTimer=setInterval(()=>{this.running&&e===this.connGen&&this.isLive&&this.sendJson({type:`ping`})},this.pingIntervalMs))}sendJson(e){if(this.socket&&this.socket.readyState===Qn)try{this.socket.send(JSON.stringify(e))}catch{}}handleUnauthorized(){this.authenticated=!1,this.connGen++,this.clearTimers(),this.closeSocket(`unauthorized`),this.setState(`unauthorized`),this.opts.onUnauthorized?.()}scheduleReconnect(){if(!this.running||this.state===`unauthorized`||this.reconnectTimer!==null)return;let e=this.backoffMs;this.backoffMs=Math.min(this.maxBackoffMs,this.backoffMs*2),this.reconnectTimer=setTimeout(()=>{this.reconnectTimer=null,this.running&&this.connect()},e)}markLive(e){this.running&&e===this.connGen&&(this.authenticated=!0,this.backoffMs=this.baseBackoffMs,this.setState(`live`),this.opts.onRecovered?.(),this.startPingTimer(e))}syncIfChannelsChanged(){let e=this.opts.getSubscribe().channels;(e.length!==this.subscribedChannels.size||e.some(e=>!this.subscribedChannels.has(e)))&&this.syncSubscriptions()}handleMessage(e,t){if(!this.running||t!==this.connGen||typeof e!=`string`)return;let n;try{n=JSON.parse(e)}catch{return}let r=typeof n.type==`string`?n.type:``;if(r===`auth_ok`)this.markLive(t),this.subscribedChannels.clear(),this.syncSubscriptions();else if(r===`subscribed`)this.authenticated||(this.markLive(t),this.syncIfChannelsChanged());else if(r===`metrics`&&n.data&&typeof n.data==`object`)this.authenticated||(this.markLive(t),this.syncIfChannelsChanged()),this.opts.onMetrics?.(n.data);else if(r===`connections`&&n.data){this.authenticated||(this.markLive(t),this.syncIfChannelsChanged());let e=n.data;this.opts.onConnections?.(Array.isArray(e)?e:e.connections??[])}else if(r===`log`&&n.data&&typeof n.data==`object`)this.authenticated||(this.markLive(t),this.syncIfChannelsChanged()),this.opts.onLog?.(n.data);else if(r===`error`){let e=typeof n.code==`string`?n.code:void 0,t=typeof n.message==`string`?n.message:`WebSocket error`;e===`unauthorized`?this.handleUnauthorized():this.opts.onError?.(t,e)}}connect(){if(!this.running)return;let e=this.opts.createSocket??(typeof WebSocket<`u`?e=>new WebSocket(e):null);if(!e){this.opts.onFallback?.();return}let t=++this.connGen;this.authenticated=!1;let n;try{n=e((this.opts.buildUrl??er)())}catch{this.opts.onFallback?.(),this.scheduleReconnect();return}this.socket=n,n.onopen=()=>{if(!this.running||t!==this.connGen)return;let e=this.opts.getToken().trim();if(e)this.sendJson({type:`auth`,token:e});else{let e=this.opts.getSubscribe();this.subscribedChannels=new Set(e.channels),this.sendJson({type:`subscribe`,channels:e.channels,since:e.since??0,interval_ms:e.interval_ms??1e3})}},n.onmessage=e=>this.handleMessage(e?.data,t),n.onerror=()=>{},n.onclose=e=>{t===this.connGen&&(this.authenticated=!1,this.socket=null,this.pingTimer!==null&&(clearInterval(this.pingTimer),this.pingTimer=null),e?.code===$n?this.handleUnauthorized():this.running&&(this.opts.onFallback?.(),this.scheduleReconnect()))}}},nr=`nexus_web_theme`,G=new class extends EventTarget{constructor(){super(),this.status=null,this.mode=null,this.streamState=`connecting`,this.streamTransport=`ws`,this.streamError=``,this.authRequired=!1,this.upRate=0,this.downRate=0,this.history=[],this.themePref=`system`,this.resolvedTheme=`dark`,this.latestConnections=[],this.wsClient=null,this.sseFallback=null,this.channelRefs={connections:0,logs:0},this.logSince=0,this.lastUp=0,this.lastDown=0,this.lastTs=0,this.mediaQuery=null,this.unsubAuth=[],this.started=!1,this.handleMediaChange=()=>{this.themePref===`system`&&(this.resolvedTheme=this.computeResolvedTheme(),this.applyThemeDom(),this.emit(`change`))},this.themePref=this.loadThemePref(),this.resolvedTheme=this.computeResolvedTheme()}get wsLive(){return this.wsClient?.isLive??!1}get shouldUseSseFallback(){return this.streamTransport===`sse`&&!this.wsLive&&!this.authRequired}start(){this.started||(this.started=!0,this.applyThemeDom(),typeof window<`u`&&window.matchMedia&&(this.mediaQuery=window.matchMedia(`(prefers-color-scheme: dark)`),this.mediaQuery.addEventListener(`change`,this.handleMediaChange)),this.unsubAuth.push(An(`unauthorized`,()=>{this.authRequired=!0,this.streamState=`unauthorized`,this.sseFallback?.stop(),this.emit(`transport-change`),this.emit(`change`),this.emit(`auth-required`)}),An(`token-changed`,()=>{this.authRequired=!1,this.streamTransport=`ws`,this.streamError=``,this.sseFallback?.stop(),this.wsClient?.restart(),this.refreshMode(),this.emit(`transport-change`),this.emit(`change`),this.emit(`refresh`)})),this.wsClient=new tr({getToken:M,getSubscribe:()=>({channels:this.activeWsChannels(),since:this.logSince,interval_ms:1500}),onMetrics:e=>this.ingestStatus(e),onConnections:e=>{this.latestConnections=e,this.dispatchEvent(new CustomEvent(`ws-connections`,{detail:e}))},onLog:e=>{e.seq>this.logSince&&(this.logSince=e.seq),this.dispatchEvent(new CustomEvent(`ws-log`,{detail:e}))},onState:e=>{(e===`live`||e===`unauthorized`)&&(this.streamState=e,e===`live`&&(this.streamTransport=`ws`,this.authRequired=!1,this.streamError=``),this.emit(`change`))},onError:e=>{this.streamError=e,this.emit(`change`)},onUnauthorized:kn,onFallback:()=>this.activateSseFallback(),onRecovered:()=>this.stopSseFallback()}),this.wsClient.start(),this.refreshMode())}stop(){if(this.started){this.started=!1,this.wsClient?.stop(),this.wsClient=null,this.sseFallback?.stop(),this.sseFallback=null,this.mediaQuery?.removeEventListener(`change`,this.handleMediaChange);for(let e of this.unsubAuth)e();this.unsubAuth=[]}}acquireChannel(e,t){e===`logs`&&t!==void 0&&t>=0&&(this.logSince=t),this.channelRefs[e]++,this.wsClient?.syncSubscriptions();let n=!1;return()=>{n||(n=!0,this.channelRefs[e]=Math.max(0,this.channelRefs[e]-1),this.wsClient?.syncSubscriptions())}}setLogCursor(e){e>this.logSince&&(this.logSince=e,this.channelRefs.logs>0&&this.wsClient?.syncSubscriptions())}onWsConnections(e){let t=t=>e(t.detail);return this.addEventListener(`ws-connections`,t),()=>this.removeEventListener(`ws-connections`,t)}onWsLog(e){let t=t=>e(t.detail);return this.addEventListener(`ws-log`,t),()=>this.removeEventListener(`ws-log`,t)}async refreshNow(){try{let[e,t]=await Promise.all([I.status(),I.mode().catch(()=>this.mode)]);this.ingestStatus(e),t&&(this.mode=t),this.authRequired=!1,this.streamError=``}catch(e){this.streamError=e instanceof Error?e.message:String(e)}this.emit(`change`),this.emit(`refresh`)}async refreshMode(){try{this.mode=await I.mode(),this.emit(`change`)}catch{}}setModeLocal(e){this.mode=e,this.emit(`change`)}cycleTheme(){let e=[`dark`,`light`,`system`],t=e[(e.indexOf(this.themePref)+1)%e.length];return this.setTheme(t),t}setTheme(e){if(this.themePref=e,typeof window<`u`)try{window.localStorage.setItem(nr,e)}catch{}this.resolvedTheme=this.computeResolvedTheme(),this.applyThemeDom(),this.emit(`change`)}subscribe(e,t=`change`){return this.addEventListener(t,e),()=>this.removeEventListener(t,e)}activeWsChannels(){let e=[`metrics`];return this.channelRefs.connections>0&&e.push(`connections`),this.channelRefs.logs>0&&e.push(`logs`),e}activateSseFallback(){this.started&&!this.authRequired&&(this.streamTransport=`sse`,this.sseFallback||=zn(e=>this.ingestStatus(e),e=>{this.wsLive||(this.streamState=e,(e===`live`||e===`polling`)&&(this.authRequired=!1,this.streamError=``),this.emit(`change`))},e=>{this.wsLive||(this.streamError=e,this.emit(`change`))},1500),this.sseFallback.start(),this.emit(`transport-change`),this.emit(`change`))}stopSseFallback(){this.streamTransport=`ws`,this.sseFallback?.stop(),this.emit(`transport-change`),this.emit(`change`)}emit(e){this.dispatchEvent(new CustomEvent(e))}ingestStatus(e){let t=Date.now(),n=Number(e.upload_bytes_total||0),r=Number(e.download_bytes_total||0);if(this.lastTs>0&&t>this.lastTs){let e=(t-this.lastTs)/1e3,i=n>=this.lastUp?n-this.lastUp:0,a=r>=this.lastDown?r-this.lastDown:0;this.upRate=Math.max(0,i/e),this.downRate=Math.max(0,a/e),this.history=[...this.history.slice(-44),{up:this.upRate,down:this.downRate,ts:t}]}else this.history.length===0&&(this.history=[{up:0,down:0,ts:t}]);this.lastUp=n,this.lastDown=r,this.lastTs=t,this.status=e,this.authRequired=!1,this.streamError=``,this.emit(`change`)}loadThemePref(){if(typeof window>`u`)return`dark`;try{let e=window.localStorage.getItem(nr);if(e===`dark`||e===`light`||e===`system`)return e}catch{}return`system`}computeResolvedTheme(){return this.themePref===`dark`||this.themePref===`light`?this.themePref:typeof window<`u`&&window.matchMedia&&window.matchMedia(`(prefers-color-scheme: light)`).matches?`light`:`dark`}applyThemeDom(){if(typeof document>`u`)return;document.documentElement.dataset.theme=this.resolvedTheme,document.documentElement.style.colorScheme=this.resolvedTheme;let e=this.resolvedTheme===`dark`?`#111317`:`#f5f6f8`,t=document.querySelector(`meta[name="theme-color"]`);!t&&document.head&&(t=document.createElement(`meta`),t.name=`theme-color`,document.head.appendChild(t)),t&&(t.content=e)}},K=class extends S{constructor(...e){super(...e),this.groups=[],this.busy=!1,this.toast=``,this.toastKind=`ok`,this.unsubs=[]}static{this.styles=[H,o`
      .hero {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: space-between;
        gap: 14px;
      }
      .hero-title {
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 20px;
        font-weight: 700;
      }
      .kpi-card {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .kpi-down {
        color: var(--nx-down);
      }
      .kpi-up {
        color: var(--nx-up);
      }
      .spark-wrap {
        position: relative;
        margin-top: 10px;
        background: var(--nx-well);
        border-radius: 8px;
        padding: 10px 8px 4px;
      }
      .spark {
        width: 100%;
        height: 112px;
        display: block;
      }
      .legend {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 14px;
        font-size: 12px;
        color: var(--nx-text-secondary);
      }
      .legend-item {
        display: inline-flex;
        align-items: center;
        gap: 6px;
      }
      .swatch {
        width: 9px;
        height: 9px;
        border-radius: 50%;
      }
      .group-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        gap: 10px;
        margin-top: 10px;
      }
      .group-tile {
        display: flex;
        flex-direction: column;
        gap: 8px;
        background: var(--nx-well);
        border-radius: 8px;
        padding: 12px;
      }
      .group-tile select {
        width: 100%;
        background: var(--nx-surface);
      }
    `]}connectedCallback(){super.connectedCallback(),this.unsubs.push(G.subscribe(()=>this.requestUpdate(),`change`),G.subscribe(()=>void this.refreshGroups(),`refresh`),B(()=>this.requestUpdate())),this.refreshGroups()}disconnectedCallback(){super.disconnectedCallback();for(let e of this.unsubs)e();this.unsubs=[]}showToast(e,t=`ok`){this.toast=e,this.toastKind=t}async refreshGroups(){try{let e=await I.outbounds();this.groups=e.groups??[]}catch{}}async handleRefresh(){this.busy=!0;try{await Promise.all([G.refreshNow(),this.refreshGroups()])}finally{this.busy=!1}}async setMode(e){let t=G.mode;G.setModeLocal({mode:e,outbound:t?.outbound??``}),this.busy=!0;try{let t=await I.setMode(e);G.setModeLocal(t),this.showToast(V(`overview.modeUpdated`,{mode:V(`overview.mode.${e}`)}),`ok`)}catch(e){t&&G.setModeLocal(t),this.showToast(e instanceof Error?e.message:String(e),`err`)}finally{this.busy=!1}}async doReload(){this.busy=!0;try{await I.reload(),this.showToast(V(`overview.reloaded`),`ok`),await G.refreshNow()}catch(e){this.showToast(e instanceof Error?e.message:String(e),`err`)}finally{this.busy=!1}}async doFlushFakeip(){this.busy=!0;try{let e=await I.flushFakeIp();this.showToast(V(`overview.flushedFakeip`,{count:e.flushed}),`ok`)}catch(e){this.showToast(e instanceof Error?e.message:String(e),`err`)}finally{this.busy=!1}}async doClearDns(){this.busy=!0;try{await I.clearCache(`dns`),this.showToast(V(`overview.clearedDns`),`ok`)}catch(e){this.showToast(e instanceof Error?e.message:String(e),`err`)}finally{this.busy=!1}}async quickSelect(e,t){let n=this.groups;this.groups=n.map(n=>n.name===e?{...n,selected:t,override:n.mode===`url-test`||n.override}:n),this.busy=!0;try{await I.selectGroup(e,t),await this.refreshGroups()}catch(e){this.groups=n,this.showToast(e instanceof Error?e.message:String(e),`err`)}finally{this.busy=!1}}sparkPoints(e,t){let n=G.history;return n.length<2?``:n.map((r,i)=>{let a=i/Math.max(1,n.length-1)*400,o=98-r[e]/t*86;return`${a.toFixed(1)},${o.toFixed(1)}`}).join(` `)}sparkArea(e,t){let n=this.sparkPoints(e,t);return n?`0,104 ${n} 400,104`:``}render(){let e=G.status,t=G.mode?.mode??`rule`,n=Math.max(1024,...G.history.map(e=>Math.max(e.up,e.down))),r=this.sparkPoints(`down`,n),i=this.sparkPoints(`up`,n);return g`
      <div class="page">
        <div class="page-head">
          <h2>${V(`overview.title`)}</h2>
          <div class="row">
            <button class="sm" @click=${()=>void this.handleRefresh()} ?disabled=${this.busy}>
              ${R.refresh()} ${V(`common.refresh`)}
            </button>
          </div>
        </div>

        ${this.toast?g`
              <div class="toast ${this.toastKind}" role="status" aria-live="polite">
                <span>${this.toast}</span>
                <button
                  class="ghost sm"
                  aria-label=${V(`common.dismiss`)}
                  @click=${()=>this.toast=``}
                >
                  ${R.close()}
                </button>
              </div>
            `:``}

        <div class="card hero">
          <div class="col" style="gap:6px">
            <div class="hero-title">
              <span class="badge ${e?`ok`:`err`}">
                <span class="dot"></span>
                ${V(e?`overview.heroRunning`:`stream.${G.streamState}`)}
              </span>
              <span class="mono" style="font-size:15px">${e?.instance??`nexus`}</span>
            </div>
            <div class="row muted mono">
              <span>${V(`overview.gen`)} #${e?.control_generation??`0`}</span>
              <span>·</span>
              <span>${V(`overview.listeners`)}: ${e?.listeners??0}</span>
              <span>·</span>
              <span>${V(`overview.workers`)}: ${e?.workers??0}</span>
              ${G.mode?.outbound?g`<span>·</span><span>global → ${G.mode.outbound}</span>`:``}
            </div>
          </div>

          <div class="row">
            <div class="segmented" role="group" aria-label=${V(`overview.mode`)}>
              ${[`rule`,`global`,`direct`].map(e=>g`
                  <button
                    class=${t===e?`active`:``}
                    aria-pressed=${t===e?`true`:`false`}
                    ?disabled=${this.busy}
                    @click=${()=>void this.setMode(e)}
                  >
                    ${V(`overview.mode.${e}`)}
                  </button>
                `)}
            </div>
            <button class="sm" ?disabled=${this.busy} @click=${()=>void this.doFlushFakeip()}>
              ${V(`overview.flushFakeip`)}
            </button>
            <button class="sm" ?disabled=${this.busy} @click=${()=>void this.doClearDns()}>
              ${V(`overview.clearDns`)}
            </button>
            <button class="primary sm" ?disabled=${this.busy} @click=${()=>void this.doReload()}>
              ${R.refresh()} ${V(`overview.reload`)}
            </button>
          </div>
        </div>

        <div class="bento-grid">
          <div class="card kpi-card">
            <h3>${V(`overview.download`)}</h3>
            <div class="metric kpi-down">${P(G.downRate)}</div>
            <div class="muted tabular">${V(`overview.total`)} ${N(e?.download_bytes_total??0)}</div>
          </div>
          <div class="card kpi-card">
            <h3>${V(`overview.upload`)}</h3>
            <div class="metric kpi-up">${P(G.upRate)}</div>
            <div class="muted tabular">${V(`overview.total`)} ${N(e?.upload_bytes_total??0)}</div>
          </div>
          <div class="card kpi-card">
            <h3>${V(`overview.sessions`)}</h3>
            <div class="metric">${e?.active_sessions??0}</div>
            <div class="muted tabular">${V(`overview.mode`)}: ${V(`overview.mode.${t}`)}</div>
          </div>
          <div class="card kpi-card">
            <h3>${V(`overview.peakCard`)}</h3>
            <div class="metric">${P(n)}</div>
            <div class="muted mono truncate">
              ${G.mode?.outbound?`→ ${G.mode.outbound}`:e?.instance??`nexus`}
            </div>
          </div>
        </div>

        <div class="card">
          <div class="row between">
            <h3>${V(`overview.throughput`)}</h3>
            <div class="legend tabular">
              <span class="legend-item">
                <span class="swatch" style="background:var(--nx-down)"></span>
                ${V(`overview.download`)} <span class="rate-slot">${P(G.downRate)}</span>
              </span>
              <span class="legend-item">
                <span class="swatch" style="background:var(--nx-up)"></span>
                ${V(`overview.upload`)} <span class="rate-slot">${P(G.upRate)}</span>
              </span>
              <span class="muted">
                ${V(`overview.peak`)} <span class="rate-slot">${P(n)}</span>
              </span>
            </div>
          </div>
          <div class="spark-wrap">
            <svg class="spark" aria-hidden="true" viewBox="0 0 400 104" preserveAspectRatio="none">
              <defs>
                <linearGradient id="nx-down-grad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stop-color="var(--nx-down)" stop-opacity="0.28" />
                  <stop offset="100%" stop-color="var(--nx-down)" stop-opacity="0.01" />
                </linearGradient>
                <linearGradient id="nx-up-grad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stop-color="var(--nx-up)" stop-opacity="0.22" />
                  <stop offset="100%" stop-color="var(--nx-up)" stop-opacity="0.01" />
                </linearGradient>
              </defs>
              <line x1="0" y1="34" x2="400" y2="34" stroke="var(--nx-border)" stroke-dasharray="3 4" />
              <line x1="0" y1="68" x2="400" y2="68" stroke="var(--nx-border)" stroke-dasharray="3 4" />
              ${r?g`
                    <polygon fill="url(#nx-down-grad)" points=${this.sparkArea(`down`,n)}></polygon>
                    <polyline fill="none" stroke="var(--nx-down)" stroke-width="2" points=${r}></polyline>
                  `:``}
              ${i?g`
                    <polygon fill="url(#nx-up-grad)" points=${this.sparkArea(`up`,n)}></polygon>
                    <polyline fill="none" stroke="var(--nx-up)" stroke-width="2" points=${i}></polyline>
                  `:``}
            </svg>
          </div>
        </div>

        <div class="card">
          <div class="row between">
            <h3>${V(`overview.quickGroups`)}</h3>
            <span class="muted tabular">${this.groups.length}</span>
          </div>
          ${this.groups.length===0?g`
                <div class="empty-state">
                  <span>${V(`overview.noGroups`)}</span>
                  <button class="sm" ?disabled=${this.busy} @click=${()=>void this.handleRefresh()}>
                    ${R.refresh()} ${V(`common.refresh`)}
                  </button>
                </div>
              `:g`
                <div class="group-grid">
                  ${this.groups.map(e=>{let t=e.members.find(t=>t.name===e.selected),n=Nn(t?.latency_ms,t?.state),r=e.mode===`selector`||e.mode===`select`||e.mode===`url-test`;return g`
                      <div class="group-tile">
                        <div class="row between">
                          <strong class="truncate">${e.name}</strong>
                          <span class="badge lat-${n}">
                            ${t?.latency_ms===void 0?V(`outbounds.unprobed`):`${t.latency_ms} ms`}
                          </span>
                        </div>
                        <div class="row between muted" style="font-size:11.5px">
                          <span>${e.mode}</span>
                          ${e.override?g`<span class="badge warn">${V(`outbounds.override`)}</span>`:``}
                        </div>
                        <select
                          aria-label=${e.name}
                          .value=${e.selected}
                          ?disabled=${this.busy||!r}
                          @change=${t=>void this.quickSelect(e.name,t.target.value)}
                        >
                          ${e.members.map(t=>g`
                              <option value=${t.name} ?selected=${t.name===e.selected}>
                                ${t.name}${t.latency_ms===void 0?``:` (${t.latency_ms}ms)`}
                              </option>
                            `)}
                        </select>
                      </div>
                    `})}
                </div>
              `}
        </div>
      </div>
    `}};U([w()],K.prototype,`groups`,void 0),U([w()],K.prototype,`busy`,void 0),U([w()],K.prototype,`toast`,void 0),U([w()],K.prototype,`toastKind`,void 0),K=U([C(`nexus-overview-page`)],K);var q=class extends S{constructor(...e){super(...e),this.groups=[],this.activeGroup=``,this.search=``,this.sortOrder=`default`,this.busy=!1,this.probingNodes=new Set,this.liveProbes=new Map,this.toast=``,this.toastKind=`ok`,this.unsubs=[],this.probeRefreshTimer=null}static{this.styles=[H,o`
      .split {
        display: grid;
        grid-template-columns: 240px 1fr;
        gap: 14px;
        align-items: start;
      }
      @media (max-width: 820px) {
        .split {
          grid-template-columns: 1fr;
        }
      }
      .rail {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .rail-item {
        width: 100%;
        text-align: left;
        display: flex;
        flex-direction: column;
        align-items: stretch;
        gap: 5px;
        padding: 10px 12px;
        border-radius: 8px;
        background: var(--nx-well);
        border: 1px solid transparent;
        transition:
          background 120ms ease-out,
          border-color 120ms ease-out,
          transform 120ms cubic-bezier(0.23, 1, 0.32, 1);
      }
      .rail-item.active {
        background: var(--nx-accent-soft);
        border-color: var(--nx-accent-border);
      }
      .node-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(225px, 1fr));
        gap: 10px;
        margin-top: 12px;
      }
      .node-card {
        display: flex;
        flex-direction: column;
        gap: 10px;
        padding: 12px;
        border-radius: 8px;
        background: var(--nx-well);
        border: 1px solid transparent;
        transition:
          border-color 120ms ease-out,
          background 120ms ease-out,
          transform 120ms cubic-bezier(0.23, 1, 0.32, 1);
      }
      .node-card.switchable {
        cursor: pointer;
      }
      .node-card.switchable:active,
      .rail-item:active {
        transform: scale(0.98);
      }
      .node-card.selected {
        border-color: var(--nx-accent);
        background: var(--nx-accent-soft);
      }
      .node-select-btn {
        flex: 1;
        min-width: 0;
        border: none;
        background: transparent;
        padding: 0;
        color: var(--nx-text);
        font-size: 13.5px;
        font-weight: 700;
        text-align: left;
        justify-content: flex-start;
      }
      .node-select-btn:disabled {
        opacity: 1;
        cursor: default;
      }
      @media (hover: hover) and (pointer: fine) {
        .rail-item:hover:not(.active) {
          background: var(--nx-row-hover);
        }
        .node-card.switchable:hover {
          border-color: var(--nx-accent-border);
          background: var(--nx-row-hover);
        }
        .node-select-btn:hover:not(:disabled) {
          background: transparent;
          color: var(--nx-accent-text, var(--nx-accent));
        }
      }
      .bars {
        display: inline-flex;
        align-items: flex-end;
        gap: 2px;
        height: 12px;
      }
      .bars span {
        width: 3px;
        border-radius: 1px;
        background: currentColor;
        opacity: 0.24;
      }
      .bars span.on {
        opacity: 1;
      }
    `]}connectedCallback(){super.connectedCallback(),this.unsubs.push(G.subscribe(()=>void this.refresh(),`refresh`),B(()=>this.requestUpdate())),this.refresh()}disconnectedCallback(){super.disconnectedCallback(),this.probeRefreshTimer!==null&&(clearTimeout(this.probeRefreshTimer),this.probeRefreshTimer=null);for(let e of this.unsubs)e();this.unsubs=[]}async refresh(){try{let e=await I.outbounds();this.groups=e.groups??[],this.groups.length>0&&!this.groups.some(e=>e.name===this.activeGroup)&&(this.activeGroup=this.groups[0].name)}catch(e){this.toast=e instanceof Error?e.message:String(e),this.toastKind=`err`}}async selectMember(e,t){let n=this.groups;this.groups=n.map(n=>n.name===e?t===`--auto`?{...n,override:!1}:{...n,selected:t,override:n.mode===`url-test`||n.override}:n),this.busy=!0;try{await I.selectGroup(e,t),await this.refresh()}catch(e){this.groups=n,this.toast=e instanceof Error?e.message:String(e),this.toastKind=`err`}finally{this.busy=!1}}async probeGroup(e){this.busy=!0;try{await I.probeGroup(e),this.toast=V(`outbounds.groupProbed`,{group:e}),this.toastKind=`ok`,this.probeRefreshTimer!==null&&clearTimeout(this.probeRefreshTimer),this.probeRefreshTimer=setTimeout(()=>{this.probeRefreshTimer=null,this.isConnected&&this.refresh()},900)}catch(e){this.toast=e instanceof Error?e.message:String(e),this.toastKind=`err`}finally{this.busy=!1}}async probeNode(e,t){t.stopPropagation();let n=new Set(this.probingNodes);n.add(e),this.probingNodes=n;try{let t=await I.probeOutbound(e),n=new Map(this.liveProbes);n.set(e,t),this.liveProbes=n;let r=t.latency_ms!==void 0&&t.latency_ms!==null?` (${t.latency_ms} ms)`:``;this.toast=V(`outbounds.nodeProbed`,{node:e,state:t.state,rtt:r}),this.toastKind=t.state===`up`?`ok`:`err`,this.refresh()}catch(t){this.toast=`${e}: ${t instanceof Error?t.message:String(t)}`,this.toastKind=`err`}finally{let t=new Set(this.probingNodes);t.delete(e),this.probingNodes=t}}effectiveLatency(e){let t=this.liveProbes.get(e.name);return t&&t.latency_ms!==void 0&&t.latency_ms!==null?t.latency_ms:e.latency_ms??null}effectiveState(e){return this.liveProbes.get(e.name)?.state??e.state}sortedMembers(e){let t=this.search.trim().toLowerCase(),n=t?e.filter(e=>e.name.toLowerCase().includes(t)||this.effectiveState(e).toLowerCase().includes(t)):[...e];return this.sortOrder===`name`?n.sort((e,t)=>e.name.localeCompare(t.name)):this.sortOrder===`latency`?n.sort((e,t)=>{let n=this.effectiveLatency(e),r=this.effectiveLatency(t);return(n??999999)-(r??999999)}):n}render(){let e=this.groups.find(e=>e.name===this.activeGroup)??this.groups[0]??null,t=e?this.sortedMembers(e.members):[],n=e!==null&&e.mode!==`select`&&e.mode!==`selector`,r=e!==null&&(e.mode===`selector`||e.mode===`select`||e.mode===`url-test`);return g`
      <div class="page">
        <div class="page-head">
          <h2>${V(`outbounds.title`)}</h2>
          <button class="sm" @click=${()=>void this.refresh()} ?disabled=${this.busy}>
            ${R.refresh()} ${V(`common.refresh`)}
          </button>
        </div>

        ${this.toast?g`
              <div class="toast ${this.toastKind}" role="status" aria-live="polite">
                <span>${this.toast}</span>
                <button
                  class="ghost sm"
                  aria-label=${V(`common.dismiss`)}
                  @click=${()=>this.toast=``}
                >
                  ${R.close()}
                </button>
              </div>
            `:``}

        ${this.groups.length===0?g`
              <div class="card empty-state">
                <span>${V(`outbounds.empty`)}</span>
                <button class="sm" ?disabled=${this.busy} @click=${()=>void this.refresh()}>
                  ${R.refresh()} ${V(`common.refresh`)}
                </button>
              </div>
            `:g`
              <div class="split">
                <div class="card rail">
                  <div class="row between" style="margin-bottom:4px">
                    <h3>${V(`outbounds.groups`)}</h3>
                    <span class="muted tabular">${this.groups.length}</span>
                  </div>
                  ${this.groups.map(t=>{let n=t.members.filter(e=>e.state===`up`).length;return g`
                      <button
                        class="rail-item ${t.name===e?.name?`active`:``}"
                        @click=${()=>this.activeGroup=t.name}
                      >
                        <div class="row between" style="width:100%">
                          <strong class="truncate">${t.name}</strong>
                          <span class="muted mono" style="font-size:11px">${t.mode}</span>
                        </div>
                        <div class="row between muted" style="width:100%; font-size:11.5px">
                          <span class="truncate">${t.selected}</span>
                          <span class="tabular">${n}/${t.members.length}</span>
                        </div>
                      </button>
                    `})}
                </div>

                ${e?g`
                      <div class="card">
                        <div class="row between" style="gap:10px">
                          <div class="row">
                            <strong style="font-size:16px">${e.name}</strong>
                            <span class="muted mono">${e.mode}</span>
                            <span class="badge ok">${V(`outbounds.selected`)}: ${e.selected}</span>
                            ${e.override?g`<span class="badge warn">${V(`outbounds.override`)}</span>`:``}
                          </div>
                          <div class="row">
                            ${e.override?g`
                                  <button
                                    class="sm"
                                    ?disabled=${this.busy}
                                    @click=${()=>void this.selectMember(e.name,`--auto`)}
                                  >
                                    ${V(`outbounds.resetAuto`)}
                                  </button>
                                `:``}
                            ${n?g`
                                  <button
                                    class="primary sm"
                                    ?disabled=${this.busy}
                                    @click=${()=>void this.probeGroup(e.name)}
                                  >
                                    ${R.bolt()} ${V(`outbounds.probeGroup`)}
                                  </button>
                                `:``}
                          </div>
                        </div>

                        <div class="row" style="margin-top:12px">
                          <input
                            data-search-input
                            type="search"
                            aria-label=${V(`outbounds.search`)}
                            spellcheck="false"
                            autocapitalize="none"
                            autocorrect="off"
                            style="flex:1; min-width:180px"
                            placeholder=${V(`outbounds.search`)}
                            .value=${this.search}
                            @input=${e=>this.search=e.target.value}
                          />
                          <select
                            aria-label=${V(`outbounds.sortLabel`)}
                            .value=${this.sortOrder}
                            @change=${e=>this.sortOrder=e.target.value}
                          >
                            <option value="default">${V(`outbounds.sort.default`)}</option>
                            <option value="latency">${V(`outbounds.sort.latency`)}</option>
                            <option value="name">${V(`outbounds.sort.name`)}</option>
                          </select>
                        </div>

                        ${t.length===0?g`
                              <div class="empty-state">
                                <span>${V(`outbounds.noMatch`)}</span>
                                ${this.search.trim()?g`<button class="sm" @click=${()=>this.search=``}>${V(`common.clearFilters`)}</button>`:g`<button class="sm" @click=${()=>void this.refresh()}>${R.refresh()} ${V(`common.refresh`)}</button>`}
                              </div>
                            `:g`
                              <div class="node-grid">
                                ${t.map(t=>{let n=this.effectiveLatency(t),i=this.effectiveState(t),a=t.breaker_open?`down`:Nn(n,i),o=Pn(n),s=this.probingNodes.has(t.name),c=this.liveProbes.get(t.name)?.status_code??t.last_status,l=t.name===e.selected;return g`
                                    <div
                                      class="node-card ${l?`selected`:``} ${r?`switchable`:``}"
                                      @click=${()=>r&&!this.busy&&void this.selectMember(e.name,t.name)}
                                    >
                                      <div class="row between">
                                        <button
                                          type="button"
                                          class="node-select-btn truncate"
                                          title=${t.name}
                                          aria-pressed=${l?`true`:`false`}
                                          ?disabled=${!r||this.busy}
                                          @click=${n=>{n.stopPropagation(),r&&this.selectMember(e.name,t.name)}}
                                        >
                                          ${t.name}
                                        </button>
                                        <span class="badge lat-${a}">
                                          <span class="bars" aria-hidden="true">
                                            ${[4,7,10,12].map((e,t)=>g`<span
                                                  class=${t<o?`on`:``}
                                                  style="height:${e}px"
                                                ></span>`)}
                                          </span>
                                          ${t.breaker_open?V(`outbounds.breaker`):n===null?V(i===`down`?`outbounds.down`:`outbounds.unprobed`):`${n} ms`}
                                        </span>
                                      </div>

                                      <div class="row between">
                                        <div class="muted mono" style="font-size:11.5px">
                                          ${t.ewma_ms===void 0?i:`EWMA ${t.ewma_ms}ms`}
                                          ${c===void 0?``:` · HTTP ${c}`}
                                        </div>
                                        <button
                                          class="sm"
                                          ?disabled=${s}
                                          @click=${e=>void this.probeNode(t.name,e)}
                                        >
                                          ${R.bolt()}
                                          ${V(s?`outbounds.probing`:`outbounds.probeNode`)}
                                        </button>
                                      </div>
                                    </div>
                                  `})}
                              </div>
                            `}
                      </div>
                    `:``}
              </div>
            `}
      </div>
    `}};U([w()],q.prototype,`groups`,void 0),U([w()],q.prototype,`activeGroup`,void 0),U([w()],q.prototype,`search`,void 0),U([w()],q.prototype,`sortOrder`,void 0),U([w()],q.prototype,`busy`,void 0),U([w()],q.prototype,`probingNodes`,void 0),U([w()],q.prototype,`liveProbes`,void 0),U([w()],q.prototype,`toast`,void 0),U([w()],q.prototype,`toastKind`,void 0),q=U([C(`nexus-outbounds-page`)],q);var J=class extends S{constructor(...e){super(...e),this.connections=[],this.detail=null,this.search=``,this.protoFilter=`all`,this.sortBy=`bytes`,this.paused=!1,this.streamState=`connecting`,this.confirmMode=`none`,this.toast=``,this.toastKind=`ok`,this.stream=null,this.unsubs=[]}static{this.styles=[H,o`
      .drawer {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 10px 16px;
        margin-top: 10px;
      }
      .kv {
        display: flex;
        flex-direction: column;
        gap: 2px;
      }
      .kv-label {
        font-size: 11px;
        color: var(--nx-muted);
        text-transform: uppercase;
        letter-spacing: 0.03em;
      }
      .target-cell {
        max-width: 260px;
      }
    `]}connectedCallback(){super.connectedCallback(),G.latestConnections.length>0&&(this.connections=G.latestConnections),this.unsubs.push(G.acquireChannel(`connections`),G.onWsConnections(e=>{this.paused||(this.connections=e)}),G.subscribe(()=>this.syncTransport(),`transport-change`),G.subscribe(()=>this.requestUpdate(),`change`),G.subscribe(()=>void this.refreshOnce(),`refresh`),B(()=>this.requestUpdate())),this.syncTransport()}disconnectedCallback(){super.disconnectedCallback(),this.stream?.stop(),this.stream=null;for(let e of this.unsubs)e();this.unsubs=[]}syncTransport(){G.wsLive||G.authRequired?(this.stream?.stop(),this.stream=null,this.streamState=G.authRequired?`unauthorized`:`live`):G.shouldUseSseFallback?this.stream||this.startStream():this.streamState=`connecting`}startStream(){this.stream?.stop(),this.stream=Bn(e=>{this.paused||(this.connections=e)},e=>this.streamState=e,e=>{this.toast=e,this.toastKind=`err`},2e3),this.stream.start()}async refreshOnce(){try{let e=await I.connections();this.connections=e.connections??[]}catch(e){this.toast=e instanceof Error?e.message:String(e),this.toastKind=`err`}}togglePause(){this.paused=!this.paused,this.paused||this.refreshOnce()}async inspect(e){try{this.detail=await I.connectionDetail(e)}catch(e){this.toast=e instanceof Error?e.message:String(e),this.toastKind=`err`}}async closeOne(e,t){t.stopPropagation();try{await I.closeConnection(e),this.detail?.id===e&&(this.detail=null),await this.refreshOnce()}catch(e){this.toast=e instanceof Error?e.message:String(e),this.toastKind=`err`}}async closeAll(){this.confirmMode=`none`;try{let e=await I.closeAllConnections();this.detail=null,this.toast=V(`connections.closedCount`,{count:e.closed??0}),this.toastKind=`ok`,await this.refreshOnce()}catch(e){this.toast=e instanceof Error?e.message:String(e),this.toastKind=`err`}}async closeFiltered(e){this.confirmMode=`none`;let t=e.filter(e=>e.can_close),n=0;await Promise.all(t.map(async e=>{try{await I.closeConnection(e.id),n++}catch{}})),this.detail=null,this.toast=V(`connections.closedCount`,{count:n}),this.toastKind=`ok`,await this.refreshOnce()}filteredList(){let e=this.search.trim().toLowerCase(),t=this.connections.filter(t=>this.protoFilter!==`all`&&t.protocol.toLowerCase()!==this.protoFilter?!1:!e||[t.id,t.inbound??``,t.protocol,t.path,t.source??``,t.target??``,t.outbound??``,t.route_rule??``,t.process_path??``,String(t.destination_port)].join(` `).toLowerCase().includes(e)),n=e=>Number(e||0);return t.sort((e,t)=>this.sortBy===`down`?n(t.download_bytes)-n(e.download_bytes):this.sortBy===`up`?n(t.upload_bytes)-n(e.upload_bytes):this.sortBy===`duration`?t.duration_ms-e.duration_ms:this.sortBy===`newest`?Number(t.id)-Number(e.id):n(t.upload_bytes)+n(t.download_bytes)-(n(e.upload_bytes)+n(e.download_bytes)))}render(){let e=this.filteredList(),t=Array.from(new Set([`tcp`,`udp`,...this.connections.map(e=>e.protocol.toLowerCase())])),n=this.search.trim().length>0||this.protoFilter!==`all`,r=G.wsLive?`live`:this.streamState,i=r===`live`?`ok`:r===`polling`||r===`connecting`?`warn`:`err`,a=r===`live`&&G.wsLive?V(`stream.liveWs`):V(`stream.${r}`);return g`
      <div class="page">
        <div class="page-head">
          <div class="row">
            <h2>${V(`connections.title`)}</h2>
            <span class="muted tabular">${e.length} / ${this.connections.length}</span>
            <span class="badge ${i}">
              <span class="dot"></span>${a}
            </span>
          </div>
          <div class="row">
            <button class="sm" @click=${()=>this.togglePause()}>
              ${this.paused?R.play():R.pause()}
              ${this.paused?V(`common.resume`):V(`common.pause`)}
            </button>
            <button class="sm" @click=${()=>void this.refreshOnce()}>
              ${R.refresh()} ${V(`common.refresh`)}
            </button>
            ${this.confirmMode===`all`?g`
                  <button class="danger sm" @click=${()=>void this.closeAll()}>
                    ${V(`connections.confirmAll`,{count:this.connections.length})}
                  </button>
                  <button class="sm" @click=${()=>this.confirmMode=`none`}>
                    ${V(`common.cancel`)}
                  </button>
                `:this.confirmMode===`filtered`?g`
                    <button class="danger sm" @click=${()=>void this.closeFiltered(e)}>
                      ${V(`connections.confirmFiltered`,{count:e.length})}
                    </button>
                    <button class="sm" @click=${()=>this.confirmMode=`none`}>
                      ${V(`common.cancel`)}
                    </button>
                  `:g`
                    ${n&&e.length>0?g`
                          <button class="danger sm" @click=${()=>this.confirmMode=`filtered`}>
                            ${V(`connections.closeFiltered`,{count:e.length})}
                          </button>
                        `:``}
                    <button
                      class="danger sm"
                      ?disabled=${this.connections.length===0}
                      @click=${()=>this.confirmMode=`all`}
                    >
                      ${R.trash()} ${V(`connections.closeAll`)}
                    </button>
                  `}
          </div>
        </div>

        ${this.toast?g`
              <div class="toast ${this.toastKind}" role="status" aria-live="polite">
                <span>${this.toast}</span>
                <button
                  class="ghost sm"
                  aria-label=${V(`common.dismiss`)}
                  @click=${()=>this.toast=``}
                >
                  ${R.close()}
                </button>
              </div>
            `:``}

        <div class="card col" style="gap:10px">
          <div class="row">
            <input
              data-search-input
              type="search"
              aria-label=${V(`connections.search`)}
              spellcheck="false"
              autocapitalize="none"
              autocorrect="off"
              style="flex:1; min-width:220px"
              placeholder=${V(`connections.search`)}
              .value=${this.search}
              @input=${e=>this.search=e.target.value}
            />
            <select
              aria-label=${V(`connections.sortLabel`)}
              .value=${this.sortBy}
              @change=${e=>this.sortBy=e.target.value}
            >
              <option value="bytes">${V(`connections.sort.bytes`)}</option>
              <option value="down">${V(`connections.sort.down`)}</option>
              <option value="up">${V(`connections.sort.up`)}</option>
              <option value="duration">${V(`connections.sort.duration`)}</option>
              <option value="newest">${V(`connections.sort.newest`)}</option>
            </select>
          </div>
          <div class="row">
            <button
              class="chip ${this.protoFilter===`all`?`active`:``}"
              @click=${()=>this.protoFilter=`all`}
            >
              ${V(`common.all`)}
            </button>
            ${t.map(e=>g`
                <button
                  class="chip ${this.protoFilter===e?`active`:``}"
                  @click=${()=>this.protoFilter=e}
                >
                  ${e.toUpperCase()}
                </button>
              `)}
          </div>
        </div>

        ${this.detail?g`
              <div class="card">
                <div class="row between">
                  <div class="row">
                    <strong>${V(`connections.detail`)}</strong>
                    <span class="badge accent mono">#${this.detail.id}</span>
                  </div>
                  <div class="row">
                    ${this.detail.can_close?g`
                          <button
                            class="danger sm"
                            @click=${e=>void this.closeOne(this.detail.id,e)}
                          >
                            ${V(`connections.closeOne`)}
                          </button>
                        `:``}
                    <button class="sm" @click=${()=>this.detail=null}>
                      ${R.close()} ${V(`common.close`)}
                    </button>
                  </div>
                </div>
                <div class="drawer mono">
                  <div class="kv">
                    <span class="kv-label">${V(`connections.col.inbound`)}</span>
                    <span>${this.detail.inbound||`-`} (${this.detail.protocol})</span>
                  </div>
                  <div class="kv">
                    <span class="kv-label">${V(`connections.col.outbound`)}</span>
                    <span>${this.detail.outbound||this.detail.path}</span>
                  </div>
                  <div class="kv">
                    <span class="kv-label">${V(`connections.detail.source`)}</span>
                    <span>${this.detail.source||`-`}</span>
                  </div>
                  <div class="kv">
                    <span class="kv-label">${V(`connections.col.target`)}</span>
                    <span>${this.detail.target||`:${this.detail.destination_port}`}</span>
                  </div>
                  <div class="kv">
                    <span class="kv-label">${V(`connections.col.rule`)}</span>
                    <span>${this.detail.route_mode||`-`} · ${this.detail.route_rule||`-`}</span>
                  </div>
                  <div class="kv">
                    <span class="kv-label">${V(`connections.col.traffic`)}</span>
                    <span>↑ ${N(this.detail.upload_bytes)} / ↓ ${N(this.detail.download_bytes)}</span>
                  </div>
                  <div class="kv">
                    <span class="kv-label">${V(`connections.detail.process`)}</span>
                    <span class="truncate" title=${this.detail.process_path||`-`}>
                      ${this.detail.process_path||`-`}
                    </span>
                  </div>
                  <div class="kv">
                    <span class="kv-label">${V(`connections.detail.uidDuration`)}</span>
                    <span>${this.detail.source_uid??`-`} · ${jn(this.detail.duration_ms)}</span>
                  </div>
                </div>
              </div>
            `:``}

        <div class="card table-wrap" style="padding:8px 12px">
          <table>
            <thead>
              <tr>
                <th>${V(`connections.col.id`)}</th>
                <th>${V(`connections.col.inbound`)}</th>
                <th>${V(`connections.col.target`)}</th>
                <th>${V(`connections.col.outbound`)}</th>
                <th>${V(`connections.col.rule`)}</th>
                <th class="num-col">${V(`connections.col.traffic`)}</th>
                <th class="num-col">${V(`connections.col.duration`)}</th>
                <th>${V(`connections.col.action`)}</th>
              </tr>
            </thead>
            <tbody>
              ${e.length===0?g`
                    <tr>
                      <td colspan="8">
                        <div class="empty-state">
                          <span>${V(`connections.empty`)}</span>
                          ${n?g`<button class="sm" @click=${()=>{this.search=``,this.protoFilter=`all`}}>${V(`common.clearFilters`)}</button>`:g`<button class="sm" @click=${()=>void this.refreshOnce()}>${R.refresh()} ${V(`common.refresh`)}</button>`}
                        </div>
                      </td>
                    </tr>
                  `:e.map(e=>g`
                      <tr
                        class="clickable ${this.detail?.id===e.id?`selected`:``}"
                        tabindex="0"
                        @click=${()=>void this.inspect(e.id)}
                        @keydown=${t=>{t.target===t.currentTarget&&(t.key===`Enter`||t.key===` `)&&(t.preventDefault(),this.inspect(e.id))}}
                      >
                        <td class="mono muted">#${e.id}</td>
                        <td>
                          <span>${e.inbound||`-`}</span>
                          <span class="badge">${e.protocol.toUpperCase()}</span>
                        </td>
                        <td class="mono target-cell truncate" title=${e.target||`:${e.destination_port}`}>
                          ${e.target||`:${e.destination_port}`}
                        </td>
                        <td><span class="badge ok">${e.outbound||e.path}</span></td>
                        <td class="mono muted">${e.route_rule||`-`}</td>
                        <td class="mono num-col">
                          <span style="color:var(--nx-up)">↑<span class="rate-slot">${N(e.upload_bytes)}</span></span>
                          /
                          <span style="color:var(--nx-down)">↓<span class="rate-slot">${N(e.download_bytes)}</span></span>
                        </td>
                        <td class="mono muted num-col">${jn(e.duration_ms)}</td>
                        <td>
                          <button
                            class="danger sm"
                            ?disabled=${!e.can_close}
                            @click=${t=>void this.closeOne(e.id,t)}
                          >
                            ${V(`connections.closeOne`)}
                          </button>
                        </td>
                      </tr>
                    `)}
            </tbody>
          </table>
        </div>
      </div>
    `}};U([w()],J.prototype,`connections`,void 0),U([w()],J.prototype,`detail`,void 0),U([w()],J.prototype,`search`,void 0),U([w()],J.prototype,`protoFilter`,void 0),U([w()],J.prototype,`sortBy`,void 0),U([w()],J.prototype,`paused`,void 0),U([w()],J.prototype,`streamState`,void 0),U([w()],J.prototype,`confirmMode`,void 0),U([w()],J.prototype,`toast`,void 0),U([w()],J.prototype,`toastKind`,void 0),J=U([C(`nexus-connections-page`)],J);var rr=[`A`,`AAAA`,`HTTPS`,`SVCB`,`CNAME`,`TXT`,`MX`,`SRV`,`NS`,`PTR`,`SOA`,`CAA`],Y=class extends S{constructor(...e){super(...e),this.domain=`example.com`,this.qtype=`A`,this.server=``,this.querying=!1,this.cacheBusy=!1,this.confirmClearAll=!1,this.result=null,this.recent=[],this.copiedIdx=-1,this.toast=``,this.toastKind=`ok`,this.unsubLocale=null}static{this.styles=[H,o`
      .query-form {
        display: grid;
        grid-template-columns: 1fr 110px 160px auto;
        gap: 8px;
        margin-top: 10px;
      }
      @media (max-width: 780px) {
        .query-form {
          grid-template-columns: 1fr 1fr;
        }
      }
      .result-box {
        margin-top: 12px;
        background: var(--nx-well);
        border-radius: 8px;
        padding: 12px;
      }
      .data-cell {
        word-break: break-all;
      }
      .cache-bar {
        margin-top: 12px;
        padding-top: 12px;
        border-top: 1px solid var(--nx-border);
      }
    `]}connectedCallback(){super.connectedCallback(),this.unsubLocale=B(()=>this.requestUpdate())}disconnectedCallback(){super.disconnectedCallback(),this.unsubLocale?.(),this.unsubLocale=null}async runQuery(){let e=this.domain.trim();if(e&&!this.querying){this.querying=!0,this.toast=``;try{let t=await I.dnsQuery({name:e,type:this.qtype,server:this.server.trim()||void 0});this.result=t;let n=`${e}|${this.qtype}`;this.recent=[{name:e,type:this.qtype},...this.recent.filter(e=>`${e.name}|${e.type}`!==n)].slice(0,5)}catch(e){this.toast=e instanceof Error?e.message:String(e),this.toastKind=`err`}finally{this.querying=!1}}}async flushFakeip(){this.cacheBusy=!0;try{let e=await I.flushFakeIp();this.toast=V(`overview.flushedFakeip`,{count:e.flushed}),this.toastKind=`ok`}catch(e){this.toast=e instanceof Error?e.message:String(e),this.toastKind=`err`}finally{this.cacheBusy=!1}}async clearCache(e){this.confirmClearAll=!1,this.cacheBusy=!0;try{let t=await I.clearCache(e);this.toast=`${t.target}: ${t.detail||`cleared`}`,this.toastKind=`ok`}catch(e){this.toast=e instanceof Error?e.message:String(e),this.toastKind=`err`}finally{this.cacheBusy=!1}}async copyAnswer(e,t){try{await navigator.clipboard.writeText(e),this.copiedIdx=t,setTimeout(()=>{this.copiedIdx===t&&(this.copiedIdx=-1)},1400)}catch{}}render(){let e=this.result,t=e?.answers??[],n=e?e.rcode===0?`ok`:e.rcode===3?`warn`:`err`:``;return g`
      <div class="card">
        <div class="row between">
          <h3>${V(`dns.title`)}</h3>
        </div>

        <form
          class="query-form"
          @submit=${e=>{e.preventDefault(),this.runQuery()}}
        >
          <input
            type="text"
            aria-label=${V(`dns.domainLabel`)}
            spellcheck="false"
            autocapitalize="none"
            autocorrect="off"
            placeholder=${V(`dns.domainPlaceholder`)}
            .value=${this.domain}
            @input=${e=>this.domain=e.target.value}
          />
          <select
            aria-label=${V(`dns.typeLabel`)}
            .value=${this.qtype}
            @change=${e=>this.qtype=e.target.value}
          >
            ${rr.map(e=>g`<option value=${e}>${e}</option>`)}
          </select>
          <input
            type="text"
            aria-label=${V(`dns.serverLabel`)}
            spellcheck="false"
            autocapitalize="none"
            autocorrect="off"
            placeholder=${V(`dns.serverPlaceholder`)}
            .value=${this.server}
            @input=${e=>this.server=e.target.value}
          />
          <button class="primary" type="submit" ?disabled=${this.querying||!this.domain.trim()}>
            ${R.search()} ${this.querying?V(`dns.querying`):V(`dns.query`)}
          </button>
        </form>

        ${this.recent.length>0?g`
              <div class="row" style="margin-top:8px">
                <span class="muted" style="font-size:11.5px">${V(`dns.recent`)}:</span>
                ${this.recent.map(e=>g`
                    <button
                      class="chip"
                      @click=${()=>{this.domain=e.name,this.qtype=e.type,this.runQuery()}}
                    >
                      <span class="mono">${e.name}</span>
                      <span>${e.type}</span>
                    </button>
                  `)}
              </div>
            `:``}

        ${this.toast?g`
              <div class="toast ${this.toastKind}" role="status" aria-live="polite" style="margin-top:10px">
                <span>${this.toast}</span>
                <button
                  class="ghost sm"
                  aria-label=${V(`common.dismiss`)}
                  @click=${()=>this.toast=``}
                >
                  ${R.close()}
                </button>
              </div>
            `:``}

        ${e?g`
              <div class="result-box">
                <div class="row between" style="margin-bottom:8px">
                  <div class="row">
                    <strong class="mono">${e.name}</strong>
                    <span class="badge accent">${e.type}</span>
                    <span class="badge ${n}">${e.rcode_name} (${e.rcode})</span>
                  </div>
                  <div class="row mono">
                    <span class="muted tabular">${V(`dns.col.ttl`)} ${e.ttl}s</span>
                    <span class="badge ok">${e.elapsed_ms} ms</span>
                  </div>
                </div>
                ${t.length===0?g`<div class="muted">${V(`dns.noAnswers`)}</div>`:g`
                      <div class="table-wrap">
                        <table>
                          <thead>
                            <tr>
                              <th>${V(`dns.col.name`)}</th>
                              <th>${V(`dns.col.type`)}</th>
                              <th>${V(`dns.col.ttl`)}</th>
                              <th>${V(`dns.col.data`)}</th>
                              <th></th>
                            </tr>
                          </thead>
                          <tbody>
                            ${t.map((e,t)=>g`
                                <tr>
                                  <td class="mono">${e.name}</td>
                                  <td><span class="badge">${e.type}</span></td>
                                  <td class="mono muted">${e.ttl}s</td>
                                  <td class="mono data-cell">${e.data}</td>
                                  <td style="text-align:right">
                                    <button
                                      class="ghost sm"
                                      @click=${()=>void this.copyAnswer(e.data,t)}
                                    >
                                      ${R.copy()}
                                      ${this.copiedIdx===t?V(`common.copied`):V(`common.copy`)}
                                    </button>
                                  </td>
                                </tr>
                              `)}
                          </tbody>
                        </table>
                      </div>
                    `}
              </div>
            `:``}

        <div class="row cache-bar">
          <button class="sm" ?disabled=${this.cacheBusy} @click=${()=>void this.flushFakeip()}>
            ${V(`dns.flushFakeip`)}
          </button>
          <button class="sm" ?disabled=${this.cacheBusy} @click=${()=>void this.clearCache(`dns`)}>
            ${V(`dns.cacheDns`)}
          </button>
          <button class="sm" ?disabled=${this.cacheBusy} @click=${()=>void this.clearCache(`rulesets`)}>
            ${V(`dns.cacheRules`)}
          </button>
          ${this.confirmClearAll?g`
                <button class="danger sm" ?disabled=${this.cacheBusy} @click=${()=>void this.clearCache(`all`)}>
                  ${V(`dns.confirmClearAll`)}
                </button>
                <button class="sm" @click=${()=>this.confirmClearAll=!1}>
                  ${V(`common.cancel`)}
                </button>
              `:g`
                <button class="danger sm" ?disabled=${this.cacheBusy} @click=${()=>this.confirmClearAll=!0}>
                  ${R.trash()} ${V(`dns.cacheAll`)}
                </button>
              `}
        </div>
      </div>
    `}};U([w()],Y.prototype,`domain`,void 0),U([w()],Y.prototype,`qtype`,void 0),U([w()],Y.prototype,`server`,void 0),U([w()],Y.prototype,`querying`,void 0),U([w()],Y.prototype,`cacheBusy`,void 0),U([w()],Y.prototype,`confirmClearAll`,void 0),U([w()],Y.prototype,`result`,void 0),U([w()],Y.prototype,`recent`,void 0),U([w()],Y.prototype,`copiedIdx`,void 0),U([w()],Y.prototype,`toast`,void 0),U([w()],Y.prototype,`toastKind`,void 0),Y=U([C(`nexus-dns-query-card`)],Y);var X=class extends S{constructor(...e){super(...e),this.rules=[],this.search=``,this.actionFilter=`all`,this.ssmUsers=[],this.ssmStats=null,this.ssmAvailable=!1,this.error=``,this.loading=!1,this.unsubs=[]}static{this.styles=[H,o`
      .summary-cell {
        word-break: break-word;
        max-width: 440px;
      }
      .user-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        padding: 7px 10px;
        border-radius: 8px;
        background: var(--nx-well);
      }
    `]}connectedCallback(){super.connectedCallback(),this.unsubs.push(G.subscribe(()=>void this.refresh(),`refresh`),B(()=>this.requestUpdate())),this.refresh()}disconnectedCallback(){super.disconnectedCallback();for(let e of this.unsubs)e();this.unsubs=[]}async refresh(){this.loading=!0;try{let e=await I.rules();this.rules=e.rules??[],this.error=``}catch(e){this.error=e instanceof Error?e.message:String(e)}finally{this.loading=!1}try{let[e,t]=await Promise.all([I.ssmapiUsers(),I.ssmapiStats()]);this.ssmUsers=e.users??[],this.ssmStats=t,this.ssmAvailable=!0}catch{this.ssmUsers=[],this.ssmStats=null,this.ssmAvailable=!1}}actionBadge(e){let t=e.toLowerCase();return t===`route`?`ok`:t===`reject`||t===`block`?`err`:t===`sniff`||t===`hijack-dns`||t===`resolve`?`accent`:`warn`}filteredRules(){let e=this.search.trim().toLowerCase();return this.rules.filter(t=>this.actionFilter!==`all`&&t.action.toLowerCase()!==this.actionFilter?!1:!e||`${t.index} ${t.type} ${t.action} ${t.target} ${t.summary}`.toLowerCase().includes(e))}render(){let e=this.filteredRules(),t=Array.from(new Set(this.rules.map(e=>e.action.toLowerCase()))),n=this.search.trim().length>0||this.actionFilter!==`all`;return g`
      <div class="page">
        <div class="page-head">
          <h2>${V(`rules.title`)}</h2>
          <button class="sm" ?disabled=${this.loading} @click=${()=>void this.refresh()}>
            ${R.refresh()} ${V(`common.refresh`)}
          </button>
        </div>

        <nexus-dns-query-card></nexus-dns-query-card>

        ${this.error?g`
              <div class="toast err" role="status" aria-live="polite">
                <span>${this.error}</span>
                <button
                  class="ghost sm"
                  aria-label=${V(`common.dismiss`)}
                  @click=${()=>this.error=``}
                >
                  ${R.close()}
                </button>
              </div>
            `:``}

        <div class="card col" style="gap:12px">
          <div class="row between">
            <div class="row">
              <h3>${V(`rules.tableTitle`)}</h3>
              <span class="muted tabular">${e.length} / ${this.rules.length}</span>
            </div>
          </div>

          <div class="row">
            <input
              data-search-input
              type="search"
              aria-label=${V(`rules.search`)}
              spellcheck="false"
              autocapitalize="none"
              autocorrect="off"
              style="flex:1; min-width:220px"
              placeholder=${V(`rules.search`)}
              .value=${this.search}
              @input=${e=>this.search=e.target.value}
            />
          </div>

          ${t.length>0?g`
                <div class="row">
                  <button
                    class="chip ${this.actionFilter===`all`?`active`:``}"
                    @click=${()=>this.actionFilter=`all`}
                  >
                    ${V(`common.all`)}
                  </button>
                  ${t.map(e=>g`
                      <button
                        class="chip ${this.actionFilter===e?`active`:``}"
                        @click=${()=>this.actionFilter=e}
                      >
                        ${e}
                      </button>
                    `)}
                </div>
              `:``}

          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>${V(`rules.col.index`)}</th>
                  <th>${V(`rules.col.type`)}</th>
                  <th>${V(`rules.col.action`)}</th>
                  <th>${V(`rules.col.target`)}</th>
                  <th>${V(`rules.col.summary`)}</th>
                </tr>
              </thead>
              <tbody>
                ${e.length===0?g`
                      <tr>
                        <td colspan="5">
                          <div class="empty-state">
                            <span>${V(`rules.empty`)}</span>
                            ${n?g`<button class="sm" @click=${()=>{this.search=``,this.actionFilter=`all`}}>${V(`common.clearFilters`)}</button>`:g`<button class="sm" ?disabled=${this.loading} @click=${()=>void this.refresh()}>${R.refresh()} ${V(`common.refresh`)}</button>`}
                          </div>
                        </td>
                      </tr>
                    `:e.map(e=>g`
                        <tr>
                          <td class="mono muted">#${e.index}</td>
                          <td><span class="badge">${e.type||`-`}</span></td>
                          <td><span class="badge ${this.actionBadge(e.action)}">${e.action}</span></td>
                          <td>
                            ${e.target?g`<span class="badge accent">${e.target}</span>`:g`<span class="muted">-</span>`}
                          </td>
                          <td class="mono summary-cell">${e.summary||`-`}</td>
                        </tr>
                      `)}
              </tbody>
            </table>
          </div>
        </div>

        <div class="card col">
          <div class="row between">
            <h3>${V(`rules.ssmapi`)}</h3>
            <span class="badge ${this.ssmAvailable?`ok`:``}">
              ${this.ssmAvailable?`${this.ssmStats?.userCount??this.ssmUsers.length} ${V(`rules.users`)}`:V(`common.off`)}
            </span>
          </div>
          ${this.ssmAvailable?g`
                <div class="row muted mono">
                  <span>↑ ${N(this.ssmStats?.uplinkBytes??0)}</span>
                  <span>·</span>
                  <span>↓ ${N(this.ssmStats?.downlinkBytes??0)}</span>
                  <span>·</span>
                  <span>TCP ${this.ssmStats?.tcpSessions??0} / UDP ${this.ssmStats?.udpSessions??0}</span>
                </div>
                <div class="col" style="gap:6px">
                  ${this.ssmUsers.slice(0,12).map(e=>g`
                      <div class="user-row">
                        <div class="row">
                          <strong class="mono">${e.username}</strong>
                          <span class="badge ${e.enabled?`ok`:`err`}">
                            ${e.enabled?V(`common.on`):V(`common.off`)}
                          </span>
                        </div>
                        <span class="mono muted">
                          ↑ ${N(e.uplinkBytes)} / ↓ ${N(e.downlinkBytes)}
                        </span>
                      </div>
                    `)}
                </div>
              `:g`<div class="muted">${V(`rules.ssmapiOff`)}</div>`}
        </div>
      </div>
    `}};U([w()],X.prototype,`rules`,void 0),U([w()],X.prototype,`search`,void 0),U([w()],X.prototype,`actionFilter`,void 0),U([w()],X.prototype,`ssmUsers`,void 0),U([w()],X.prototype,`ssmStats`,void 0),U([w()],X.prototype,`ssmAvailable`,void 0),U([w()],X.prototype,`error`,void 0),U([w()],X.prototype,`loading`,void 0),X=U([C(`nexus-rules-services-page`)],X);var ir=[`all`,`trace`,`debug`,`info`,`warn`,`error`],ar=[`all`,`core`,`net`,`tls`,`quic`,`dns`,`route`,`tun`,`proxy`,`control`,`state`],or=600,Z=class extends S{constructor(...e){super(...e),this.entries=[],this.latestSeq=0,this.evicted=0,this.level=`all`,this.domain=`all`,this.search=``,this.paused=!1,this.autoScroll=!0,this.streamState=`connecting`,this.copied=!1,this.toast=``,this.toastKind=`ok`,this.stream=null,this.releaseLogsChannel=null,this.seenSeq=new Set,this.reloadToken=0,this.unsubs=[],this.searchTimer=null}static{this.styles=[H,o`
      .log-box {
        max-height: 60dvh;
        min-height: 280px;
        overflow-y: auto;
        overscroll-behavior: contain;
        display: flex;
        flex-direction: column;
        gap: 2px;
        background: var(--nx-well);
        border-radius: 8px;
        padding: 8px;
      }
      .log-line {
        display: grid;
        grid-template-columns: 62px 68px 64px 72px 1fr;
        gap: 8px;
        align-items: baseline;
        padding: 4px 6px;
        border-radius: 6px;
        line-height: 1.45;
      }
      @media (hover: hover) and (pointer: fine) {
        .log-line:hover {
          background: var(--nx-row-hover);
        }
      }
      .msg {
        word-break: break-word;
      }
      @media (max-width: 720px) {
        .log-line {
          grid-template-columns: 56px 56px 1fr;
        }
        .hide-sm {
          display: none;
        }
      }
    `]}connectedCallback(){super.connectedCallback(),this.unsubs.push(G.onWsLog(e=>{!this.paused&&e.seq>this.latestSeq&&this.matchesFilters(e)&&this.appendEntry(e)}),G.subscribe(()=>this.syncTransport(),`transport-change`),G.subscribe(()=>this.requestUpdate(),`change`),G.subscribe(()=>void this.reloadStream(),`refresh`),B(()=>this.requestUpdate())),this.reloadStream()}stopStream(){this.stream?.stop(),this.stream=null}disconnectedCallback(){super.disconnectedCallback(),this.reloadToken++,this.stopStream(),this.releaseLogsChannel?.(),this.releaseLogsChannel=null,this.searchTimer!==null&&(clearTimeout(this.searchTimer),this.searchTimer=null);for(let e of this.unsubs)e();this.unsubs=[]}getFilterParams(){return{level:this.level===`all`?void 0:this.level,domain:this.domain===`all`?void 0:this.domain,search:this.search.trim()||void 0,since:this.latestSeq>0?this.latestSeq:void 0}}matchesFilters(e){if(this.domain!==`all`&&e.domain!==this.domain)return!1;if(this.level!==`all`){let t={trace:0,debug:1,info:2,warn:3,error:4,fatal:5},n=t[this.level]??0;if((t[e.level]??0)<n)return!1}let t=this.search.trim().toLowerCase();return!(t&&!`${e.domain} ${e.message}`.toLowerCase().includes(t))}syncTransport(){G.wsLive||G.authRequired?(this.stopStream(),this.streamState=G.authRequired?`unauthorized`:`live`):G.shouldUseSseFallback?!this.stream&&this.isConnected&&this.startFallbackSse(this.reloadToken):this.streamState=`connecting`}startFallbackSse(e){this.stopStream(),this.stream=Vn(()=>this.getFilterParams(),t=>{!this.paused&&e===this.reloadToken&&this.appendEntry(t)},t=>{!this.paused&&e===this.reloadToken&&this.applySnapshot(t.entries??[],t.latest_seq??0,t.evicted??0)},t=>{e===this.reloadToken&&(this.streamState=t)},t=>{e===this.reloadToken&&(this.toast=t,this.toastKind=`err`)}),this.stream.start()}async reloadStream(){let e=++this.reloadToken;this.stopStream(),this.seenSeq.clear(),this.entries=[],this.latestSeq=0;try{let t=await I.logs({level:this.level===`all`?void 0:this.level,domain:this.domain===`all`?void 0:this.domain,search:this.search.trim()||void 0,limit:250});if(!this.isConnected||e!==this.reloadToken)return;this.applySnapshot(t.entries??[],t.latest_seq??0,t.evicted??0),G.setLogCursor(this.latestSeq)}catch(t){if(!this.isConnected||e!==this.reloadToken)return;this.toast=t instanceof Error?t.message:String(t),this.toastKind=`err`}this.isConnected&&e===this.reloadToken&&(this.releaseLogsChannel||=G.acquireChannel(`logs`,this.latestSeq),this.syncTransport())}pruneSeenSeq(e){this.seenSeq.size<=or||(this.seenSeq=new Set(e.map(e=>e.seq)))}applySnapshot(e,t,n){this.latestSeq=Math.max(this.latestSeq,t),this.evicted=n;let r=!1,i=[...this.entries];for(let t of e)this.seenSeq.has(t.seq)||(this.seenSeq.add(t.seq),t.seq>this.latestSeq&&(this.latestSeq=t.seq),i.push(t),r=!0);if(r){let e=i.slice(-600);this.pruneSeenSeq(e),this.entries=e,this.scrollToBottom()}}appendEntry(e){if(this.seenSeq.has(e.seq))return;this.seenSeq.add(e.seq),e.seq>this.latestSeq&&(this.latestSeq=e.seq);let t=[...this.entries.slice(-599),e];this.pruneSeenSeq(t),this.entries=t,this.scrollToBottom()}scrollToBottom(){this.autoScroll&&this.updateComplete.then(()=>{let e=this.shadowRoot?.querySelector(`.log-box`);e&&(e.scrollTop=e.scrollHeight)})}scheduleReload(){this.searchTimer!==null&&clearTimeout(this.searchTimer),this.searchTimer=setTimeout(()=>{this.searchTimer=null,this.reloadStream()},280)}async updateCoreLevel(e){if(!e)return;let t=this.domain===`all`?`global`:this.domain;try{await I.setLogLevel(e,t),this.toast=V(`logs.levelApplied`,{domain:t,level:e}),this.toastKind=`ok`}catch(e){this.toast=e instanceof Error?e.message:String(e),this.toastKind=`err`}}formatPlainLines(){return this.entries.map(e=>`#${e.seq} ${Mn(e.timestamp_ns)} [${e.level}] (${e.domain}) ev=${e.event} ${e.message}`).join(`
`)}async copyLogs(){try{await navigator.clipboard.writeText(this.formatPlainLines()),this.copied=!0,setTimeout(()=>this.copied=!1,1400)}catch{}}exportSnapshot(){let e=new Blob([this.formatPlainLines()+`
`],{type:`text/plain;charset=utf-8`}),t=URL.createObjectURL(e),n=document.createElement(`a`);n.href=t,n.download=`nexus-logs-${Date.now()}.txt`,n.click(),setTimeout(()=>URL.revokeObjectURL(t),1e3)}levelBadge(e){return e===`error`?`err`:e===`warn`?`warn`:e===`info`?`accent`:e===`debug`?`ok`:``}render(){let e=G.wsLive?`live`:this.streamState,t=e===`live`?`ok`:e===`polling`||e===`connecting`?`warn`:`err`,n=e===`live`&&G.wsLive?V(`stream.liveWs`):V(`stream.${e}`),r=this.level!==`all`||this.domain!==`all`||this.search.trim().length>0;return g`
      <div class="page">
        <div class="page-head">
          <div class="row">
            <h2>${V(`logs.title`)}</h2>
            <span class="badge ${t}">
              <span class="dot"></span>${n}
            </span>
            <span class="muted mono tabular">
              ${V(`logs.latest`)} #${this.latestSeq} · ${V(`logs.evicted`)} ${this.evicted}
            </span>
          </div>
          <div class="row">
            <button class="sm" @click=${()=>this.paused=!this.paused}>
              ${this.paused?R.play():R.pause()}
              ${this.paused?V(`common.resume`):V(`common.pause`)}
            </button>
            <button
              class="chip ${this.autoScroll?`active`:``}"
              @click=${()=>{this.autoScroll=!this.autoScroll,this.autoScroll&&this.scrollToBottom()}}
            >
              ${V(`logs.autoscroll`)}
            </button>
            <button
              class="sm"
              ?disabled=${this.entries.length===0}
              @click=${()=>void this.copyLogs()}
            >
              ${R.copy()} ${this.copied?V(`common.copied`):V(`common.copy`)}
            </button>
            <button
              class="sm"
              ?disabled=${this.entries.length===0}
              @click=${()=>this.exportSnapshot()}
            >
              ${R.download()} ${V(`common.export`)}
            </button>
            <button class="primary sm" @click=${()=>void this.reloadStream()}>
              ${R.refresh()} ${V(`common.refresh`)}
            </button>
          </div>
        </div>

        ${this.toast?g`
              <div class="toast ${this.toastKind}" role="status" aria-live="polite">
                <span>${this.toast}</span>
                <button
                  class="ghost sm"
                  aria-label=${V(`common.dismiss`)}
                  @click=${()=>this.toast=``}
                >
                  ${R.close()}
                </button>
              </div>
            `:``}

        <div class="card col" style="gap:10px">
          <div class="row">
            <input
              data-search-input
              type="search"
              aria-label=${V(`logs.search`)}
              spellcheck="false"
              autocapitalize="none"
              autocorrect="off"
              style="flex:1; min-width:200px"
              placeholder=${V(`logs.search`)}
              .value=${this.search}
              @input=${e=>{this.search=e.target.value,this.scheduleReload()}}
              @keydown=${e=>e.key===`Enter`&&void this.reloadStream()}
            />
            <select
              aria-label=${V(`logs.domainLabel`)}
              .value=${this.domain}
              @change=${e=>{this.domain=e.target.value,this.reloadStream()}}
            >
              ${ar.map(e=>g`<option value=${e}>
                    ${V(`logs.domainPrefix`,{domain:e===`all`?V(`common.all`):e})}
                  </option>`)}
            </select>
            <select
              aria-label=${V(`logs.coreLevelLabel`)}
              @change=${e=>{let t=e.target;this.updateCoreLevel(t.value),t.value=``}}
            >
              <option value="" selected disabled>${V(`logs.coreLevel`)}…</option>
              ${[`error`,`warn`,`info`,`debug`,`trace`].map(e=>g`<option value=${e}>${e.toUpperCase()}</option>`)}
            </select>
          </div>

          <div class="row">
            ${ir.map(e=>g`
                <button
                  class="chip ${this.level===e?`active`:``}"
                  @click=${()=>{this.level=e,this.reloadStream()}}
                >
                  ${e===`all`?V(`common.all`):e.toUpperCase()}
                </button>
              `)}
          </div>
        </div>

        <div class="card" style="padding:10px">
          <div class="log-box mono">
            ${this.entries.length===0?g`
                  <div class="empty-state">
                    <span>${V(`logs.empty`)}</span>
                    ${r?g`<button class="sm" @click=${()=>{this.level=`all`,this.domain=`all`,this.search=``,this.reloadStream()}}>${V(`common.clearFilters`)}</button>`:g`<button class="sm" @click=${()=>void this.reloadStream()}>${R.refresh()} ${V(`common.refresh`)}</button>`}
                  </div>
                `:this.entries.map(e=>g`
                    <div class="log-line">
                      <span class="muted">#${e.seq}</span>
                      <span class="muted hide-sm">${Mn(e.timestamp_ns)}</span>
                      <span class="badge ${this.levelBadge(e.level)}">${e.level}</span>
                      <span class="muted hide-sm">${e.domain}</span>
                      <span class="msg">${e.message}</span>
                    </div>
                  `)}
          </div>
        </div>
      </div>
    `}};U([w()],Z.prototype,`entries`,void 0),U([w()],Z.prototype,`latestSeq`,void 0),U([w()],Z.prototype,`evicted`,void 0),U([w()],Z.prototype,`level`,void 0),U([w()],Z.prototype,`domain`,void 0),U([w()],Z.prototype,`search`,void 0),U([w()],Z.prototype,`paused`,void 0),U([w()],Z.prototype,`autoScroll`,void 0),U([w()],Z.prototype,`streamState`,void 0),U([w()],Z.prototype,`copied`,void 0),U([w()],Z.prototype,`toast`,void 0),U([w()],Z.prototype,`toastKind`,void 0),Z=U([C(`nexus-logs-page`)],Z);var Q=class extends S{constructor(...e){super(...e),this.diag=null,this.health=null,this.events=[],this.metricsText=``,this.metricsEnabled=!1,this.showRawMetrics=!1,this.tokenInput=M(),this.copied=!1,this.busy=!1,this.toast=``,this.toastKind=`ok`,this.unsubs=[]}static{this.styles=[H,o`
      .metrics-pre {
        margin: 8px 0 0;
        padding: 12px;
        border-radius: 8px;
        background: var(--nx-well);
        max-height: 260px;
        overflow: auto;
        overscroll-behavior: contain;
        white-space: pre-wrap;
        word-break: break-all;
        font-size: 11.5px;
        line-height: 1.45;
      }
      .kpi-card {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
    `]}connectedCallback(){super.connectedCallback(),this.unsubs.push(G.subscribe(()=>void this.refresh(),`refresh`),B(()=>this.requestUpdate())),this.refresh()}disconnectedCallback(){super.disconnectedCallback();for(let e of this.unsubs)e();this.unsubs=[]}async refresh(){this.busy=!0;try{let[e,t,n]=await Promise.all([I.diagnostics(),I.health(),I.events(0).catch(()=>null)]);this.diag=e,this.health=t,this.events=(n?.events??[]).slice(-30).reverse()}catch(e){this.toast=e instanceof Error?e.message:String(e),this.toastKind=`err`}finally{this.busy=!1}try{this.metricsText=await I.metricsText(),this.metricsEnabled=!0}catch{this.metricsText=``,this.metricsEnabled=!1}}async saveToken(){On(this.tokenInput);try{let e=await I.health();this.health=e,this.toast=V(`auth.verified`,{instance:e.instance}),this.toastKind=`ok`,await this.refresh()}catch(e){this.toast=V(`auth.failed`,{error:e instanceof Error?e.message:String(e)}),this.toastKind=`err`}}clearToken(){this.tokenInput=``,On(``),this.toast=V(`auth.cleared`),this.toastKind=`ok`}async notifyNetworkChange(){this.busy=!0;try{await I.networkChange(),this.toast=V(`diag.networkNotified`),this.toastKind=`ok`,await this.refresh()}catch(e){this.toast=e instanceof Error?e.message:String(e),this.toastKind=`err`}finally{this.busy=!1}}async copyJsonReport(){let e={captured_at:new Date().toISOString(),health:this.health,status:G.status,mode:G.mode,diagnostics:this.diag,recent_events:this.events};try{await navigator.clipboard.writeText(JSON.stringify(e,null,2)),this.copied=!0,setTimeout(()=>this.copied=!1,1600)}catch{}}parsedMetricLines(){return this.metricsText.split(`
`).filter(e=>e&&!e.startsWith(`#`)).slice(0,12).map(e=>{let t=e.lastIndexOf(` `);return t>0?{name:e.slice(0,t),value:e.slice(t+1)}:{name:e,value:``}})}render(){let e=this.metricsEnabled?this.parsedMetricLines():[];return g`
      <div class="page">
        <div class="page-head">
          <div class="row">
            <h2>${V(`diag.title`)}</h2>
            ${this.health?g`<span class="badge ok">${this.health.status.toUpperCase()} · ${this.health.instance}</span>`:``}
          </div>
          <div class="row">
            <button class="sm" ?disabled=${this.busy} @click=${()=>void this.notifyNetworkChange()}>
              ${R.bolt()} ${V(`diag.networkChange`)}
            </button>
            <button class="sm" @click=${()=>void this.copyJsonReport()}>
              ${R.copy()} ${this.copied?V(`common.copied`):V(`diag.copyJson`)}
            </button>
            <button class="primary sm" ?disabled=${this.busy} @click=${()=>void this.refresh()}>
              ${R.refresh()} ${V(`common.refresh`)}
            </button>
          </div>
        </div>

        ${this.toast?g`
              <div class="toast ${this.toastKind}" role="status" aria-live="polite">
                <span>${this.toast}</span>
                <button
                  class="ghost sm"
                  aria-label=${V(`common.dismiss`)}
                  @click=${()=>this.toast=``}
                >
                  ${R.close()}
                </button>
              </div>
            `:``}

        ${this.diag?g`
              <div class="bento-grid">
                <div class="card kpi-card">
                  <h3>${V(`diag.authorized`)}</h3>
                  <div class="metric" style="color:var(--nx-ok-fg)">${this.diag.authorized_requests}</div>
                  <div class="muted mono">${V(`overview.gen`)} #${this.diag.control_generation}</div>
                </div>
                <div class="card kpi-card">
                  <h3>${V(`diag.unauthorized`)}</h3>
                  <div class="metric" style="color:${this.diag.unauthorized_requests>0?`var(--nx-err-fg)`:`inherit`}">
                    ${this.diag.unauthorized_requests}
                  </div>
                  <div class="muted">HTTP 401</div>
                </div>
                <div class="card kpi-card">
                  <h3>${V(`diag.expired`)}</h3>
                  <div class="metric">${this.diag.expired_requests} / ${this.diag.reply_failed}</div>
                  <div class="muted">${V(`diag.timeoutReply`)}</div>
                </div>
                <div class="card kpi-card">
                  <h3>${V(`diag.listenersConn`)}</h3>
                  <div class="metric">${this.diag.listeners} / ${this.diag.active_connections}</div>
                  <div class="muted mono">${this.diag.instance}</div>
                </div>
              </div>
            `:``}

        <div class="card col">
          <div class="row between">
            <h3>${V(`auth.title`)}</h3>
            <span class="muted mono" style="font-size:11.5px">${V(`diag.sessionStorageOnly`)}</span>
          </div>
          <p class="muted" style="margin:0">${V(`auth.desc`)}</p>
          <div class="row">
            <input
              data-search-input
              type="password"
              aria-label=${V(`auth.tokenLabel`)}
              autocomplete="off"
              spellcheck="false"
              autocapitalize="none"
              autocorrect="off"
              style="flex:1; min-width:240px"
              placeholder=${V(`auth.placeholder`)}
              .value=${this.tokenInput}
              @input=${e=>this.tokenInput=e.target.value}
              @keydown=${e=>e.key===`Enter`&&void this.saveToken()}
            />
            <button class="primary" @click=${()=>void this.saveToken()}>
              ${R.lock()} ${V(`auth.save`)}
            </button>
            <button @click=${()=>this.clearToken()}>${V(`auth.clear`)}</button>
          </div>
        </div>

        <div class="bento-2">
          <div class="card col">
            <div class="row between">
              <h3>${V(`diag.events`)}</h3>
              <span class="muted tabular">${this.events.length}</span>
            </div>
            ${this.events.length===0?g`
                  <div class="empty-state">
                    <span>${V(`diag.noEvents`)}</span>
                    <button class="sm" ?disabled=${this.busy} @click=${()=>void this.refresh()}>
                      ${R.refresh()} ${V(`common.refresh`)}
                    </button>
                  </div>
                `:g`
                  <div class="table-wrap">
                    <table>
                      <thead>
                        <tr>
                          <th>${V(`diag.col.id`)}</th>
                          <th>${V(`diag.col.event`)}</th>
                          <th>${V(`diag.col.gen`)}</th>
                        </tr>
                      </thead>
                      <tbody>
                        ${this.events.slice(0,15).map(e=>g`
                            <tr>
                              <td class="mono muted">#${e.id}</td>
                              <td><span class="badge accent">${e.event}</span></td>
                              <td class="mono muted">#${e.control_generation}</td>
                            </tr>
                          `)}
                      </tbody>
                    </table>
                  </div>
                `}
          </div>

          <div class="card col">
            <div class="row between">
              <h3>${V(`diag.metrics`)}</h3>
              ${this.metricsEnabled?g`
                    <button class="sm" @click=${()=>this.showRawMetrics=!this.showRawMetrics}>
                      ${this.showRawMetrics?V(`diag.summary`):V(`diag.raw`)}
                    </button>
                  `:g`<span class="badge">${V(`common.off`)}</span>`}
            </div>
            ${this.metricsEnabled?this.showRawMetrics?g`<pre class="metrics-pre mono">${this.metricsText}</pre>`:g`
                    <div class="table-wrap">
                      <table>
                        <tbody>
                          ${e.map(e=>g`
                              <tr>
                                <td class="mono muted" style="word-break:break-all">${e.name}</td>
                                <td class="mono num-col" style="font-weight:600">${e.value}</td>
                              </tr>
                            `)}
                        </tbody>
                      </table>
                    </div>
                  `:g`<div class="empty-state">${V(`diag.metricsOff`)}</div>`}
          </div>
        </div>
      </div>
    `}};U([w()],Q.prototype,`diag`,void 0),U([w()],Q.prototype,`health`,void 0),U([w()],Q.prototype,`events`,void 0),U([w()],Q.prototype,`metricsText`,void 0),U([w()],Q.prototype,`metricsEnabled`,void 0),U([w()],Q.prototype,`showRawMetrics`,void 0),U([w()],Q.prototype,`tokenInput`,void 0),U([w()],Q.prototype,`copied`,void 0),U([w()],Q.prototype,`busy`,void 0),U([w()],Q.prototype,`toast`,void 0),U([w()],Q.prototype,`toastKind`,void 0),Q=U([C(`nexus-diagnostics-page`)],Q);var $=[{path:`/`,key:`1`,labelKey:`nav.overview`,component:`nexus-overview-page`,icon:R.overview,exact:!0},{path:`/outbounds`,key:`2`,labelKey:`nav.outbounds`,component:`nexus-outbounds-page`,icon:R.outbounds},{path:`/connections`,key:`3`,labelKey:`nav.connections`,component:`nexus-connections-page`,icon:R.connections},{path:`/services`,key:`4`,labelKey:`nav.rules`,component:`nexus-rules-services-page`,icon:R.rules},{path:`/logs`,key:`5`,labelKey:`nav.logs`,component:`nexus-logs-page`,icon:R.logs},{path:`/diagnostics`,key:`6`,labelKey:`nav.diagnostics`,component:`nexus-diagnostics-page`,icon:R.diagnostics}],sr=$.map(e=>({path:e.path,title:()=>`${V(e.labelKey)} · Nexus`,component:e.component})),cr=class extends S{constructor(...e){super(...e),this.authModalOpen=!1,this.router=new on({routes:sr,autoStart:!0}),this.unsubs=[],this.handleKeydown=e=>{if(e.key===`Escape`&&this.authModalOpen){this.authModalOpen=!1;return}if(e.metaKey||e.ctrlKey||e.altKey||this.isTypingTarget(e))return;let t=$.find(t=>t.key===e.key);t?(e.preventDefault(),this.router.push(t.path)):e.key===`/`?(e.preventDefault(),this.focusActiveSearch()):(e.key===`r`||e.key===`R`)&&(e.preventDefault(),G.refreshNow())}}static{this.styles=[Zn,H,o`
      :host {
        display: block;
        min-height: 100dvh;
        background: var(--nx-bg);
        color: var(--nx-text);
        font-family:
          Inter,
          system-ui,
          -apple-system,
          BlinkMacSystemFont,
          'Segoe UI',
          sans-serif;
      }
      .shell {
        display: grid;
        grid-template-columns: 224px 1fr;
        min-height: 100dvh;
      }
      aside {
        background: var(--nx-sidebar);
        border-right: 1px solid var(--nx-border);
        padding: 16px 12px 14px;
        display: flex;
        flex-direction: column;
        gap: 10px;
        position: sticky;
        top: 0;
        height: 100dvh;
      }
      .brand-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 4px 6px 6px;
        gap: 8px;
      }
      .brand {
        display: flex;
        align-items: center;
        gap: 9px;
      }
      .brand-mark {
        width: 26px;
        height: 26px;
        border-radius: 7px;
        background: var(--nx-accent);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        color: var(--nx-accent-fg);
        font-weight: 700;
        font-size: 13px;
      }
      .brand-text {
        font-size: 15px;
        font-weight: 700;
        letter-spacing: 0.1em;
      }
      nav {
        display: flex;
        flex-direction: column;
        gap: 2px;
      }
      nav a {
        display: flex;
        align-items: center;
        gap: 9px;
        text-decoration: none;
        color: var(--nx-text-secondary);
        padding: 8px 10px;
        border-radius: 8px;
        font-size: 13.5px;
        font-weight: 600;
      }
      nav a.active {
        background: var(--nx-accent-soft);
        color: var(--nx-accent-text, var(--nx-accent));
      }
      @media (hover: hover) and (pointer: fine) {
        nav a:hover:not(.active) {
          background: var(--nx-well);
          color: var(--nx-text);
        }
      }
      .sidebar-foot {
        margin-top: auto;
        display: flex;
        flex-direction: column;
        gap: 8px;
        padding-top: 10px;
        border-top: 1px solid var(--nx-border);
      }
      .mini-rates {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 6px;
        padding: 8px 10px;
        border-radius: 8px;
        background: var(--nx-well);
        font-size: 11.5px;
      }
      .controls-row {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 5px;
      }
      .controls-row button {
        padding: 6px 4px;
        font-size: 11.5px;
      }
      main {
        padding: 20px 24px max(24px, env(safe-area-inset-bottom));
        max-width: 1280px;
        width: 100%;
        margin: 0 auto;
        min-width: 0;
      }
      .auth-banner {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        margin-bottom: 14px;
        padding: 10px 14px;
        border-radius: 10px;
        background: var(--nx-warn-bg);
        border: 1px solid var(--nx-warn-border);
        color: var(--nx-warn-fg);
        font-size: 13px;
        font-weight: 500;
      }
      @media (max-width: 860px) {
        .shell {
          grid-template-columns: 1fr;
        }
        aside {
          position: sticky;
          top: 0;
          height: auto;
          z-index: 30;
          border-right: none;
          border-bottom: 1px solid var(--nx-border);
          padding: max(10px, env(safe-area-inset-top)) max(12px, env(safe-area-inset-right)) 10px
            max(12px, env(safe-area-inset-left));
          gap: 8px;
        }
        nav {
          flex-direction: row;
          overflow-x: auto;
          overscroll-behavior: contain;
          padding-bottom: 2px;
        }
        nav a {
          padding: 7px 10px;
          white-space: nowrap;
        }
        .mini-rates,
        .hint-line {
          display: none;
        }
        .sidebar-foot {
          margin-top: 0;
          padding-top: 0;
          border-top: none;
        }
        main {
          padding: 14px max(14px, env(safe-area-inset-right))
            max(20px, env(safe-area-inset-bottom)) max(14px, env(safe-area-inset-left));
        }
      }
    `]}connectedCallback(){super.connectedCallback(),G.start(),this.syncHostTheme(),this.unsubs.push(G.subscribe(()=>{this.syncHostTheme(),this.requestUpdate()},`change`),G.subscribe(()=>this.requestUpdate(),`auth-required`),B(()=>{let e=$.find(e=>e.path===window.location.pathname)??$[0];document.title=`${V(e.labelKey)} · Nexus`,this.requestUpdate()})),window.addEventListener(`keydown`,this.handleKeydown)}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener(`keydown`,this.handleKeydown);for(let e of this.unsubs)e();this.unsubs=[],G.stop(),this.router.stop()}syncHostTheme(){this.setAttribute(`data-theme`,G.resolvedTheme)}isTypingTarget(e){for(let t of e.composedPath())if(t instanceof HTMLElement){let e=t.tagName;if(e===`INPUT`||e===`TEXTAREA`||e===`SELECT`||t.isContentEditable)return!0}return!1}focusActiveSearch(){let e=this.shadowRoot?.querySelector(`router-view`),t=(e?.shadowRoot?.querySelector(`.viewport`)?.firstElementChild??e?.firstElementChild)?.shadowRoot?.querySelector(`[data-search-input]`);t&&(t.focus(),t.select())}render(){let e=G.streamState,t=e===`live`?`ok`:e===`polling`||e===`connecting`?`warn`:`err`,n=e===`live`&&G.streamTransport===`ws`?V(`stream.liveWs`):V(`stream.${e}`),r=Jn();return g`
      <div class="shell">
        <aside>
          <div class="brand-row">
            <div class="brand">
              <span class="brand-mark" aria-hidden="true">N</span>
              <span class="brand-text">NEXUS</span>
            </div>
            <span class="badge ${t}" title=${G.streamError||n}>
              <span class="dot"></span>${n}
            </span>
          </div>

          <nav aria-label=${V(`nav.mainLabel`)}>
            ${$.map(e=>g`
                <a
                  title="${V(e.labelKey)} (${e.key})"
                  ${Sn(this.router,e.path,{exact:e.exact,activeClass:`active`})}
                >
                  ${e.icon()}<span>${V(e.labelKey)}</span>
                </a>
              `)}
          </nav>

          <div class="sidebar-foot">
            <div class="mini-rates mono">
              <span class="rate-slot" style="color:var(--nx-down)">↓ ${P(G.downRate)}</span>
              <span class="rate-slot" style="color:var(--nx-up)">↑ ${P(G.upRate)}</span>
            </div>

            <div class="controls-row">
              <button
                class="sm"
                title=${V(`theme.${G.themePref}`)}
                @click=${()=>G.cycleTheme()}
              >
                ${G.resolvedTheme===`dark`?R.moon():R.sun()}
                ${V(`theme.${G.themePref}`)}
              </button>
              <button class="sm" @click=${()=>Xn()}>
                ${R.globe()} ${r===`zh`?`中文`:`EN`}
              </button>
              <button
                class="sm ${G.authRequired?`danger`:``}"
                @click=${()=>this.authModalOpen=!0}
              >
                ${R.lock()} ${V(`auth.configure`)}
              </button>
            </div>

            <div class="muted hint-line" style="font-size:11px; text-align:center">
              ${V(`shortcuts.hint`)}
            </div>
          </div>
        </aside>

        <main>
          ${G.authRequired?g`
                <div class="auth-banner" role="alert">
                  <span>${V(`auth.banner`)}</span>
                  <button class="primary sm" @click=${()=>this.authModalOpen=!0}>
                    ${R.lock()} ${V(`auth.openConfig`)}
                  </button>
                </div>
              `:``}
          <router-view .router=${this.router}></router-view>
        </main>
      </div>

      <nexus-auth-modal
        .open=${this.authModalOpen}
        @close=${()=>this.authModalOpen=!1}
      ></nexus-auth-modal>
    `}};U([w()],cr.prototype,`authModalOpen`,void 0),cr=U([C(`nexus-app`)],cr);